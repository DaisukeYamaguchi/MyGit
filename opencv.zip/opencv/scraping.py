#coding : utf-8
import sys, time
from urllib import request
from selenium import webdriver
from selenium.webdriver import Chrome
from selenium.webdriver.chrome.options import Options

url = 'https://www.google.co.jp/search?biw=622&bih=601&tbm=isch&sa=1&ei=RpLcWo-XMMi08QWfnqioBQ&q=%E5%9F%8E%E5%B3%B6%E8%8C%82&oq=%E5%9F%8E%E5%B3%B6&gs_l=psy-ab.3.0.0l8.4777906.4784016.0.4785576.14.13.1.0.0.0.142.1432.5j8.13.0....0...1c.1j4.64.psy-ab..1.11.1152...0i4k1j0i4i10k1j0i10k1j0i24k1.0.wQnUJcx-W3Y'
dir = 'joshima'

def scrollPage(to):
  to = 'document.body.scrollHeight' if to == 'bottom' else '0'
  try:
    browser.execute_script('window.scrollTo(0, ' + to + ');')
  except:
    pass

if not os.path.exists('./train_data/' + dir):
  os.mkdir('./train_data/' + dir)

options = Options()
options.add_argument('--headless')

browser = webdriver.Chrome(chrome_options=options)
browser.maximize_window()

browser.get(url)

for i in range(20):
  scrollPage('bottom')
  time.sleep(1)

elem = browser.find_element_by_id('rg_s')

images = elem.find_elements_by_tag_name('img')

for i in range(len(images)):
  img = None
  localfile = None
  try:
    img = request.urlopen(images[i].get_attribute('src'))
    temp = '00' + str(i)
    localfile = open('./train_data/' + dir + '/train' + temp[len(temp) - 3:len(temp)] + ' .jpeg', 'wb')
    localfile.write(img.read())
  except:
    print('error: '+str(i))
    if img is not None:
      img.close()
    if localfile is not None:
      localfile.close()
    pass

browser.close()

