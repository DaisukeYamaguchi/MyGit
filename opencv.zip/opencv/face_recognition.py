import cv2

face_cascade_path = 'C:/Users/Daisuke Yamaguchi/AppData/Local/VirtualStore/Program Files/OpenCV/opencv/sources/data/haarcascades_cuda/haarcascade_frontalface_default.xml'
person_cascade_path = 'C:/Users/Daisuke Yamaguchi/AppData/Local/VirtualStore/Program Files/OpenCV/opencv/sources/data/haarcascades_cuda/haarcascade_eye.xml'

def get_images(path):
  image_pil = Image.open(os.path.join(path)).convert('L')
  
  image = np.array(image_pil, 'uint8')
  
  faces = faceCascade.detectMultiScale(image)
  
  for (x, y, w, h) in faces:
    image = cv2.resize(image[y: y + h, x: x + w], (200, 200), interpolation=cv2.INTER_LINEAR)
  
  return image

face_cascade = cv2.CascadeClassifier(face_cascade_path)

cap = cv2.VideoCapture(0)

while True:
  ret, img = cap.read()
  gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
  faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)
  for x, y, w, h in faces:
    cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
    cv2.imwrite('moment.jpeg', img[y: y + h, x: x + w])
    images = get_images('moment.jpeg')
    label, confidence = recognizer.predict(images)
    cv2.putText(img, class_[label] + ':' + str(round(confidence, 2)), (x-5, y-5), cv2.FONT_HERSHEY_PLAIN, 1.5, (0, 255, 0), 1, cv2.LINE_AA)
    face = img[y: y + h, x: x + w]
#    face_gray = gray[y: y + h, x: x + w]
#    eyes = eye_cascade.detectMultiScale(face_gray)
#    for (ex, ey, ew, eh) in eyes:
#      cv2.rectangle(face, (ex, ey), (ex + ew, ey + eh), (0, 255, 0), 2)
  cv2.imshow('video image', img)
  key = cv2.waitKey(10)
  if key == 27:  # ESCキーで終了
      break

cap.release()
cv2.destroyAllWindows()

