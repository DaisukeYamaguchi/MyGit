import os, random, cv2, copy
import numpy as np

images = []
for item in os.listdir('./images'):
  images.append('./images/' + item)

sampled = random.sample(images, 3)

height = 0
for i in range(len(sampled)):
  sampled[i] = cv2.imread(sampled[i])
  height = height if len(sampled[i]) < height else len(sampled[i])

padding = copy.deepcopy(np.arange(height * 3).reshape(height, 1, 3))
padding = padding * 0 + 255

for i in range(len(sampled)):
  template = np.array([copy.deepcopy(sampled[i][0])])
  for j in range(len(template)):
    for k in range(len(template[j])):
      template[j][k] = 255
  top = True
  while len(sampled[i]) < height:
    sampled[i] = np.vstack((template, sampled[i])) if top else np.vstack((sampled[i], template))
    top = not top

panorama = None
for i in range(len(sampled)):
  if 0 < i:
    #for j in range(int(np.random.normal(15, 5))):
    #  sampled[i] = np.hstack((padding, sampled[i]))
    panorama = np.hstack((panorama, sampled[i]))
  else:
    panorama = sampled[i]

cv2.imshow('img', panorama)

cv2.waitKey(0)
cv2.destroyAllWindows()

