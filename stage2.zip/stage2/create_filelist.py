# -*- coding: utf-8 -*
import numpy as np
import pkl

data = []
with open('filelist.csv', 'r', encoding = 'utf8') as f:
    for line in f:
        data.append(line.rstrip('\n').split(','))

classlist = []
for item in data:
    classlist.extend(item[1:])

classlist = list(set(classlist))

file_set = {}
for item1 in classlist:
    file_set[item1] = []
    for item2 in data:
        if item1 in item2[1:]:
            file_set[item1].append(item2[0])
    
    file_set[item1] = set(file_set[item1])

pkl.dump(file_set, 'file_set.pkl')

