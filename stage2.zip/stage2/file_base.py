# -*- coding: utf-8 -*
import os, sys, datetime
import pkl
from dateutil.relativedelta import relativedelta
from janome.tokenizer import Tokenizer

# 類義語学習のメッセージ
def extract(feature):
    
    status = pkl.load('status.pkl')
    est_box = pkl.load(est_box, 'est_box.pkl')
    
    status['time'] = datetime.datetime.today()
    
    week = ['月', '火', '水', '木', '金', '土', '日']
    
    t = Tokenizer('5w1h_dict.csv')
    
    tokens = t.tokenize(''.join(feature).upper())
    
    for token in tokens:
        if token.part_of_speech.split(',')[3] == 'when':
            if 'day' in token.infl_form:
                if est_box['file']['when']['from'] == '' and est_box['file']['when']['to'] == '':
                    est_box['file']['when']['direct'] = status['time'] - datetime.timedelta(days=int(token.infl_form.split('=')[1]))
                else:
                    est_box['file']['when']['direct'] = est_box['file']['when']['from'] + datetime.timedelta(days=int(token.infl_form.split('=')[1]))
                    print()
            elif 'month' in token.infl_form:
                if est_box['file']['when']['from'] == '' and est_box['file']['when']['to'] == '':
                    date = status['time'] - relativedelta(months=int(token.infl_form.split('=')[1]))
                    est_box['file']['when']['direct'] = date
                    est_box['file']['when']['from'] = est_box['file']['when']['direct'] - datetime.timedelta(days=est_box['file']['when']['direct'].day) + datetime.timedelta(days=1)
                    est_box['file']['when']['to'] = est_box['file']['when']['from'] + relativedelta(months=1) - datetime.timedelta(days=1)
            elif 'week' in token.infl_form:
                if est_box['file']['when']['from'] == '' and est_box['file']['when']['to'] == '':
                    print(token.infl_form.split('=')[1])
                    date = status['time'] - datetime.timedelta(days=int(token.infl_form.split('=')[1]) * 7)
                    est_box['file']['when']['direct'] = date
                    est_box['file']['when']['from'] = est_box['file']['when']['direct'] - datetime.timedelta(days=date.weekday())
                    est_box['file']['when']['to'] = est_box['file']['when']['direct'] + datetime.timedelta(days=6-date.weekday())
                else:
                    for i in range(7):
                        if week[(est_box['file']['when']['from'] + datetime.timedelta(days=i)).weekday()] == token.base_form:
                            est_box['file']['when']['direct'] = est_box['file']['when']['from'] + datetime.timedelta(days=i)
                    
                    est_box['file']['when']['from'] = est_box['file']['when']['to'] = ''
        if token.part_of_speech.split(',')[3] == 'who':
            est_box['file']['who'] = token.surface
        if token.part_of_speech.split(',')[3] == 'what':
            est_box['file']['what'] = token.base_form
    
    return est_box['file']

