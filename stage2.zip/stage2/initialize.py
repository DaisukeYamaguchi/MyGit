# -*- coding: utf-8 -*
from janome.tokenizer import Tokenizer
import random as rd
import datetime
import pkl

# 会話の状態管理
status = {'mode': '', 'time': '', 'zone': '', 'you': '', 'thema': '', 'talk': {}}

# 定型文の候補
hello = {'morning': 'おはようございます', 'noon': 'こんにちは', 'evening': 'こんばんは', 'any': 'お疲れ様です', 'first': '初めまして、私はボットです'}

static = {'contact': ['ご挨拶がまだですよね？', 'まずはご挨拶をしませんか？', 'あなたのお名前は？'], 
          'yourname': ['どなたですか？', 'お名前は何ですか？', 'あなたのお名前は？'], 
          'pardon': ['申し訳ありませんが、', 'お手数ですが、', '恐れ入りますが、'], 
          'rehear': ['表現を変えていただいてもよろしいですか？', '言い方を変えていただいてもよろしいでしょうか？', '別の言葉で表現していただいてもよろしいでようか？'], 
          'ask': ['どうされましたか？', '何かご用ですか？', 'どのようなご用件でしょうか？']}

est_box = {'file': {'who': '', 'when': {'direct': '', 'from': '', 'to': ''}, 'what': '', 'class': ''}}

def get_etiquette(msg):
    cls = ''
    for item in list(hello.values()):
        if msg in item:
            cls = 'greeting'
        
    
    return cls

# 状態を初期化
status['time'] = datetime.datetime.today()
status['turn'] = 'me'

h = int(status['time'].strftime("%H"))
if 4 <= h and h < 11:
    status['zone'] = 'morning'
elif 11 <= h and h < 18:
    status['zone'] = 'noon'
else:
    status['zone'] = 'evening'

pkl.dump(status, 'status.pkl')
pkl.dump(hello, 'hello.pkl')
pkl.dump(static, 'static.pkl')
pkl.dump(est_box, 'est_box.pkl')
