# -*- coding: utf-8 -*
import pkl

file_set = pkl.load('file_set.pkl')
est_box = pkl.load(est_box, 'est_box.pkl')

request_set = est_box['file']['class']

forcus = ''
if len(request_set) < 1:
    forcus = ''
elif len(request_set) < 2:
    forcus = request_set[0]
else:
    forcus = file_set[request_set[0]] & file_set[request_set[1]]
    for i in range(2, len(request_set)):
        forcus = forcus & file_set[request_set[i]]

