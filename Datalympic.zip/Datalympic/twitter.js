var twitter = require('twitter');
var fs = require('fs');
var moment = require('moment-timezone');
var request = require('request');
var x2j = require('xml2json');

var app = require('http').createServer(function(req, res) {
  var url = req.url == '/' ? '.' + req.url + 'index.html' : '.' + req.url;
  if (fs.existsSync(url)) {
    fs.readFile(url, (err, data) => {
      if (!err) {
        res.writeHead(200, {"Content-Type": getType(url)});
        res.end(data);
      }
    });
  }
}).listen(3000);

function getType(_url) {
  var types = {
    ".html": "text/html",
    ".css": "text/css",
    ".js": "text/javascript",
    ".png": "image/png",
    ".gif": "image/gif",
    ".svg": "svg+xml"
  }
  for (var key in types) {
    if (_url.endsWith(key)) {
      return types[key];
    }
  }
  return "text/plain";
}

var token = {
  consumer_key: 'SJNhcy2x9Re16L1uwkqEByxgY',
  consumer_secret: 'lefCMF3nmmxi1EhArGQkQAPWOeqB7OVKngxUQS1O8QzS0udOB9',
  access_token_key: '979716311717572608-pU9iY9tnv3d51RFLMtZB1Ts7CtgCGS4',
  access_token_secret: 'EAlbA8pAkR4KR5ALz5WgClTS0OD1vcbNjCB96DNDS2s7p'
};

var globalStream = null;

var filter = {
  keyword: null,
  rejectList: null,
  retweet: null,
  locations: null
}

var io = require('socket.io').listen(app);

io.sockets.on('connection', function(socket){
  socket.on('msg', function(data) {
    io.sockets.emit('msg', data);
  });
  
  socket.on('setting', function(data){
    console.log(data)
    filter.keyword = data.search;
    if(data.reject){
      data.reject = data.reject.replace(/ /g, '');
      data.reject = data.reject.replace(/,/g, '","');
      filter.rejectList = JSON.parse('["' + data.reject + '"]')
    }else{
      filter.rejectList = null;
    }
    
    if(data.address){
      request.get('https://www.geocoding.jp/api/?q=' + encodeURIComponent(data.address), function(err, res, body) {
        if (err) {
          console.log('Error: ' + err.message);
          return;
        }
        var json = JSON.parse(x2j.toJson(body));
        var lat = parseFloat(json.result.coordinate.lat);
        var lng = parseFloat(json.result.coordinate.lng);
        
        data.radius = data.radius ? data.radius : 10;
        
        var lat_km = data.radius * 0.00898769093;
        var lng_km = data.radius / (2 * Math.PI * 6378.137 * Math.cos(lat * (Math.PI / 180)) / 360);
        
        var sw = (lng - lng_km) + ',' + (lat - lat_km);
        var ne = (lng + lng_km) + ',' + (lat + lat_km);
        
        filter.locations = sw + ',' + ne;
        filter.retweet = data.retweet;
        startStream();
      });
    }else{
      filter.retweet = data.retweet;
      startStream();
    }
  });
});

function startStream(){
  if(globalStream){
    globalStream.destroy();
    globalStream = null;
  }
  twit = new twitter(token);
  
  var option = {};
  if(filter.keyword){
    option.track = filter.keyword;
  }
  if(filter.locations){
    option.locations = filter.locations;
  }
  
  twit.stream('statuses/filter', option, function(stream){
    globalStream = stream;
    globalStream.on('data', function(data){
      if(!rejectCheck(data.text) && retweetCheck(data.text)){
        var tweet = {
          created_at : moment(data.created_at, 'ddd MMM DD HH:mm:ss ZZ YYYY').tz('Asia/Tokyo').format("M/D HH:mm"),
          text: data.text,
          coordinates: data.coordinates,
          name: data.user.name
        }
        
        var hook = {};
        if(addressCheck(tweet.text)){
          console.log('address hooked.');
          slotsHook(tweet.text, function(err, data){
            io.sockets.emit('tweet', {tweet: tweet, hook: data});
          });
        }else{
          io.sockets.emit('tweet', {tweet: tweet, hook: hook});
        }
      }
    });
    
    globalStream.on('error', function (error) {
      console.log('error')
      globalStream.destroy();
      startStream();
    });
  });
}

function retweetCheck(str){
  if(!filter.retweet){
    if(str.startsWith('RT')){
      return false;
    }
  }
  return true;
}

function rejectCheck(str){
  if(filter.rejectList){
    var has = false;
    for(var d of filter.rejectList){
      if(str.indexOf(d) > -1){
        return true;
      }
    }
  }
  return false;
}

function addressCheck(str){
  var result = str.match(/.{1,6}[市郡区町村].{1,20}[\d０-９〇一-九十上下東西]/);
  return result;
}

function slotsHook(sentence, callback){
  var options = {
    uri: 'https://labs.goo.ne.jp/api/slot',
    headers: {
      'content-type': 'application/json'
    },
    json: {
      app_id: '3152d5c551b78c99091e581f5c64f32975d1910db7d29988d8c9b6760edcf13a',
      sentence: sentence
    }
  };
  
  request.post(options, function(err, response, body){
    var hook = {};
    if(err){
      return callback(err);
    }
    var fullname_ = '';
    for(i in body.slots.name){
      var surname = body.slots.name[i].surname ? body.slots.name[i].surname : '';
      var given_name = body.slots.name[i].given_name ? body.slots.name[i].given_name : '';
      if(fullname_){
        fullname_ += ('、' + surname + given_name);
      }else{
        fullname_ = surname + given_name;
      }
    }
    if(fullname_){
      hook.name = fullname_;
    }
    
    var sex_ = '';
    for(i in body.slots.sex){
      sex = body.slots.sex[i].norm_value ? body.slots.sex[i].norm_value : body.slots.sex[i].value;
      if(sex_){
        sex_ += ('、' + sex);
      }else{
        sex_ = sex;
      }
    }
    if(sex_){
      hook.sex = sex_;
    }
    
    var address_ = '';
    for(i in body.slots.address){
      address = body.slots.address[i].norm_value ? body.slots.address[i].norm_value : body.slots.address[i].value;
      if(['都', '道', '府', '県', '市', '町', '村'].indexOf(address.slice(-1)) < 0){
        if(body.slots.address[i].lat && body.slots.address[i].lon){
          address += (' ' + body.slots.address[i].lat + ':' + body.slots.address[i].lon)
        }
        if(address_){
          address_ += ('、' + address);
        }else{
          address_ = address;
        }
      }
    }
    if(address_){
      hook.address = address_;
    }
    
    var tel_ = '';
    for(i in body.slots.tel){
      tel = body.slots.tel[i].norm_value ? body.slots.tel[i].norm_value : body.slots.tel[i].value;
      if(tel_){
        tel_ += ('、' + tel);
      }else{
        tel_ = tel;
      }
    }
    if(tel_){
      hook.tel = tel_;
    }
    
    var age_ = '';
    for(i in body.slots.age){
      age = body.slots.age[i].norm_value ? body.slots.age[i].norm_value : body.slots.age[i].value;
      if(age_){
        age_ += ('、' + age);
      }else{
        age_ = age;
      }
    }
    if(age_){
      hook.age = age_;
    }
    
    var birthday_ = '';
    for(i in body.slots.birthday){
      birthday = body.slots.birthday[i].norm_value ? body.slots.birthday[i].norm_value : body.slots.birthday[i].value;
      if(birthday_){
        birthday_ += ('、' + birthday);
      }else{
        birthday_ = birthday;
      }
    }
    if(birthday_){
      hook.birthday = birthday_;
    }
    return callback(null, hook);
  });
}

