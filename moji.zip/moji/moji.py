import nnabla as nn
import nnabla.functions as F
import nnabla.parametric_functions as PF
import numpy as np
from scipy.misc import imread
from PIL import Image

import nnabla.solvers as S
from nnabla.utils.data_iterator import data_iterator_csv_dataset

def network(x, y, test=False):
    # Input:x -> 1,28,28
    # Convolution -> 16,13,13
    h = PF.convolution(x, 16, (16, 16), (0, 0), name='Convolution')
    # ReLU
    h = F.relu(h, True)
    # MaxPooling -> 16,3,3
    h = F.max_pooling(h, (4, 4), (4, 4))
    # Affine_2 -> 10
    h = PF.affine(h, (10, ), name='Affine_2')
    # Softmax
    h = F.softmax(h)
    # CategoricalCrossEntropy -> 1
    #h = F.categorical_cross_entropy(h, y)
    return h

def add_margin(pil_img, top, right, bottom, left, color):
    width, height = pil_img.size
    new_width = width + right + left
    new_height = height + top + bottom
    result = Image.new(pil_img.mode, (new_width, new_height), color)
    result.paste(pil_img, (left, top))
    return result

nn.clear_parameters()

x = nn.Variable((1, 1, 28, 28))
t = nn.Variable((1, 1))
y = network(x, t, test = True)

im = imread('C:\\Users\\Daisuke Yamaguchi\\Desktop\\moji\\test.png', flatten=True)
im = np.round(im)

for i in range(len(im)):
    for j in range(len(im[i])):
        im[i][j] = 0 if 200 < im[i][j] else 255 - im[i][j]

start = []
end = []
prev = 0
imx = np.sum(im, axis = 0)
for i in range(len(imx)):
    imx[i] = 1 if 0 < imx[i] else 0

for i in range(len(imx)):
    if i != 0:
        if prev != imx[i]:
            if prev:
                end.append(i)
            else:
                start.append(i)
            
            prev = (prev - 1) ** 2
    else:
        if 0 < imx[i]:
            start.append(i)
            prev = 1

nn.parameter.load_parameters('C:\\Users\\Daisuke Yamaguchi\\Desktop\\neural_network_console_120\\samples\\sample_dataset\\MNIST\\moji.files\\20181008_180741\\parameters.h5');

output = []
for i in range(len(start)):
    im_t = im[:, start[i]:end[i]]
    while True:
        if 0 < np.sum(im_t[0]):
            break
        im_t = np.delete(im_t, 0, axis = 0)
    while True:
        if 0 < np.sum(im_t[len(im_t) - 1]):
            break
        im_t = np.delete(im_t, len(im_t) - 1, axis = 0)
    
    height = len(im_t)
    width = len(im_t[0])
    if height < width:
        for j in range(width - height):
            if j % 2 == 0:
                im_t = np.vstack((im_t, im_t[0] - im_t[0]))
            else:
                im_t = np.vstack((im_t[0] - im_t[0], im_t))
    else:
        for j in range(height - width):
            if j % 2 == 0:
                im_t = np.hstack((im_t, np.array([[0]] * len(im_t))))
            else:
                im_t = np.hstack((np.array([[0]] * len(im_t)), im_t))
    
    im_t = Image.fromarray(im_t).resize((20, 20))
    im_t = add_margin(im_t, 4, 4, 4, 4, 0)
    
    im_t.convert('RGB').save(str(i) + '.png')
    
    x.d = np.array(im_t).reshape(1, 1, 28, 28) / 255
    
    y.forward()
    
    nums = np.array(y.d[0])
    
    index = np.argmax(nums)
    output.append([index, nums[index]])


