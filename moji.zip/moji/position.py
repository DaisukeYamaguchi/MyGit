import cv2
import math
import numpy as np
from scipy import ndimage

img = cv2.imread('./sample/data3.png')
gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
edges = cv2.Canny(gray,50,150,apertureSize = 3)

minLineLength = 100
maxLineGap = 30

point = []
lines = cv2.HoughLines(edges, 1, np.pi / 180, 100)
for line in lines:
    for rho, theta in line:
        a = np.cos(theta)
        b = np.sin(theta)
        x0 = a * rho
        y0 = b * rho
        x1 = int(x0 + 0 * (-b))
        y1 = int(y0 + 0 * (a))
        x2 = int(x0 - 550 * (-b))
        y2 = int(y0 - 550 * (a))
        
        slope = math.degrees(math.atan2((y2 - y1), (x2 - x1)))
        if -45 < slope < 45:
            point.append(slope)
        
        #waste = cv2.line(img, (x1, y1), (x2, y2), (0, 0, 255), 2)

waste = point.pop(0)
point = np.array(point)

slope = np.sum(point) / len(point)

target = ndimage.rotate(img, slope)
#target = np.array(target)

im_t = Image.fromarray(target)
im_t.convert('RGB').save('./result.png')

#cv2.imwrite('result.png', img)



56 47  270 113
191 169  405 235
455 238  564 343
258 420  563 486