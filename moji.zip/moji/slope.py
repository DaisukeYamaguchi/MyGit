import nnabla as nn
import nnabla.functions as F
import nnabla.parametric_functions as PF
import numpy as np

import cv2, math, sys
from scipy import ndimage
from scipy.misc import imread
from PIL import Image

import nnabla.solvers as S
from nnabla.utils.data_iterator import data_iterator_csv_dataset

def network(x, y, test=False):
    # Input:x -> 1,28,28
    # Convolution -> 16,13,13
    h = PF.convolution(x, 16, (16, 16), (0, 0), name='Convolution')
    # ReLU
    h = F.relu(h, True)
    # MaxPooling -> 16,3,3
    h = F.max_pooling(h, (4, 4), (4, 4))
    # Affine_2 -> 10
    h = PF.affine(h, (10, ), name='Affine_2')
    # Softmax
    h = F.softmax(h)
    # CategoricalCrossEntropy -> 1
    #h = F.categorical_cross_entropy(h, y)
    return h

def add_margin(pil_img, top, right, bottom, left, color):
    width, height = pil_img.size
    new_width = width + right + left
    new_height = height + top + bottom
    result = Image.new(pil_img.mode, (new_width, new_height), color)
    result.paste(pil_img, (left, top))
    return result

def get_degree(img):
    l_img = img.copy()
    edges = cv2.Canny(img, 50, 150, apertureSize = 3)
    minLineLength = 100
    maxLineGap = 30
    
    point = []
    lines = cv2.HoughLines(edges, 1, np.pi / 180, 100)
    for line in lines:
        for rho, theta in line:
            a = np.cos(theta)
            b = np.sin(theta)
            x0 = a * rho
            y0 = b * rho
            x1 = int(x0 + 0 * (-b))
            y1 = int(y0 + 0 * (a))
            x2 = int(x0 - 550 * (-b))
            y2 = int(y0 - 550 * (a))
            
            slope = math.degrees(math.atan2((y2 - y1), (x2 - x1)))
            if -45 < slope < 45:
                point.append(slope)
    
    waste = point.pop(0)
    point = np.array(point)
    
    return np.sum(point) / len(point)

def run(template, source):
    if type(source) != list:
        source = [source]
    
    template = np.float32(cv2.imread(template, 0))
    
    rows, cols = template.shape
    
    for i in range(len(source)):
        img = cv2.imread(source[i], 0)
        arg = get_degree(img)
        
        target = ndimage.rotate(img, arg)
        target = np.array(target)
        
        height = len(target) - len(template)
        width = len(target[0]) - len(template[0])
        
        for j in range(height):
            if j % 2 == 0:
                target = np.delete(target, 0, axis = 0)
            else:
                target = np.delete(target, len(target) - 1, axis = 0)
        
        for j in range(width):
            if j % 2 == 0:
                target = np.delete(target, 0, axis = 1)
            else:
                target = np.delete(target, len(target[0]) - 1, axis = 1)
        
        d, etc = cv2.phaseCorrelate(np.float32(target), template)
        dx, dy = d
        M = np.float32([[1, 0, dx],[0, 1, dy]])
        target = cv2.warpAffine(target, M, (cols,rows))
        
        im = Image.fromarray(target)
        
        for key in option.keys():
            im_crop = im.crop((option[key]['x1'], option[key]['y1'], option[key]['x2'], option[key]['y2']))
            im_crop = np.asarray(im_crop)
            im_crop.flags.writeable = True
            
            nn.clear_parameters()
            
            x = nn.Variable((1, 1, 28, 28))
            t = nn.Variable((1, 1))
            y = network(x, t, test = True)
            
            im_crop = np.round(im_crop)
            
            for j in range(len(im_crop)):
                for k in range(len(im_crop[j])):
                    im_crop[j][k] = 0 if 200 < im_crop[j][k] else 255 - im_crop[j][k]
            
            start = []
            end = []
            prev = 0
            imx = np.sum(im_crop, axis = 0)
            for j in range(len(imx)):
                imx[j] = 1 if 0 < imx[j] else 0
            
            for j in range(len(imx)):
                if j != 0:
                    if prev != imx[j]:
                        if prev:
                            end.append(j)
                        else:
                            start.append(j)
                        
                        prev = (prev - 1) ** 2
                else:
                    if 0 < imx[j]:
                        start.append(j)
                        prev = 1
            
            im_te = Image.fromarray(im_crop)
            
            im_te.convert('RGB').save(str(i) + key + '.png')
            
            nn.parameter.load_parameters('C:\\Users\\Daisuke Yamaguchi\\Desktop\\neural_network_console_120\\samples\\sample_dataset\\MNIST\\moji.files\\20181008_180741\\parameters.h5');
            
            if 1 < len(start) and 1 < len(end):
                output = []
                for j in range(len(start)):
                    im_t = im_crop[:, start[j]: end[j]]
                    while True:
                        if 0 < np.sum(im_t[0]):
                            break
                        im_t = np.delete(im_t, 0, axis = 0)
                    while True:
                        if 0 < np.sum(im_t[len(im_t) - 1]):
                            break
                        im_t = np.delete(im_t, len(im_t) - 1, axis = 0)
                    
                    height = len(im_t)
                    width = len(im_t[0])
                    if height < width:
                        for k in range(width - height):
                            if k % 2 == 0:
                                im_t = np.vstack((im_t, im_t[0] - im_t[0]))
                            else:
                                im_t = np.vstack((im_t[0] - im_t[0], im_t))
                    else:
                        for k in range(height - width):
                            if k % 2 == 0:
                                im_t = np.hstack((im_t, np.array([[0]] * len(im_t))))
                            else:
                                im_t = np.hstack((np.array([[0]] * len(im_t)), im_t))
                    
                    im_t = Image.fromarray(im_t).resize((20, 20))
                    im_t = add_margin(im_t, 4, 4, 4, 4, 0)
                    
                    x.d = np.array(im_t).reshape(1, 1, 28, 28) / 255
                    
                    y.forward()
                    
                    nums = np.array(y.d[0])
                    
                    index = np.argmax(nums)
                    output.append([index, nums[index]])
                
                print(output)

option = {
  'box1': {'x1': 56, 'y1': 47, 'x2': 270, 'y2': 113},
  'box2': {'x1': 191, 'y1': 169, 'x2': 405, 'y2': 235},
  'box3': {'x1': 455, 'y1': 278, 'x2': 564, 'y2': 343},
  'box4': {'x1': 258, 'y1': 420, 'x2': 563, 'y2': 486}
}

run('./template.png', ['./sample/data2.png', './sample/data3.png'])






