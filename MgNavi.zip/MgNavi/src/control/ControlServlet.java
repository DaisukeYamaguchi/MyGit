package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Manager;

public class ControlServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doProcess(request, response);
	}

	public void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");

		String page = (String) request.getParameter("page");

		Manager mg = new Manager();
		String data = (String) request.getParameter("data");

		if ("trainingData".equals(page)) {
			if (data != null) {
				mg.setTrainData(data);
				request.setAttribute("trStat", "complete");
				request.setAttribute("tab", "tab1");
			}
		}else if("synonym".equals(page)) {
			if (data != null) {
				mg.setSynonymData(data);
				request.setAttribute("rpStat", "complete");
				request.setAttribute("tab", "tab2");
			}
		}else{
			request.setAttribute("tab", "tab1");
		}

		String[][] trainData = mg.getTrainData();
		String[][] synonymData = mg.getSynonymData();

		request.setAttribute("trainData", trainData);
		request.setAttribute("synonymData", synonymData);

		RequestDispatcher dispatch = request.getRequestDispatcher("Main.jsp");

		dispatch.forward(request, response);
	}

}
