# -*- coding: utf-8 -*
import falcon, json, chat

#クラスを作成し処理を記述する
class ChatResource(object):
    #GETメソッド
    def on_get(self, req, resp):
        
        request = req.params['request']
        
        response = chat.run(request)
        
        #メッセージをjson形式で返す
        resp.body = json.dumps(response, ensure_ascii=False).encode("utf-8")

#appインスタンス作成
app = falcon.API()
#エンドポイントとクラスを結びつける
app.add_route("/chat", ChatResource())

if __name__ == "__main__":
    #サーバーを起動する
    from wsgiref import simple_server
    httpd = simple_server.make_server("", 3000, app)
    print('server listening...')
    httpd.serve_forever()

