# -*- coding: utf-8 -*
import os, random, pickle

def run(request):
    
    response = None
    
    if os.path.exists('../session/context.pkl'):
        with open('../session/context.pkl', 'rb') as f:
            context = pickle.load(f)
    else:
        context = {'check': {1: '-', 2: '-', 3: '-', 4: '-', 5:'-', 6: '-', 7: '-', 8: '-', 9: '-', 10: '-'}, 'status': 'send', 'target': None}
    
    data = []
    with open('../data/question.txt', 'r', encoding = 'utf8') as f:
        for line in f:
            data.append(line.rstrip('\n').split(','))
    
    question_dict = {}
    for item in data:
        question_dict[int(item[0])] = item[1]
    
    if context['status'] == 'receive':
        if request == 'はい':
            target = context['target']
            context['check'][target] = '○'
            context['status'] = 'send'
        elif request == 'いいえ':
            target = context['target']
            context['check'][target] = '×'
            context['status'] = 'send'
        else:
            response = '「はい」か「いいえ」で回答してください。' + question_dict[context['target']]
    
    if context['status'] == 'send':
        question_list = []
        for item in context['check'].items():
            if item[1] == '-':
                question_list.append(item[0])
        
        if question_list != []:
            target = random.choice(question_list)
            response = question_dict[target]
            context['target'] = target
            context['status'] = 'receive'
        else:
            response = context['check']
            os.remove('../session/context.pkl')
    
    with open('../session/context.pkl', 'wb') as f:
        pickle.dump(context, f)
    
    print(context)
    
    return response

