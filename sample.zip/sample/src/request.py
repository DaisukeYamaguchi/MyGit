import json
import requests

url = 'http://localhost:3000/chat'

query = {
            'request': 'はい'
        }

r = requests.get(url, params=query)

print(json.dumps(r.json(), sort_keys=True, indent=2, ensure_ascii=False))

