var express = require('express');
var router = express.Router();
var models = [];
var io = require('socket.io-client');
var socket = io('http://localhost:3001');
socket.on('connect', function(){
  socket.emit('push', 'connected.');
});

/* GET users listing. */
router.get('/pusher', function(req, res, next) {
  socket.emit('push', 'https://www.hotpepper.jp/strJ001009957/');
  res.send('complete.')
});

module.exports = router;
