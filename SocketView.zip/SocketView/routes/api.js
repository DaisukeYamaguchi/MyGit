var express = require('express');
var router = express.Router();
var request = require("request");
var io = require('socket.io-client');
var socket = io('http://localhost:3001');
socket.on('connect', function(){
  socket.emit('push', 'connected.');
});

/* GET users listing. */
router.get('/pusher', function(req, res, next) {
  //SHUGAR MARKET �����V�_�X
  request.get({
    url: 'http://webservice.recruit.co.jp/hotpepper/shop/v1',
    qs: {
      key: '41516a925082e9cb',
      format: 'json',
      keyword: req.query.name
    }
  }, function (error, response, response) {
    response = JSON.parse(response)
    socket.emit('push', response.results.shop[0].urls.pc);
    //socket.emit('push', 'https://yokanavi.com/');
    res.send('complete.')
  });
});

module.exports = router;

