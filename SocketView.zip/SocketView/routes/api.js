var express = require('express');
var router = express.Router();
var request = require("request");
var io = require('socket.io-client');
var socket = io('http://localhost:3001');
var DiscoveryV1 = require('watson-developer-cloud/discovery/v1');
socket.on('connect', function(){
  socket.emit('push', 'connected.');
});

/* GET users listing. */
router.get('/pusher', function(req, res, next) {
  var discovery = new DiscoveryV1({
    username: 'fc530f1e-c276-4b2d-855a-f4c7eb9c8668',
    password: '5ijLLyGfHcKa',
    version: '2018-03-05'
  });
  
  var params = {
    environment_id: 'b17295ee-33cf-400e-876b-d0ac4c5082bf',
    collection_id: '3f45f6e9-196f-4715-9aac-5986bff5201e',
    natural_language_query: req.query.sentence,
    count: 5
  }
  
  discovery.query(params, function(err, data) {
    if(err){
      throw err;
    }
    socket.emit('push', data.results);
    res.send('complete.');
  });
});

router.get('/paging', function(req, res, next) {
  request.get({
    url: 'http://webservice.recruit.co.jp/hotpepper/shop/v1',
    qs: {
      key: '41516a925082e9cb',
      format: 'json',
      keyword: req.query.name
    }
  }, function (error, response, response) {
    response = JSON.parse(response)
    try{
      res.send(response.results.shop[0].urls.pc);
    }catch(e){
      res.send('');
    }
  });
});

module.exports = router;

