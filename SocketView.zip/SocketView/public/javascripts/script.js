$(function(){
  var socket = io.connect('ws://localhost:3001', {transports: ['websocket']});
  
  socket.on('connect', function () {
    //socket.emit('add:member', {room: info.room, user: info.user});
  });
  
  socket.on('push', function (data) {
    $('.contentFrame').attr('src', data)
  });
})

