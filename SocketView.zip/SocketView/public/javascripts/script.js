$(function(){
  var socket = io.connect('ws://localhost:3001', {transports: ['websocket']});
  
  socket.on('connect', function () {
    //socket.emit('add:member', {room: info.room, user: info.user});
  });
  
  socket.on('push', function (data) {
    $('.menu').empty();
    for(var i=0 ; i<data.length ; i++){
      $('.menu').append('<div class="item"><div class="symbol">' + (i + 1) + '</div><div class="label">' + data[i].title + '<br>' + data[i].area + '</div><div class="ring"></div></div>')
    }
    
    setTimeout(function(){
      getUrl(data[0].title)
    }, 0);
    
    setTimeout(function(){
      $('.ring').eq(0).css('animation', 'pulsate 0.2s ease-out');
      $('.label').eq(0).css('background', 'rgb(245, 169, 188)');
      $('.symbol').eq(0).css('color', 'rgb(245, 169, 188)');
      setTimeout(function(){
        $('.ring').eq(0).css('animation','');
      }, 200);
    }, 2000);
    
    console.log('最もおすすめできるお店は、' + data[0].title +  'です。' + data[0].voice)
    
    for(var i = 0;i<$('.item').length;i++){
      $('.item').eq(i).css('animation', 'anim 0.7s ease-out forwards');
      $('.item').eq(i).css('animation-delay', (i * 0.3) + 's');
    }
  });
  
  $(document).on('click', '.label', function(){
    $('.label').css('background', 'deepskyblue');
    $('.symbol').css('color', 'deepskyblue');
    setTimeout($.proxy(function(){
      getUrl($(this).html().split('<br>')[0])
    }, this), 0);
    $(this).parent().find('.ring').css('animation', 'pulsate 0.2s ease-out');
    $(this).css('background', 'rgb(245, 169, 188)');
    $(this).parent().find('.symbol').css('color', 'rgb(245, 169, 188)');
    setTimeout($.proxy(function(){
      $(this).parent().find('.ring').css('animation','');
    }, this), 200);
  })
  
  function getUrl(name){
    $('.contentFrame').fadeOut('fast');
    fetch('http://localhost:3000/api/paging?name=' + name, {mode: 'cors'}).then(function(response) {
      return response.text();
    }).then(function(text){
      $('.contentFrame').attr('src', text);
      $('.contentFrame').on('load', function(){
        $('.contentFrame').fadeIn('slow');
      })
    });
  }
})

