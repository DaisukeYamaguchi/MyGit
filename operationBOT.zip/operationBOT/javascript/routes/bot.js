var express = require('express');
var router = express.Router();
var io = require('socket.io-client');

/* GET home page. */
router.get('/talk', function(req, res, next) {
  var socket = io('http://localhost:3001');
  req.query.room = 'test';
  req.query.user = 'bot';
  socket.data = req.query;
  socket.on('connect', function () {
    socket.emit('talk', req.query);
  });
  res.send('');
});

module.exports = router;
