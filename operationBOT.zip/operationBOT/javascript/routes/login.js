var express = require('express');
var router = express.Router();

router.get('/', function(req, res, next) {
  res.render('login', {title: 'Chat'});
});

router.post('/', function(req, res, next) {
  res.render('chat', {title: 'Chat', username: JSON.stringify(req.body.username)});
});

module.exports = router;
