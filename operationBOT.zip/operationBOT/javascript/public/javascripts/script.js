/*
const lang = {
  'ja': {'stt': 'ja-JP', 'tts': 'Google 日本語'},
  'en': {'stt': 'en-US', 'tts': 'Google US English'},
  'zh': {'stt': 'cmn-Hans-CN', 'tts': 'Google 普通话（中国大陆）'},
  'es': {'stt': 'es-ES', 'tts': 'Google español'},
  'ko': {'stt': 'ko-KR', 'tts': 'Google 한국의'}
}

(index):34 Microsoft Haruka Desktop - Japanese
(index):34 Microsoft Zira Desktop - English (United States)
(index):34 Google Deutsch
(index):34 Google US English
(index):34 Google UK English Female
(index):34 Google UK English Male
(index):34 Google español
(index):34 Google español de Estados Unidos
(index):34 Google français
(index):34 Google हिन्दी
(index):34 Google Bahasa Indonesia
(index):34 Google italiano
(index):34 Google 日本語
(index):34 Google 한국의
(index):34 Google Nederlands
(index):34 Google polski
(index):34 Google português do Brasil
(index):34 Google русский
(index):34 Google 普通话（中国大陆）
(index):34 Google 粤語（香港）
(index):34 Google 國語（臺灣）

// 音声認識ツールを初期化
var recognition = new webkitSpeechRecognition();
recognition.lang = lang[info.lang]['stt'];
recognition.interimResults = true;
recognition.continuous = true;
*/

$(function(){
/*
  // 音声認識を制御
  recognition.onresult = function(event){
    var results = event.results;
    for (var i = event.resultIndex; i<results.length; i++){
      // 無音が続いたら、認識結果を読み上げる
      if(!results[i].isFinal){
        $('.request').val(results[i][0].transcript);
      }else{
        sendMessage();
      }
    }
  }
  
  // 音声読み上げを制御
  function speak(msg){
    var voices = speechSynthesis.getVoices();
    var uttr = new SpeechSynthesisUtterance(msg);
    voices.forEach(function(v, i){
      if(v.name == lang[info.lang]['tts']){
        uttr.voice = v;
      }
    });
    speechSynthesis.cancel();
    speechSynthesis.speak(uttr);
  }
*/
  $(document).on('keyup', '.request', function(){
    if($('.request').val() == ''){
      $('.text').hide();
      $('.mic').css('display', 'inline-block');
    }else{
      $('.mic').hide();
      $('.text').css('display', 'inline-block');
    }
  });

  $(document).on('click', '.submit.text', function(){
    if($('.request').val()){
      socket.emit('talk', {room: room, user: user, message: $('.request').val()});
      $('.request').val('');
      $('.text').hide();
      $('.mic').css('display', 'inline-block');
    }
  });

  $(document).on('click', '.mic', function(){
    if($(this).attr('class') == 'mic' && $(this).attr('src') == './images/mic_on.png'){
      recognition.start();
      $(this).attr('src', './images/mic_off.png');
    }else if($(this).attr('class') == 'mic' && $(this).attr('src') == './images/mic_off.png'){
      recognition.stop();
      $(this).attr('src', './images/mic_on.png');
    }
  });

  function putMessage(response){
    console.log(response)
    var p = response.user == user ? $('<p>', {class: 'chat-talk mytalk'}) : $('<p>', {class: 'chat-talk'});
    var div = $('<div>', {class: 'talk-content'});
    div.append($('<span>').css('padding', '0px 10px').html(response.message));
    if(response.content){
      response.content = JSON.parse(response.content);
      if(response.content.type == 'progress'){
        div.append($('<progress>', {value: response.content.value}));
        $('.request').prop('disabled', true);
        if(response.content.value == 1){
          $('.request').prop('disabled', false);
        }
      }
    }
    p.append(div);
    if(response.mode == 'overwrite'){
      $('.chat-talk:last').remove();
    }
    $('.chat-frame').append(p);
    $('.messageDiv').scrollTop($('.messageDiv')[0].scrollHeight);
  }

  var socket = io.connect('ws://localhost:3001', {transports: ['websocket']});

  socket.on('connect', function (){
    var id = socket.io.engine.id;
    socket.emit('welcome', {room: room, user: user});
  });

  socket.on('talk', function (data) {
    for(var i=0 ; i<data.length ; i++){
      putMessage(data[i])
    }
  });
})

/*
68
114
196
*/

