var express = require('express');
var router = express.Router();

var fs = require('fs');

/* GET users listing. */
router.get('/profile', function(req, res, next) {
  fs.readdir('../resource/' + req.query.environment_id + '/profile', function(err, files){
    if(!err){
      for(var i=0 ; i<files.length ; i++){
        files[i] = files[i].replace('.json', '');
      }
      res.send(files);
    }
  });
});

module.exports = router;
