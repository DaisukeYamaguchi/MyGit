var express = require('express');
var router = express.Router();

var fs = require('fs');

/* GET users listing. */
router.get('/lineup', function(req, res, next) {
  fs.readdir('../resource/' + req.query.environment_id + '/profile', function(err, files){
    if(!err){
      for(var i=0 ; i<files.length ; i++){
        files[i] = files[i].replace('.json', '');
      }
      res.send(files);
    }
  });
});

/* GET users listing. */
router.get('/profile', function(req, res, next) {
  fs.readFile('../resource/' + req.query.environment_id + '/profile/' + req.query.user_id + '.json', function(err, json){
    if(!err){
      json = JSON.parse(json);
      res.send(json);
    }
  });
});

/* GET users listing. */
router.get('/pi', function(req, res, next) {
  fs.readFile('../resource/' + req.query.environment_id + '/pi_json/' + req.query.user_id + '.json', function(err, json){
    if(!err){
      json = JSON.parse(json);
      res.send(json);
    }
  });
});

module.exports = router;
