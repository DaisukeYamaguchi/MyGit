$('#body').append($('<div>', {cass: 'profile'}).css({height: '100%', width: '100%'})
.append($('<div>', {cass: 'info'}).css({height: 'calc(100% - 20px)', width: 'calc(40% - 20px)', margin: '10px', float: 'left', background: '#444444'}))
.append($('<div>', {cass: 'status'}).css({height: 'calc(100% - 20px)', width: 'calc(60% - 20px)', margin: '10px', float: 'right', background: '#444444'})));


$.ajax({
  url:'/api/profile',
  type:'GET',
  data:{
    environment_id: 'test-0000',
    user_id: 'bcc13390'
  }
})
.done(function(data){
  console.log($('#body').find('.profile').html())
  $('#body .profile .info').append($('<div>').append($('<span>').html('����')).append($('<input>').val('test')));
})
.fail(function(data){
})
.always(function(data){
});
