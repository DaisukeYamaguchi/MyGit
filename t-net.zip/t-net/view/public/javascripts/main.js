$(function(){
  $.ajax({
    url:'/api/profile',
    type:'GET',
    data:{
      environment_id: 'test-0000'
    }
  })
  .done(function(data){
    for(var i=0 ; i<data.length ; i++){
      var item = $('<div>', {class: 'item'});
      item.append($('<span>').html(data[i]));
      item.append($('<input>', {type: 'checkbox'}).prop('checked', true));
      $('#filter').append(item);
    }
  })
  .fail(function(data){
  })
  .always(function(data){
  })
})