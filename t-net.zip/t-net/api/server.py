# -*- coding: utf-8 -*
import json
import falcon
import urllib.parse
import science as sci

#クラスを作成し処理を記述する
class OperationResource(object):
    #GETメソッド
    def on_get(self, req, resp):
        response = None
        if 'environment_id' in req.params.keys():
            response = sci.run(req.params['environment_id'])
        
        #メッセージをjson形式で返す
        resp.body = json.dumps(response)

class CORSMiddleware:
    def process_request(self, req, resp):
        resp.set_header('Access-Control-Allow-Origin', '*')

#appインスタンス作成
app = falcon.API(middleware=[CORSMiddleware()])
#エンドポイントとクラスを結びつける
app.add_route("/pca/v1", OperationResource())

if __name__ == "__main__":
    #サーバーを起動する
    from wsgiref import simple_server
    httpd = simple_server.make_server("", 14000, app)
    print('server listening...')
    httpd.serve_forever()

