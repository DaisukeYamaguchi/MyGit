import os, json
import numpy as np
import pprint
from sklearn.decomposition import PCA

def run(environment_id):
    data = []
    member = []
    for file in os.listdir('../resource/' + environment_id + '/pi_json'):
        f = open('../resource/' + environment_id + '/pi_json/' + file, 'r')
        json_data = json.load(f)
        
        row = []
        member.append(file)
        for i in range(len(json_data['personality'])):
            row.append(json_data['personality'][i]['percentile'])
        
        data.append(row)
    
    pca = PCA(n_components=3)
    pca.fit(data)
    data_pca = pca.transform(data)
    data_pca = data_pca * 5
    data_pca = data_pca.tolist()
    
    response = {}
    for i in range(len(data_pca)):
      response[member[i].replace('.json', '')] = data_pca[i]
    
    return response

