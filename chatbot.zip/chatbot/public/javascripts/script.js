$(document).on('keyup', '.request', function(){
  if($('.request').val() == ''){
    $('.text').hide();
    $('.mic').css('display', 'inline-block');
  }else{
    $('.mic').hide();
    $('.text').css('display', 'inline-block');
  }
});

$(document).on('click', '.submit.text', function(){
  $('.request').attr('readonly', true);
  var msg = $('.request').val();
  putUsrMsg(msg)
  putBotMsg(msg)
  $('.request').val('');
  $('.text').hide();
  $('.mic').css('display', 'inline-block');
});

function putBotMsg(msg){
  var p = $('<p>', {class: 'chat-talk load'})
  var span = $('<span>', {class: 'talk-icon'}).append($('<img>', {src: './images/submit.png', alt: 'tartgeticon'}));
  p.append(span);
  p.append($('<span>', {class: 'talk-content load'}).html('<div class="loading"><div></div><div></div><div></div></div>'));
  $('.chat-frame').append(p);
  $('.messageDiv').scrollTop($('.messageDiv')[0].scrollHeight);
  setTimeout(function(){
    fetch('http://localhost:14000/operate', {mode: 'cors'}).then(function(response) {
      return response.json();
    }).then(function(json){
      $('.chat-talk.load').remove();
      var p = $('<p>', {class: 'chat-talk'})
      var span = $('<span>', {class: 'talk-icon'}).append($('<img>', {src: './images/submit.png', alt: 'tartgeticon'}));
      p.append(span);
      p.append($('<span>', {class: 'talk-content'}).html(json['message']));
      $('.chat-frame').append(p);
      $('.messageDiv').scrollTop($('.messageDiv')[0].scrollHeight);
      $('.request').attr('readonly', false);
    });
  }, 1000);
}

function putUsrMsg(msg){
  var p = $('<p>', {class: 'chat-talk mytalk'})
  p.append($('<span>', {class: 'talk-content'}).html(msg));
  $('.chat-frame').append(p);
  $('.messageDiv').scrollTop($('.messageDiv')[0].scrollHeight);
}

/*
68
114
196
*/
