# -*- coding: utf-8 -*-
import os, sys
import numpy as np

cd = os.path.dirname(os.path.abspath(__file__)) + '/..'

def interval(when):
    date = np.array([[False] * 7] * 36)
    time = np.array([[False] * 7] * 36)
    
    if when['date'] == None:
        date = None
    else:
        for i in range(when['date']['from'], when['date']['to']+1):
            date[:,i] = True
    
    if when['date'] == None:
        time = None
    else:
        for i in range(when['time']['from'], when['time']['to']):
            time[i,:] = True
    
    if date is None:
        if time is None:
            return True
        else:
            return time
    else:
        if time is None:
            return data
        else:
            return date * time

def reservation(room):
    reservation = {}
    
    if room == None:
        room = os.listdir(cd + '/data/room')
        for i in range(len(room)):
            room[i] = room[i].split('.')[0]
    
    for item in room:
        file = []
        for line in open(cd + '/data/room/'+item+'.csv', 'r', encoding = 'utf8'):
            file.append(line.rstrip('\n').split(','))
        
        reservation[item] = np.array(file)
        reservation[item] = reservation[item] == 'TRUE'
    
    return reservation

def schedule(member):
    schedule = {}
    
    all_free = None
    if member == None:
        all_free = True
    else:
        for item in member:
            file = []
            for line in open(cd + '/data/member/'+item+'.csv', 'r', encoding = 'utf8'):
                file.append(line.rstrip('\n').split(','))
            schedule[item] = np.array(file)
            schedule[item] = schedule[item] == 'TRUE'
        
        all_free = schedule[member[0]]
        for i in range(1, len(schedule)):
            all_free = all_free * schedule[member[i]]
    
    return all_free

def tXmXr(time, member, room):
    scope_plate = time * member
    for item in room.keys():
        room[item] = room[item] * scope_plate
        if 0 == np.sum(room[item]):
            room[item] = None
    
    return room

def get_workable(room):
    import datetime
    
    week = ['月', '火', '水', '木', '金', '土', '日']
    workable = []
    for item in room.keys():
        if room[item] is not None:
            for i in range(len(room[item][0])):
                temp = {'place': '', 'day': 0, 'from': 0, 'to': 0, 'hold': 0}
                temp['place'] = item
                status = False
                for j in range(len(room[item])):
                    if status == False:
                        if room[item][j][i] == True:
                            temp['day'] = i
                            temp['from'] = j
                            status = True
                    else:
                        if room[item][j][i] == False:
                            temp['to'] = j
                            temp['hold'] = (temp['to'] - temp['from']) / 4
                            temp['start'] = str(int(temp['from'] / 4 + 9)) + ':' + str(int((temp['from'] - (temp['from'] / 4) * 4)) * 15).zfill(2)
                            temp['end'] = str(int(temp['to'] / 4 + 9)) + ':' + str(int((temp['to'] - (temp['to'] / 4) * 4)) * 15).zfill(2)
                            today = datetime.date.today()
                            today = today + datetime.timedelta(days=temp['day'])
                            temp['date'] = str(today.month)+'月'+str(today.day)+'日（'+week[today.weekday()]+'）'
                            workable.append(temp)
                            status = False
    
    return workable

