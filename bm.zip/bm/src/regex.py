# -*- coding: utf-8 -*
import os

cd = os.path.dirname(os.path.abspath(__file__)) + '/..'

def k2a(kstring, sep=False):
    import re
    
    tt_ksuji = str.maketrans('一二三四五六七八九〇壱弐参', '1234567890123')
    
    re_suji = re.compile(r'[十拾百千万億兆\d]+')
    re_kunit = re.compile(r'[十拾百千]|\d+')
    re_manshin = re.compile(r'[万億兆]|[^万億兆]+')
    
    TRANSUNIT = {'十': 10,
                 '拾': 10,
                 '百': 100,
                 '千': 1000}
    TRANSMANS = {'万': 10000,
                 '億': 100000000,
                 '兆': 1000000000000}
    
    def _transvalue(sj, re_obj=re_kunit, transdic=TRANSUNIT):
        unit = 1
        result = 0
        for piece in reversed(re_obj.findall(sj)):
            if piece in transdic:
                if unit > 1:
                    result += unit
                unit = transdic[piece]
            else:
                val = int(piece) if piece.isdecimal() else _transvalue(piece)
                result += val * unit
                unit = 1
        
        if unit > 1:
            result += unit
        
        return result
    
    transuji = kstring.translate(tt_ksuji)
    for suji in sorted(set(re_suji.findall(transuji)), key=lambda s: len(s),
                           reverse=True):
        if not suji.isdecimal():
            arabic = _transvalue(suji, re_manshin, TRANSMANS)
            arabic = '{:,}'.format(arabic) if sep else str(arabic)
            transuji = transuji.replace(suji, arabic)
    
    return transuji

def z2h(sentence):
    import zenhan
    
    s_hankaku = zenhan.z2h(sentence, mode=2)
    return s_hankaku

def h2z(sentence):
    import zenhan
    
    s_zenkaku = zenhan.h2z(sentence, mode=2)
    return s_zenkaku

def time_trans(sentence):
    import re
    
    match = re.findall('[0-9]{1,2}：[0-9]{0,2}', sentence)
    for item in match:
        sentence = sentence.replace(item, item.replace('：', '時') + '分')
    
    match = re.findall('[0-9]{1,2}:[0-9]{0,2}', sentence)
    for item in match:
        sentence = sentence.replace(item, item.replace(':', '時') + '分')
    
    match = re.findall('[0-9]{1,2}／[0-9]{0,2}', sentence)
    for item in match:
        sentence = sentence.replace(item, item.replace('／', '月') + '日')
    
    match = re.findall('[0-9]{1,2}/[0-9]{0,2}', sentence)
    for item in match:
        sentence = sentence.replace(item, item.replace('/', '月') + '日')
    
    return sentence

def date_extract(sentence):
    import re, datetime
    
    now = datetime.date.today()
    
    date = {}
    date['from'] = 0
    date['to'] = 6
    
    if '今日' in sentence:
        date['from'] = date['to'] = 0
    
    if '明日' in sentence:
        date['from'] = date['to'] = 1
    
    if '明後日' in sentence:
        date['from'] = date['to'] = 2
    
    if '来週' in sentence:
        diff = 7 - now.weekday()
        date['from'] = diff
        date['to'] = diff + 6
    
    if '再来週' in sentence:
        diff = 7 - now.weekday()
        date['from'] = diff + 7
        date['to'] = diff + 13
    
    if '月曜日' in sentence:
        if 0 < now.weekday():
            if '来週' not in sentence and '再来週' not in sentence:
                date['from'] = date['to'] = date['from'] + 7 - now.weekday()
            else:
                date['from'] = date['to'] = date['from']
        else:
            date['from'] = date['to'] = date['from'] + 0 + 7 - now.weekday()
        
        if '月曜日から' in sentence:
            date['to'] = 6
    
    if '火曜日' in sentence:
        if 1 < now.weekday():
            if '来週' not in sentence and '再来週' not in sentence:
                date['from'] = date['to'] = date['from'] + 8 - now.weekday()
            else:
                date['from'] = date['to'] = date['from'] + 1
        else:
            date['from'] = date['to'] = date['from'] + 1 + 7 - now.weekday()
        
        if '火曜日から' in sentence:
            date['to'] = 7
    
    if '水曜日' in sentence:
        if 2 < now.weekday():
            if '来週' not in sentence and '再来週' not in sentence:
                date['from'] = date['to'] = date['from'] + 9 - now.weekday()
            else:
                date['from'] = date['to'] = date['from'] + 2
        else:
            date['from'] = date['to'] = date['from'] + 2 + 7 - now.weekday()
        
        if '水曜日から' in sentence:
            date['to'] = 7
    
    if '木曜日' in sentence:
        if 3 < now.weekday():
            if '来週' not in sentence and '再来週' not in sentence:
                date['from'] = date['to'] = date['from'] + 10 - now.weekday()
            else:
                date['from'] = date['to'] = date['from'] + 3
        else:
            date['from'] = date['to'] = date['from'] + 3 + 7 - now.weekday()
        
        if '木曜日から' in sentence:
            date['to'] = 7
    
    if '金曜日' in sentence:
        if 4 < now.weekday():
            if '来週' not in sentence and '再来週' not in sentence:
                date['from'] = date['to'] = date['from'] + 11 - now.weekday()
            else:
                date['from'] = date['to'] = date['from'] + 4
        else:
            date['from'] = date['to'] = date['from'] + 4 + 7 - now.weekday()
        
        if '金曜日から' in sentence:
            date['to'] = 7
    
    if '土曜日' in sentence:
        if 5 < now.weekday():
            if '来週' not in sentence and '再来週' not in sentence:
                date['from'] = date['to'] = date['from'] + 12 - now.weekday()
            else:
                date['from'] = date['to'] = date['from'] + 5
        else:
            date['from'] = date['to'] = date['from'] + 5 + 7 - now.weekday()
        
        if '土曜日から' in sentence:
            date['to'] = 7
    
    if '日曜日' in sentence:
        if 5 < now.weekday():
            if '来週' not in sentence and '再来週' not in sentence:
                date['from'] = date['to'] = date['from'] + 13 - now.weekday()
            else:
                date['from'] = date['to'] = date['from'] + 6
        else:
            date['from'] = date['to'] = date['from'] + 6 + 7 - now.weekday()
        
        if '日曜日から' in sentence:
            date['to'] = 7
    
    match = re.findall('([0-9]{1,2})月([0-9]{0,2})日の', sentence)
    if 0 < len(match):
        temp = datetime.date(now.year, int(match[0][0]), int(match[0][1]))
        date['from'] = date['to'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})月([0-9]{0,2})日に', sentence)
    if 0 < len(match):
        temp = datetime.date(now.year, int(match[0][0]), int(match[0][1]))
        date['from'] = date['to'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})月([0-9]{0,2})日で', sentence)
    if 0 < len(match):
        temp = datetime.date(now.year, int(match[0][0]), int(match[0][1]))
        date['from'] = date['to'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})日の', sentence)
    if 0 < len(match):
        temp = ''
        if int(match[0][0]) < now.day:
            temp = datetime.date(now.year, now.month+1, int(match[0][0]))
        else:
            temp = datetime.date(now.year, now.month, int(match[0][0]))
        
        date['from'] = date['to'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})日に', sentence)
    if 0 < len(match):
        temp = ''
        if int(match[0][0]) < now.day:
            temp = datetime.date(now.year, now.month+1, int(match[0][0]))
        else:
            temp = datetime.date(now.year, now.month, int(match[0][0]))
        
        date['from'] = date['to'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})日で', sentence)
    if 0 < len(match):
        temp = ''
        if int(match[0][0]) < now.day:
            temp = datetime.date(now.year, now.month+1, int(match[0][0]))
        else:
            temp = datetime.date(now.year, now.month, int(match[0][0]))
        
        date['from'] = date['to'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})月([0-9]{0,2})日から', sentence)
    if 0 < len(match):
        temp = datetime.date(now.year, int(match[0][0]), int(match[0][1]))
        date['from'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})月([0-9]{0,2})日～', sentence)
    if 0 < len(match):
        temp = datetime.date(now.year, int(match[0][0]), int(match[0][1]))
        date['from'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})月([0-9]{0,2})日~', sentence)
    if 0 < len(match):
        temp = datetime.date(now.year, int(match[0][0]), int(match[0][1]))
        date['from'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})月([0-9]{0,2})日以降', sentence)
    if 0 < len(match):
        temp = datetime.date(now.year, int(match[0][0]), int(match[0][1]))
        date['from'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})日から', sentence)
    if 0 < len(match):
        temp = ''
        if int(match[0][0]) < now.day:
            temp = datetime.date(now.year, now.month+1, int(match[0][0]))
        else:
            temp = datetime.date(now.year, now.month, int(match[0][0]))
        
        date['from'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})日～', sentence)
    if 0 < len(match):
        temp = ''
        if int(match[0][0]) < now.day:
            temp = datetime.date(now.year, now.month+1, int(match[0][0]))
        else:
            temp = datetime.date(now.year, now.month, int(match[0][0]))
        
        date['from'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})日~', sentence)
    if 0 < len(match):
        temp = ''
        if int(match[0][0]) < now.day:
            temp = datetime.date(now.year, now.month+1, int(match[0][0]))
        else:
            temp = datetime.date(now.year, now.month, int(match[0][0]))
        
        date['from'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})日以降', sentence)
    if 0 < len(match):
        temp = ''
        if int(match[0][0]) < now.day:
            temp = datetime.date(now.year, now.month+1, int(match[0][0]))
        else:
            temp = datetime.date(now.year, now.month, int(match[0][0]))
        
        date['from'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})日まで', sentence)
    if 0 < len(match):
        temp = ''
        if int(match[0][0]) < now.day:
            temp = datetime.date(now.year, now.month+1, int(match[0][0]))
        else:
            temp = datetime.date(now.year, now.month, int(match[0][0]))
        
        date['to'] = (temp - now).days
    
    match = re.findall('([0-9]{1,2})月([0-9]{0,2})日まで', sentence)
    if 0 < len(match):
        temp = datetime.date(now.year, int(match[0][0]), int(match[0][1]))
        date['to'] = (temp - now).days
    
    match = re.findall('から([0-9]{1,2})月([0-9]{0,2})日', sentence)
    if 0 < len(match):
        temp = datetime.date(now.year, int(match[0][0]), int(match[0][1]))
        date['to'] = (temp - now).days
    
    match = re.findall('～([0-9]{1,2})月([0-9]{0,2})日', sentence)
    if 0 < len(match):
        temp = datetime.date(now.year, int(match[0][0]), int(match[0][1]))
        date['to'] = (temp - now).days
    
    match = re.findall('~([0-9]{1,2})月([0-9]{0,2})日', sentence)
    if 0 < len(match):
        temp = datetime.date(now.year, int(match[0][0]), int(match[0][1]))
        date['to'] = (temp - now).days
    
    match = re.findall('から([0-9]{1,2})日', sentence)
    if 0 < len(match):
        temp = ''
        if int(match[0][0]) < now.day:
            temp = datetime.date(now.year, now.month+1, int(match[0][0]))
        else:
            temp = datetime.date(now.year, now.month, int(match[0][0]))
        
        date['to'] = (temp - now).days
    
    match = re.findall('～([0-9]{1,2})日', sentence)
    if 0 < len(match):
        temp = ''
        if int(match[0][0]) < now.day:
            temp = datetime.date(now.year, now.month+1, int(match[0][0]))
        else:
            temp = datetime.date(now.year, now.month, int(match[0][0]))
        
        date['to'] = (temp - now).days
    
    match = re.findall('~([0-9]{1,2})日', sentence)
    if 0 < len(match):
        temp = ''
        if int(match[0][0]) < now.day:
            temp = datetime.date(now.year, now.month+1, int(match[0][0]))
        else:
            temp = datetime.date(now.year, now.month, int(match[0][0]))
        
        date['to'] = (temp - now).days
    
    return date

def time_extract(sentence):
    import re
    
    time = {}
    time['from'] = {'hour': 9, 'minute': 0}
    time['to'] = {'hour': 18, 'minute': 0}
    
    if '昼' in sentence:
        time['from'] = {'hour': 11, 'minute': 0}
        time['to'] = {'hour': 14, 'minute': 0}
    
    if '午前中' in sentence or '昼前' in sentence:
        time['from'] = {'hour': 9, 'minute': 0}
        time['to'] = {'hour': 12, 'minute': 0}
    if '午後' in sentence or '昼以降' in sentence or '昼から' in sentence:
        time['from'] = {'hour': 13, 'minute': 0}
        time['to'] = {'hour': 18, 'minute': 0}
    
    match = re.findall('([0-9]{1,2})時に', sentence)
    if 0 < len(match):
        time['from'] = time['to'] = {'hour': int(match[0]), 'minute':0}
    
    match = re.findall('([0-9]{1,2})時で', sentence)
    if 0 < len(match):
        time['from'] = time['to'] = {'hour': int(match[0]), 'minute':0}
    
    match = re.findall('([0-9]{1,2})時の', sentence)
    if 0 < len(match):
        time['from'] = time['to'] = {'hour': int(match[0]), 'minute':0}
    
    match = re.findall('([0-9]{1,2})時([0-9]{0,2})分から', sentence)
    if 0 < len(match):
        time['from'] = {'hour': int(match[0][0]), 'minute':int(match[0][1])}
    
    match = re.findall('([0-9]{1,2})時([0-9]{0,2})分～', sentence)
    if 0 < len(match):
        time['from'] = {'hour': int(match[0][0]), 'minute':int(match[0][1])}
    
    match = re.findall('([0-9]{1,2})時([0-9]{0,2})分~', sentence)
    if 0 < len(match):
        time['from'] = {'hour': int(match[0][0]), 'minute':int(match[0][1])}
    
    match = re.findall('([0-9]{1,2})時から', sentence)
    if 0 < len(match):
        time['from'] = {'hour': int(match[0]), 'minute': 0}
    
    match = re.findall('([0-9]{1,2})時～', sentence)
    if 0 < len(match):
        time['from'] = {'hour': int(match[0]), 'minute': 0}
    
    match = re.findall('([0-9]{1,2})時~', sentence)
    if 0 < len(match):
        time['from'] = {'hour': int(match[0]), 'minute': 0}
    
    match = re.findall('から([0-9]{1,2})時([0-9]{0,2})分', sentence)
    if 0 < len(match):
        time['to'] = {'hour': int(match[0][0]), 'minute':int(match[0][1])}
    
    match = re.findall('～([0-9]{1,2})時([0-9]{0,2})分', sentence)
    if 0 < len(match):
        time['to'] = {'hour': int(match[0][0]), 'minute':int(match[0][1])}
    
    match = re.findall('~([0-9]{1,2})時([0-9]{0,2})分', sentence)
    if 0 < len(match):
        time['to'] = {'hour': int(match[0][0]), 'minute':int(match[0][1])}
    
    match = re.findall('から([0-9]{1,2})時', sentence)
    if 0 < len(match):
        time['to'] = {'hour': int(match[0]), 'minute': 0}
    
    match = re.findall('～([0-9]{1,2})時', sentence)
    if 0 < len(match):
        time['to'] = {'hour': int(match[0]), 'minute': 0}
    
    match = re.findall('~([0-9]{1,2})時', sentence)
    if 0 < len(match):
        time['to'] = {'hour': int(match[0]), 'minute': 0}
    
    time['from'] = int((time['from']['hour'] - 9) * 4 + time['from']['minute'] / 15)
    time['to'] = int((time['to']['hour'] - 9) * 4 + time['to']['minute'] / 15)
    
    return time

def get_plan(sentence):
    plan = {}
    plan['date'] = date_extract(sentence)
    plan['time'] = time_extract(sentence)
    
    return plan

