from texttable import Texttable

def create_table(data, mode=0):
    full = [["番号", "日付", "開始", "終了", "会議室"]]
    for item in data:
        full.append(item)
    
    table = Texttable()
    if mode == 0:
        table.set_cols_align(["c", "c", "c", "c", "c"])
        table.set_cols_valign(["m", "m", "m", "m", "m"])
    elif mode == 1:
        table.set_deco(Texttable.HEADER)
        table.set_cols_dtype(['t', 't', 't', 't', 't'])
        table.set_cols_align(["c", "c", "c", "c", "c"])
    
    table.add_rows(full)
    
    return table

