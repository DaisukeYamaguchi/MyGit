# -*- coding: utf-8 -*-
import sys, os
import regex, overlaid, language, pkl, table

#message = '明後日の14時から15時にA室でお願いします。山口さんと渡邊さんと木元君が来ます'
#message = 'A室でお願いします。山口さんと渡邊さんと木元君が来ます'
#message = '明後日の午後からA室でお願いします。山口さんと渡邊さんと木元君が来ます'
message = '山口さんと渡邊さんと木元君が'
#message = '11月3日の14時から15時で'
#message = '11月1日以降で'
#message = '11月1日から11月3日で'
#message = '11月1日から11月3日まで'
#message = '11月1日から'
#message = '3日の14時から18時で'
#message = '2日以降で'
#message = '1日から3日で'
#message = '2日から'
#message = '来週金曜日の13時から'
#message = '再来週日曜日の13時から'
#message = '明日の昼ぐらい'

cd = os.path.dirname(os.path.abspath(__file__)) + '/..'

if 1 < len(sys.argv):
    message = sys.argv[1]

message = language.text_trans(message)

session = {'when': None, 'where': None, 'who': None}

session['when'] = regex.get_plan(message)
session['who'], session['where'] = language.get_proper_noun(message)

if os.path.exists(cd + '/pickle/session.pkl'):
    pre_session = pkl.load(cd + '/pickle/session.pkl')
    if pre_session['when']['date'] is not None:
        session['when']['date'] = pre_session['when']['date']
        session['when']['time'] = pre_session['when']['time']
    if pre_session['when']['time'] is not None:
        session['when']['time'] = pre_session['when']['time']
    if pre_session['who'] is not None:
        session['who'] = pre_session['who']
    if pre_session['where'] is not None:
        session['where'] = pre_session['where']

pkl.dump(session, cd + '/pickle/session.pkl')

time = overlaid.interval(session['when'])
member = overlaid.schedule(session['who'])
room = overlaid.reservation(session['where'])



workable = overlaid.tXmXr(time, member, room)
candidate = overlaid.get_workable(workable)

reply = None
if candidate == []:
    reply = '空きが見つかりません。'
else:
    data = []
    for item in candidate:
        data.append([item['date'], item['start'], item['end'], item['place'], item['day'], item['from']])
    
    sorted(data, key=lambda x:(x[4], x[5]), reverse = False)
    
    for i in range(len(data)):
        data[i].pop(5)
        data[i].pop(4)
        data[i].insert(0, i + 1)
    
    result = table.create_table(data)
    reply = '上記の空き時間を確認しました。'
    print(result.draw())

print(reply)

