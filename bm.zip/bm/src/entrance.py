# -*- coding: utf-8 -*-
import sys, os
import regex, overlaid, language, pkl

#message = '明後日の14時から15時にA室でお願いします。山口さんと渡邊さんと木元君が来ます'
#message = 'A室でお願いします。山口さんと渡邊さんと木元君が来ます'
#message = '明後日の午後からA室でお願いします。山口さんと渡邊さんと木元君が来ます'
#message = '山口さんと渡邊さんと木元君が'
#message = '11月3日の14時から15時で'
#message = '11月1日以降で'
#message = '11月1日から11月3日で'
#message = '11月1日から11月3日まで'
#message = '11月1日から'
#message = '3日の14時から18時で'
#message = '2日以降で'
#message = '1日から3日で'
#message = '2日から'
#message = '来週金曜日の13時から'
#message = '再来週日曜日の13時から'
#message = '明日の昼ぐらい'

cd = os.path.dirname(os.path.abspath(__file__)) + '/..'

if 1 < len(sys.argv):
    message = sys.argv[1]

message = language.text_trans(message)

session = {'when': None, 'where': None, 'who': None}

session['when'] = regex.get_plan(message)
session['who'], session['where'] = language.get_proper_noun(message)

pkl.dump(session, cd + '/pickle/session.pkl')

time = overlaid.interval(session['when'])
member = overlaid.schedule(session['who'])
room = overlaid.reservation(session['where'])



workable = overlaid.tXmXr(time, member, room)
candidate = overlaid.get_workable(workable)

reply = None
if candidate == []:
    reply = '空きが見つかりません。'
else:
    reply = candidate

print(reply)

