# -*- coding: utf-8 -*
from janome.tokenizer import Tokenizer

def wakachi_nv(text):
    t = Tokenizer('../data/dict.csv')
    
    for i in range(len(text)):
        line = []
        tokens = t.tokenize(text[i])
        for token in tokens:
            if token.part_of_speech.split(',')[0] == '名詞' or token.part_of_speech.split(',')[0] == '動詞':
                if token.base_form != '*':
                    line.append(token.base_form)
        text[i] = ' '.join(line)
    return text

def text_trans(text):
    t = Tokenizer('../data/dict.csv')
    
    tokens = t.tokenize(text)
    text = ''
    for token in tokens:
        if token.part_of_speech.split(',')[0] != '記号':
            if token.part_of_speech.split(',')[1] == 'ユーザー定義' and token.part_of_speech.split(',')[2] == '時間':
                text = text + token.base_form
            else:
                text = text + token.surface
    
    return text

def get_proper_noun(sentence):
    from janome.tokenizer import Tokenizer
    
    t = Tokenizer('../data/dict.csv')
    tokens = t.tokenize(sentence)
    
    member = None
    room = None
    for token in tokens:
        if token.part_of_speech.split(',')[1] == 'ユーザー定義':
            if token.part_of_speech.split(',')[2] == '人名':
                if member == None:
                    member = []
                
                member.append(token.surface)
            elif token.part_of_speech.split(',')[2] == '場所':
                if room == None:
                    room = []
                
                room.append(token.surface)
    
    return member, room

