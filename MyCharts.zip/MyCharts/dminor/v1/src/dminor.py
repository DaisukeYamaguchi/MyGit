import numpy as np
from sklearn.model_selection import GridSearchCV
from sklearn.neighbors import KernelDensity

def kde(samples, range):
  x = eval('np.array(' + samples + ')')
  
  grid = GridSearchCV(KernelDensity(), {'bandwidth': eval('np.linspace' + range)}, cv=5)
  grid.fit(x.reshape(-1, 1))
  
  x_plot = eval('np.linspace' + range + '[:, np.newaxis]')
  label = eval('np.linspace' + range).tolist()
  value = np.exp(grid.best_estimator_.score_samples(x_plot)).tolist()
  
  response = {'kde': {'label': label, 'value': value}}
  
  return response


