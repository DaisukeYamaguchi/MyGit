(function(){
  function plotProbGraph(){
    var ideal = [71.9, 88.3, 96.4, 72.5, 79.2, 108.9, 88.7, 83.8, 89.5, 93.0, 100.0, 86.7, 71.6, 71.0, 90.2, 70.3, 80.5, 64.0, 86.3, 96.2, 79.2, 78.8, 68.6, 78.6, 90.8, 79.8, 82.5, 68.0, 95.4, 78.3, 74.7, 92.2, 77.2, 80.8, 94.1, 98.5, 86.7, 92.4, 85.1, 67.0, 101.4, 80.8, 79.2, 92.4, 87.5, 92.1, 81.1, 86.7, 97.8, 85.1, 86.2, 91.7, 82.2, 79.6, 79.8, 88.6, 83.5, 75.8, 100.0, 94.0, 68.8, 89.6, 87.2, 81.6, 85.3, 78.7, 77.6, 58.0, 86.3, 82.7, 86.2, 85.6, 83.5, 73.3, 90.1, 107.5, 72.8, 86.6, 83.5, 102.5, 86.2, 74.6, 81.1, 81.5, 82.2, 72.3, 93.0, 76.8, 76.4, 89.3, 74.8, 103.5, 65.4, 88.5, 97.6, 88.0, 86.5, 75.2, 75.1, 97.1]
    var reality = [82.5,38.2,76.5,51.3,67.1,100,95.0,39.4,51.6,62.9,74.9,78.3,49.7,51.0,72.5,67.8,69.8,53.0,63.7,67.3,51.8,77.1,50.5,72.8,94.5,59.7,85.6,67.3,79.0,46.3,71.3,100,67.6,55.5,57.1,79.3,86.2,66.9,89.0,89.5,46.4,47.7,100,84.3,68.2,78.1,45.2,44.3,49.8,73.5,94.7,85.4,54.2,60.1,40.7,82.5,100,75.5,58.5,65.1,61.5,67.2,46.2,74.4,34.6,35.0,56.3,78.0,66.7,66.5,75.9,84.1,70.4,83.4,57.3,45.7,77.3,67.3,80.0,81.4,16.0,63.4,27.4,65.1,68.2,85.7,85.6,78.1,59.4,60.4,65.9,90.3,31.4,27.2,57.9,74.6,75.7,69.2,82.8,52.4];
    var range = '(0, 100, 21)'
    var test = [4.8151244321614374e-33, 3.1862270711609744e-28, 7.756263157826029e-24, 6.946044156830654e-20, 2.2884455090765873e-16, 2.773908602998224e-13, 1.237368541566821e-10, 2.0330281836326723e-8, 0.0000012343376956565694, 0.000028039990012886795, 0.0002503627185970672, 0.0010515669071066171, 0.0030989841340194634, 0.007976369259032858, 0.016136174488091584, 0.025796701954012406, 0.03399293727909736, 0.03666445868590433, 0.031229542562239827, 0.021227856693926375, 0.012525127629154247]
    
    var url = 'http://localhost:14000/d-minor/v1/kde?';
    var query = {
      samples: JSON.stringify(reality),
      range: range
    }
    url = url + $.param(query);
    fetch(url, {mode: 'cors'}).then(function(response) {
      return response.json();
    }).then(function(json) {
      var type = 'line';
      var data = {
        labels: json.kde.label,
        datasets: [{
          label: '理想値',
          data: test,
          borderColor: 'rgba(115, 230, 172, 1)',
          backgroundColor: 'rgba(115, 230, 172, 0.2)'
        },
        {
          label: '実測値',
          data: json.kde.value,
          borderColor: 'rgba(255, 182, 193, 1)',
          backgroundColor: 'rgba(255, 182, 193, 0.2)'
        }]
      };
      var options = {
        scales: {
          xAxes: [{
            ticks: {
              callback: function(value, index, values){
                return value + '%';
              }
            }
          }],
          yAxes: [{
            ticks: {
              callback: function(value, index, values){
                return '';
              }
            }
          }]
        },
        legend: {
          position: 'right'
        }
      };
      var ctx = document.getElementById('my_chart1').getContext('2d');
      var myChart = new Chart(ctx, {
        type: type,
        data: data,
        options: options
      })
    });
  }
  
  function plotSatisfyGraph(){
    var type = 'doughnut';
    var data = {
      labels: ['参考になった', '参考にならなかった', '未回答'],
      datasets: [{
        data: [66, 33, 53],
        backgroundColor: ['rgba(135, 206, 250, 0.7)', 'rgba(255, 182, 193, 0.7)', 'rgba(192, 192, 192, 0.7)']
      }]
    };
    var options = {
      legend: {
        position: 'right'
      },
      pieceLabel: {
        position: 'inside',
        fontSize: 18
      },
      cutoutPercentage: 60
    };
    var ctx = document.getElementById('my_chart2').getContext('2d');
    var myChart = new Chart(ctx, {
      type: type,
      data: data,
      options: options
    });
    $('.kaitouritu .center .num').html('152');
    $('.kaitouritu .center .text').html('access');
    setTimeout(function(){
      $('.kaitouritu .center').css('transform', 'rotateX(0)');
    }, 300);
  }
  
  function plotWordCloudGraph(){
    var type = 'horizontalBar';
    var data = {
      labels: ['ディレクター', '仕様', 'エンジニア', '指示', '開発', 'メンバー', 'デ プロイ', '確認', 'もの', '対応', '納品'],
      datasets: [{
        data: [32, 21, 16, 13, 11, 9, 8, 8, 7, 7, 7],
        backgroundColor: 'orange'
      }]
    };
    var options = {
      legend: {
        display: false
      }
    };
    var ctx = document.getElementById('my_chart3').getContext('2d');
    var myChart = new Chart(ctx, {
      type: type,
      data: data,
      options: options
    })
    setTimeout(function(){
      $('.wordcloud img').css('transform', 'scale(1)');
    }, 300);
  }
  
  function plotBunruiGraph(){
    var type = 'radar';
    var data = {
      labels: ['くらし・手続き', '子育て・教育', '健康・医療・福祉', '観光・魅力・イベント', '創業・産業・ビジネス', '市政全般'],
      datasets: [{
        data: [41, 29, 26, 18, 15, 23],
        borderColor: 'rgba(64, 224, 208, 1)',
        backgroundColor: 'rgba(64, 224, 208, 0.2)'
      }]
    };
    var options = {
      legend: {
        display: false
      },
      scale: {
        pointLabels: {
          fontSize: 14
        },
        ticks: {
          min: 0
        }
      }
    };
    var ctx = document.getElementById('my_chart4').getContext('2d');
    var myChart = new Chart(ctx, {
      type: type,
      data: data,
      options: options
    })
  }
  
  function plotAccessGraph(){
    var type = 'line';
    var dt = new Date();
    var labels = [];
    dt.setDate(dt.getDate() - 8);
    for(var i=0 ; i<7 ; i++){
      dt.setDate(dt.getDate() + 1);
      labels.push(dt.getMonth()+1 + '/' + dt.getDate());
    }
    
    var data = {
      labels: labels,
      datasets: [
      {
        data: [56, 33, 41, 112, 135, 34, 40],
        lineTension: 0,
        borderColor: 'rgba(135, 206, 250, 1)',
        backgroundColor: 'rgba(135, 206, 250, 0.2)'
      }]
    };
    var options = {
      scales: {
        yAxes: [{
          ticks: {
            min: 0,
            callback: function(value, index, values){
              return value + '回';
            }
          }
        }]
      },
      legend: {
        display: false
      }
    };
    var ctx = document.getElementById('my_chart5').getContext('2d');
    var myChart = new Chart(ctx, {
      type: type,
      data: data,
      options: options
    });
  }
  plotProbGraph();
  plotSatisfyGraph();
  plotWordCloudGraph();
  plotBunruiGraph();
  plotAccessGraph();
})();
