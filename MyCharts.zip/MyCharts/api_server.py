# -*- coding: utf-8 -*
import json, falcon, ast
import knn.v1.operation.knn as knn
import knn.v1.setup.setup as knn_set
import mlp.v1.operation.mlp as mlp
import mlp.v1.setup.setup as mlp_set
import dnorm.v1.src.dnorm as dnorm
import dminor.v1.src.dminor as dminor
import nlp.v1.src.part_of_speech as pos

# /knn/v1/environments
class KnnEnvironmentsResourceV1(object):
  def on_get(self, req, resp):
    response = None
    response = knn_set.create_env()
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /knn/v1/documents?environment_id={環境名}&document={学習データ（JSON）}
class KnnDocumentsResourceV1(object):
  def on_get(self, req, resp):
    response = None
    if 'environment_id' in req.params.keys():
      if 'document' in req.params.keys():
        response = knn_set.create_doc(req.params['environment_id'], req.params['document'])
      else:
        response = 'パラメータ：document を指定してください。'
    else:
      response = 'パラメータ：environment_id を指定してください。'
    
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /knn/v1/update?environment_id={環境名}&query={クエリ}
class KnnUpdateResourceV1(object):
  def on_get(self, req, resp):
    response = None
    if 'environment_id' in req.params.keys():
      if 'query' in req.params.keys():
        response = knn_set.update_doc(req.params['environment_id'], req.params['query'])
      else:
        response = 'パラメータ：query を指定してください。'
    else:
      response = 'パラメータ：environment_id を指定してください。'
    
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /knn/v1/view?environment_id={環境名}
class KnnViewResourceV1(object):
  def on_get(self, req, resp):
    response = None
    if 'environment_id' in req.params.keys():
      response = knn_set.view_doc(req.params['environment_id'])
    else:
      response = 'パラメータ：environment_id を指定してください。'
    
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /knn/v1/training_data?environment_id={環境名}&training_field{カラム名}
class KnnTrainingResourceV1(object):
  def on_get(self, req, resp):
    response = None
    if 'environment_id' in req.params.keys():
      if 'training_field' in req.params.keys():
        response = knn_set.training_doc(req.params['environment_id'], req.params['training_field'])
      else:
        response = 'パラメータ：training_field を指定してください。'
    else:
      response = 'パラメータ：environment_id を指定してください。'
    
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /knn/v1/query?environment_id={環境名}&request={問合せ内容}
class KnnQueryResourceV1(object):
  def on_get(self, req, resp):
    response = None
    if 'environment_id' in req.params.keys():
      if 'request' in req.params.keys():
        response = knn.predict(req.params['environment_id'], req.params['request'])
      else:
        response = 'パラメータ：request を指定してください。'
    else:
      response = 'パラメータ：environment_id を指定してください。'
    
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)



# /mlp/v1/environments
class MlpEnvironmentsResourceV1(object):
  def on_get(self, req, resp):
    response = None
    response = mlp_set.create_env()
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /mlp/v1/documents?environment_id={環境名}&document={学習データ（JSON）}
class MlpDocumentsResourceV1(object):
  def on_get(self, req, resp):
    response = None
    if 'environment_id' in req.params.keys():
      if 'document' in req.params.keys():
        req.params['document'] = ','.join(req.params['document'])
        if req.params['document'] == '{,}':
          req.params['document'] = "{}"
        req.params['document'] = ast.literal_eval(req.params['document'])
        if req.params['document'] == {} or ('sentence' in req.params['document'].keys() and 'class' in req.params['document'].keys()):
          response = mlp_set.create_doc(req.params['environment_id'], req.params['document'])
        else:
          response = 'パラメータの指定形式に誤りがあります。例）：/mlp/v1/documents?environment_id={環境名}&document={"sentence":"分類対象となるテキスト","class":"分類名"}'
      else:
        response = 'パラメータの指定形式に誤りがあります。例）：/mlp/v1/documents?environment_id={環境名}&document={"sentence":"分類対象となるテキスト","class":"分類名"}'
    else:
      response = 'パラメータの指定形式に誤りがあります。例）：/mlp/v1/documents?environment_id={環境名}&document={"sentence":"分類対象となるテキスト","class":"分類名"}'
    
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /mlp/v1/update?environment_id={環境名}&query={クエリ}
class MlpUpdateResourceV1(object):
  def on_get(self, req, resp):
    response = None
    if 'environment_id' in req.params.keys():
      if 'query' in req.params.keys():
        response = mlp_set.update_doc(req.params['environment_id'], req.params['query'])
      else:
        response = 'パラメータ：query を指定してください。'
    else:
      response = 'パラメータ：environment_id を指定してください。'
    
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /mlp/v1/view?environment_id={環境名}
class MlpViewResourceV1(object):
  def on_get(self, req, resp):
    response = None
    if 'environment_id' in req.params.keys():
      response = mlp_set.view_doc(req.params['environment_id'])
    else:
      response = 'パラメータ：environment_id を指定してください。'
    
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /mlp/v1/training_data?environment_id={環境名}
class MlpTrainingResourceV1(object):
  def on_get(self, req, resp):
    response = None
    if 'environment_id' in req.params.keys():
      response = mlp_set.training_doc(req.params['environment_id'])
    else:
      response = 'パラメータ：environment_id を指定してください。'
    
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /mlp/v1/query?environment_id={環境名}&request={問合せ内容}
class MlpQueryResourceV1(object):
  def on_get(self, req, resp):
    response = None
    if 'environment_id' in req.params.keys():
      if 'request' in req.params.keys():
        response = mlp.predict(req.params['environment_id'], req.params['request'])
      else:
        response = 'パラメータ：request を指定してください。'
    else:
      response = 'パラメータ：environment_id を指定してください。'
    
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)



# /d-norm/v1/query?request={問合せ内容}
class DNormQueryResourceV1(object):
  def on_get(self, req, resp):
    response = None
    if 'request' in req.params.keys():
      response = dnorm.norm(req.params['request'])
    else:
      response = 'パラメータ：request を指定してください。'
    
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)



# /d-minor/v1/kde?samples={サンプリングデータ}&range={レンジ}
class DMinorKDEResourceV1(object):
  def on_get(self, req, resp):
    samples = None
    if 'samples' in req.params.keys():
      if 'range' in req.params.keys():
        response = dminor.kde(req.params['samples'], req.params['range'])
      else:
        response = 'パラメータ：range を指定してください。'
    else:
      response = 'パラメータ：samples を指定してください。'
    
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)



# /nlp/v1/proper-noun?request={問合せ内容}
class NlpPosResourceV1(object):
  def on_get(self, req, resp):
    route = req.url.split('/')[-1]
    route = route.split('?')[0]
    if route == 'proper-noun':
      if 'request' in req.params.keys():
        response = pos.get_proper_noun(req.params['request'])
      else:
        response = 'パラメータ：request を指定してください。'
    
    resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)



class CORSMiddleware:
    def process_request(self, req, resp):
        resp.set_header('Access-Control-Allow-Origin', '*')

app = falcon.API(middleware=[CORSMiddleware()])

app.add_route("/knn/v1/environments", KnnEnvironmentsResourceV1())
app.add_route("/knn/v1/documents", KnnDocumentsResourceV1())
app.add_route("/knn/v1/update", KnnUpdateResourceV1())
app.add_route("/knn/v1/view", KnnViewResourceV1())
app.add_route("/knn/v1/training_data", KnnTrainingResourceV1())
app.add_route("/knn/v1/query", KnnQueryResourceV1())

app.add_route("/mlp/v1/environments", MlpEnvironmentsResourceV1())
app.add_route("/mlp/v1/documents", MlpDocumentsResourceV1())
app.add_route("/mlp/v1/update", MlpUpdateResourceV1())
app.add_route("/mlp/v1/view", MlpViewResourceV1())
app.add_route("/mlp/v1/training_data", MlpTrainingResourceV1())
app.add_route("/mlp/v1/query", MlpQueryResourceV1())

app.add_route("/d-norm/v1/query", DNormQueryResourceV1())

app.add_route("/d-minor/v1/kde", DMinorKDEResourceV1())

app.add_route("/nlp/v1/proper-noun", NlpPosResourceV1())

if __name__ == "__main__":
  from wsgiref import simple_server
  httpd = simple_server.make_server("", 14000, app)
  print('server listening...')
  httpd.serve_forever()

