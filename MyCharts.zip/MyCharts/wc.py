import matplotlib.pyplot as plt
import numpy as np
from bs4 import BeautifulSoup
import requests
from PIL import Image
from os import path
from janome.tokenizer import Tokenizer
import random
from collections import Counter

def mecab_analysis(text):
    t = Tokenizer()
    
    tokens = t.tokenize(text)
    
    line = []
    for token in tokens:
        if token.part_of_speech.split(',')[0] == '名詞':
            line.append(token.surface)
    
    return line

def get_wordlist_from_QiitaURL(url):
    res = requests.get(url)
    soup = BeautifulSoup(res.text)
    text = soup.body.section.get_text().replace('\n','').replace('\t','')
    return mecab_analysis(text)

def create_wordcloud(text):
    
    # 環境に合わせてフォントのパスを指定する。
    fpath = "meiryo.ttc"
    
    wordcloud = WordCloud(background_color="white", font_path=fpath, width=600, height=450, color_func=color_func, max_words=70, stopwords=set(stop_words)).generate(text)
    
    plt.figure(figsize=(15, 12))
    plt.imshow(wordcloud)
    plt.axis("off")
    plt.savefig('wordcloud.png')

def color_func(word, font_size, position, orientation, random_state, font_path):
    colors = ['blue', 'red', 'green', 'orange', 'lawngreen', 'mediumorchid', 'turquoise', 'lightcoral', 'chocolate', 'deepskyblue', 'burlywood', 'yellowgreen']
    return random.choice(colors)

def crop_center(pil_img, crop_width, crop_height):
    img_width, img_height = pil_img.size
    return pil_img.crop(((img_width - crop_width) // 2,
                         (img_height - crop_height) // 2,
                         (img_width + crop_width) // 2,
                         (img_height + crop_height) // 2))



# ストップワードの設定
stop_words = [u'てる', u'いる', u'なる', u'れる', u'する', u'ある', u'こと', u'これ', u'さん', u'して', \
         u'くれる', u'やる', u'くださる', u'そう', u'せる', u'した',  u'思う',  \
         u'それ', u'ここ', u'ちゃん', u'くん', u'', u'て',u'に',u'を',u'は',u'の', u'が', u'と', u'た', u'し', u'で', \
         u'ない', u'も', u'な', u'い', u'か', u'ので', u'よう', u'']

url = "http://qiita.com/t_saeko/items/2b475b8657c826abc114"
wordlist = get_wordlist_from_QiitaURL(url)
create_wordcloud(" ".join(wordlist))

im = Image.open('wordcloud.png')
croped = im.crop((165, 155, 1365, 1050))
croped.save('wordcloud.png', quality=100)

counter = Counter(wordlist)

for item in stop_words:
  try:
    del counter[item]
  except:
    pass

labels = []
data = []
itr = 0
for word, cnt in counter.most_common():
    if 1 < len(word):
        labels.append(word)
        data.append(cnt)
        if itr < 10:
            itr += 1
        else:
            break

print(labels)
print(data)

