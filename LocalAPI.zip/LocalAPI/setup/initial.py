# -*- coding: utf-8 -*-
import os, sys, copy, configparser, shutil
import common.pkl as pkl
import numpy as np
import pandas as pd
import threading
import setup.mlp_thread_super as mlp_thread_super, setup.knn_thread_super as knn_thread_super

def init_train(env_id, mode = 'init'):
    try:
        cd = os.path.dirname(os.path.abspath(__file__)) + '/../../environments/'
        
        shutil.rmtree(cd + env_id + '/pickle') if os.path.exists(cd + env_id + '/pickle') else None
        os.mkdir(cd + env_id + '/pickle') if not os.path.exists(cd + env_id + '/pickle') else None
        os.mkdir(cd + env_id + '/pickle/document') if not os.path.exists(cd + env_id + '/pickle/document') else None
        os.mkdir(cd + env_id + '/pickle/model') if not os.path.exists(cd + env_id + '/pickle/model') else None
        os.mkdir(cd + env_id + '/pickle/vector') if not os.path.exists(cd + env_id + '/pickle/vector') else None
        
        norm_path = ''
        if mode == 'add':
            norm_path = '/../..'
        
        ini = configparser.SafeConfigParser()
        ini.read(cd + env_id + norm_path + '/conf.ini')
        property = ini.get('process', 'setting')
        property = property.replace(', ', ',').replace(' ,', ',').replace(' , ', ',').replace(': ', ':').replace(' :', ':').replace(' : ', ':')
        
        setting = property.split(',')
        setting_dict = {}
        keys = set()
        for i in range(len(setting)):
            item = setting[i].split(':')
            keys.add(item[0])
            if item[1] in setting_dict.keys():
                setting_dict[item[1]].append(item[0])
            else:
                setting_dict[item[1]] = []
                setting_dict[item[1]].append(item[0])
        
        keys = list(keys)
        
        mlp_data = []
        knn_data = []
        pn_data = []
        with open(cd + env_id + norm_path + '/data/train_data.csv', 'r', encoding = 'utf8') as f:
            for line in f:
                item = line.rstrip('\n').split(',')
                if item[1] in setting_dict['knn']:
                    knn_data.append(copy.deepcopy(item))
                if item[1] in keys:
                    mlp_data.append(copy.deepcopy(item))
                    item[1] = 'neutral'
                    pn_data.append([copy.deepcopy(item[0]), copy.deepcopy(item[1])])
        
        with open(cd + env_id + norm_path + '/data/pn_data.csv', 'r', encoding = 'utf8') as f:
            for line in f:
                pn_data.append(line.rstrip('\n').split(','))
        
        mlp_data = np.array(mlp_data)
        knn_data = np.array(knn_data)
        pn_data = np.array(pn_data)
        
        mlp_dummy = pd.get_dummies(mlp_data[:,1], drop_first = False)
        mlp_label = {}
        for i in range(len(mlp_dummy.columns)):
            mlp_label[i] = mlp_dummy.columns[i]
        
        knn_dummy = pd.get_dummies(knn_data[:,1], drop_first = False)
        knn_label = {}
        for i in range(len(knn_dummy.columns)):
            knn_label[i] = knn_dummy.columns[i]
        
        pn_dummy = pd.get_dummies(pn_data[:,1], drop_first = False)
        pn_label = {}
        for i in range(len(pn_dummy.columns)):
            pn_label[i] = pn_dummy.columns[i]
        
        thread = []
        thread.append(mlp_thread_super.MlpThreadSuper(env_id, mlp_data, mlp_dummy, mlp_label, 'mlp'))
        thread.append(mlp_thread_super.MlpThreadSuper(env_id, pn_data, pn_dummy, pn_label, 'pn'))
        thread.append(knn_thread_super.KnnThreadSuper(env_id, knn_data, knn_label))
        
        for item in thread:
            item.start()
        
        for item in thread:
            item.join()
        
        pkl.dump(mlp_label, cd + env_id + '/pickle/document/mlp_label.pkl')
        pkl.dump(knn_label, cd + env_id + '/pickle/document/knn_label.pkl')
        pkl.dump(pn_label, cd + env_id + '/pickle/document/pn_label.pkl')
        
        merge_pickle(env_id, mlp_label, knn_label, pn_label)
        
        return {'message': 'Succeeded in training the data'}
    except:
        return {'message': 'Failed in training the data'}

def merge_pickle(env_id, mlp_label, knn_label, pn_label):
    cd = os.path.dirname(os.path.abspath(__file__)) + '/../../environments/'
    
    vector = {}
    mlp = {}
    knn = {}
    pn = {}
    for i in range(len(mlp_label)):
        mlp[i] = pkl.load(cd + env_id + '/pickle/model/mlp'+str(i)+'.pkl')
        os.remove(cd + env_id + '/pickle/model/mlp'+str(i)+'.pkl')
    
    for i in range(len(knn_label)):
        vector[i] = pkl.load(cd + env_id + '/pickle/vector/part'+str(i)+'.pkl')
        knn[i] = pkl.load(cd + env_id + '/pickle/model/knn'+str(i)+'.pkl')
        os.remove(cd + env_id + '/pickle/vector/part'+str(i)+'.pkl')
        os.remove(cd + env_id + '/pickle/model/knn'+str(i)+'.pkl')
    
    for i in range(len(pn_label)):
        pn[i] = pkl.load(cd + env_id + '/pickle/model/pn'+str(i)+'.pkl')
        os.remove(cd + env_id + '/pickle/model/pn'+str(i)+'.pkl')
    
    pkl.dump(vector, cd + env_id + '/pickle/vector/part.pkl')
    pkl.dump(mlp, cd + env_id + '/pickle/model/mlp.pkl')
    pkl.dump(knn, cd + env_id + '/pickle/model/knn.pkl')
    pkl.dump(pn, cd + env_id + '/pickle/model/pn.pkl')


