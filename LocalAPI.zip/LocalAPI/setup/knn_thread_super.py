# -*- coding: utf-8 -*
import os.path, threading
import common.pkl as pkl
import setup.knn_thread_sub as knn_thread_sub

class KnnThreadSuper(threading.Thread):
    def __init__(self, id, data, label):
        super(KnnThreadSuper, self).__init__()
        self.id = id
        self.data = data
        self.label = label
    
    def run(self):
        cd = os.path.dirname(os.path.abspath(__file__)) + '/../../environments/'
        
        print('knn_super >> start')
        
        text = {}
        for i in range(len(self.label)):
            text[i] = []
            for line in self.data:
                if line[1] == self.label[i] and line[2] != '':
                    text[i].append(list(line))
        
        thread = []
        for i in range(len(text)):
            thread.append(knn_thread_sub.KnnThreadSub(self.id, i, text[i]))
        
        for item in thread:
            item.start()
        
        for item in thread:
            item.join()
        
        pkl.dump(text, cd + self.id + '/pickle/document/text.pkl')
        
        print('knn_super >> end')

