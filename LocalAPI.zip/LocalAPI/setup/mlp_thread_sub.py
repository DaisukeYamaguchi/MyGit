# -*- coding: utf-8 -*
import os.path, threading, copy
import common.language as language, common.pkl as pkl
import numpy as np
from sklearn.neural_network import MLPClassifier

class MlpThreadSub(threading.Thread):
    def __init__(self, id, index, X, y, name):
        super(MlpThreadSub, self).__init__()
        self.id = id
        self.index = index
        self.X = X
        self.y = y
        self.name = name
    
    def run(self):
        cd = os.path.expanduser('~') + '/Chatbot/environments/'
        
        clf = MLPClassifier(
            hidden_layer_sizes = (50, ), 
            solver = 'adam', 
            alpha = 0.0001, 
            activation = 'relu', 
            random_state = 0, 
            max_iter = 10000, 
        )
        
        clf.fit(self.X, self.y)
        
        pkl.dump(clf, cd + self.id + '/pickle/model/' + self.name + str(self.index) + '.pkl')

