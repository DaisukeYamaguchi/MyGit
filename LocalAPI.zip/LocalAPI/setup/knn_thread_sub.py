# -*- coding: utf-8 -*
import os.path, threading, copy
import common.language as language, common.pkl as pkl
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.feature_extraction.text import TfidfVectorizer

class KnnThreadSub(threading.Thread):
    def __init__(self, id, index, text):
        super(KnnThreadSub, self).__init__()
        self.id = id
        self.index = index
        self.text = text
    
    def run(self):
        cd = os.path.expanduser('~') + '/Chatbot/environments/'
        
        part_vector = {}
        model = {}
        
        pick = np.array(self.text)
        
        vector, X = self.get_tfidf(copy.deepcopy(pick[:,0]))
        
        y = pick[:,2]
        
        clf = KNeighborsClassifier(n_neighbors = 1)
        
        clf.fit(X, y)
        
        pkl.dump(vector, cd + self.id + '/pickle/vector/part'+str(self.index)+'.pkl')
        pkl.dump(clf, cd + self.id + '/pickle/model/knn'+str(self.index)+'.pkl')
    
    def get_tfidf(self, data):
        X = language.wakachi_nv(self.id, data)
        vector = TfidfVectorizer(use_idf=True)
        vector.fit_transform(X)
        X = vector.transform(X)
        
        return vector, X
