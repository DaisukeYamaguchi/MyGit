# -*- coding: utf-8 -*-
import os, urllib.parse, copy
import common.language as language

def run(env_id, context):
    if context['status'] == 'steady':
        context['status'] = 'close'
    elif context['status'] == 'understand':
        context['response'] = 'これから音声の聞き取りのみを行います。<br終了したい場合は、送信フォームから「終了」とお伝えください。'
        context['status'] = 'steady'
    return context

