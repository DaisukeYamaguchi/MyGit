# -*- coding: utf-8 -*-
import os, urllib.parse, copy
import common.language as language

def run(env_id, context):
    msg = language.text_trans(env_id, copy.deepcopy(context['message']))
    
    filter = {}
    filter['where'] = language.get_place(env_id, msg)
    
    if context['pardon'] < 3:
        if filter['where'] is None:
            context['response'] = '場所はどちらでしょうか？' if context['pardon'] == 0 else '場所の認識に失敗しました。<br>表現を変えていただいてもよろしいでしょうか？'
            context['pardon'] += 1
        else:
            context['request'] = msg
            
            url = 'https://www.google.com/maps/embed/v1/place?'
            
            params = {
                      'q': filter['where'],
                      'key': 'AIzaSyBjvvqJrBlALGxmvQHWHAaweWgDziF2-PA'
                     }
            
            tag = create_table(url + urllib.parse.urlencode(params))
            
            context['content'] = {}
            context['content']['type'] = 'html'
            context['content']['result'] = tag
            context['response'] = 'こちらの地図をご確認ください。'
            context['learning'].append('') if context['learning'] != [] else None
            context['status'] = 'proposal'
    else:
        context['response'] = '担当者に引き継ぎます。'
        context['status'] = 'consult'
    
    return context

def create_table(url):
    tag = '<iframe class="item" src=' + url + ' width="600" height="400" frameborder="0" style="border:0" allowfullscreen>'
    return tag

