# -*- coding: utf-8 -*-

def run(context):
    import os.path, distance, regex, language, pkl, pn, session as sess
    cd = os.path.expanduser('~') + '/ChatNavi/webapp'
    
    rsv = {'when': None, 'where': None, 'who': None}
    
    rsv['when'] = regex.get_plan(msg)
    rsv['who'], rsv['where'] = language.get_proper_noun(msg, 'rsv_dict.csv')
    
    reply = None
    if context['status'] == 'fix':
        noun = language.get_noun(msg)
        if noun != None:
            reply = '予約が完了しました。<br>手続きを終了します。\n/release'
        else:
            reply = '会議名を判断できませんでした。<br>名詞以外の単語は対応していません。'
    if context['status'] == 'confirm':
        if 1 == pn.predict(msg):
            context['status'] == 'fix'
            reply = '会議名は何にしますか？'
        else:
            if rsv['when'] is rsv['who'] is rsv['where'] is None:
                candidate = get_candidate(rsv)
                result = create_table(candidate)
                context['response'] = result + '<transaction>空き状況を再度ご確認ください。'
                context['status'] = 'steady'
                return reply
            else:
                context['status'] = 'steady'
    
    if context['status'] == 'request':
        index = language.get_number(regex.z2h(msg))
        if 0 == len(index):
            context['response'] = '文脈を理解できませんでした。<br>管理者に追加学習を依頼します。'
        elif 1 == len(index):
            if int(index[0]) < len(context['rsv'])+1:
                candidate = get_candidate(context['rsv'])
                candidate = candidate[condition['request']]
                candidate[3] = str(int(candidate[2].split(':')[0]) + 1) + ':' + candidate[2].split(':')[1]
                result = create_table([candidate])
                pkl.dump(result, context['userhome'] + '/rsv_cnf.pkl')
                reply = result + '<transaction>上記のスケジュールで予約してよろしいですか？'
                context['status'] = 'confirm'
            else:
                reply = 'その番号は存在しません。入力内容を確認してください。'
        elif 1 < len(index):
            reply = '申請は１件ずつ行ってください。'
    if context['status'] == 'steady':
        past = pkl.load('session/' + id + '/rsv.pkl')
        if session['when'] is session['who'] is session['where'] is None:
            print('※未対応※')
        else:
            for key in session.keys():
                if session[key] is not None:
                    past[key] = session[key]
                    session = past
                    condition['status'] = 'understand'
    if condition['status'] == 'understand':
        if session['when'] is session['who'] is session['where'] is None:
            os.remove(cd + '/session/'+ id +'/message.pkl')
            reply = '日時、メンバー、場所から指定できます。'
        else:
            session['subject'] = msg
            candidate = get_candidate(session)
            if candidate == []:
                reply = '空きが見つかりませんでした。'
            else:
                result = create_table(candidate)
                reply = result + '<transaction>上記の空き時間を確認しました。<br>予約したいスケジュールは番号でお伝えください。'
                os.remove(cd + '/session/'+ id +'/message.pkl')
                condition['status'] = 'steady'
            pkl.dump(session, 'session/' + id + '/rsv.pkl')
    
    sess.set(id, condition)
    
    return context

def get_candidate(session):
    time = interval(session['when'])
    member = schedule(session['who'])
    room = reservation(session['where'])
    
    workable = tXmXr(time, member, room)
    candidate = get_workable(workable)
    
    data = []
    for i in range(len(candidate)):
        candidate[i] = [candidate[i]['date'], candidate[i]['start'], candidate[i]['end'], candidate[i]['place'], str(candidate[i]['day']), str(candidate[i]['from']), str(candidate[i]['to']), str(candidate[i]['hold'])]
    
    candidate = sorted(candidate, key=lambda x:(x[4], x[5], x[6], x[3]), reverse = False)
    
    for i in range(len(candidate)):
        candidate[i].insert(0, str(i+1))
    
    return candidate

def create_table(data, mode=0):
    from texttable import Texttable
    #full = [["番号", "日付", "開始", "終了", "会議室"]]
    #for item in data:
    #    full.append(item)
    #
    #table = Texttable()
    #if mode == 0:
    #    table.set_cols_align(["c", "c", "c", "c", "c"])
    #    table.set_cols_valign(["m", "m", "m", "m", "m"])
    #elif mode == 1:
    #    table.set_deco(Texttable.HEADER)
    #    table.set_cols_dtype(['t', 't', 't', 't', 't'])
    #    table.set_cols_align(["c", "c", "c", "c", "c"])
    #
    #table.add_rows(full)
    
    table = "<table id='scheduleTable'><tr><th>番号</th><th>日付</th><th>開始</th><th>終了</th><th>場所</th></tr>"
    
    for i in range(len(data)):
        table += '<tr>'
        for j in range(5):
            table += '<td>' + data[i][j] + '</td>'
        table += '</tr>'
    
    table += '</table>'
    
    return table

def interval(when):
    import numpy as np
    date = np.array([[False] * 7] * 36)
    time = np.array([[False] * 7] * 36)
    
    if when == None:
        return True
    else:
        if when['date'] == None:
            date = None
        else:
            for i in range(when['date']['from'], when['date']['to']+1):
                date[:,i] = True
        
        if when['time'] == None:
            time = None
        else:
            for i in range(when['time']['from'], when['time']['to']):
                time[i,:] = True
        
        if date is None:
            if time is None:
                return True
            else:
                return time
        else:
            if time is None:
                return date
            else:
                return date * time

def reservation(room):
    import os.path
    import numpy as np
    cd = os.path.expanduser('~') + '/ChatNavi/webapp'
    reservation = {}
    
    if room == None:
        room = os.listdir(cd + '/data/room')
        for i in range(len(room)):
            room[i] = room[i].split('.')[0]
    
    for item in room:
        file = []
        for line in open(cd + '/data/room/'+item+'.csv', 'r', encoding = 'utf8'):
            file.append(line.rstrip('\n').split(','))
        
        reservation[item] = np.array(file)
        reservation[item] = reservation[item] == 'TRUE'
    
    return reservation

def schedule(member):
    import os.path
    import numpy as np
    import distance
    
    cd = os.path.expanduser('~') + '/ChatNavi/webapp'
    schedule = {}
    
    all_free = None
    if member == None:
        all_free = True
    else:
        member = distance.run(member)
        
        for item in member:
            file = []
            for line in open(cd + '/data/member/'+item+'.csv', 'r', encoding = 'utf8'):
                file.append(line.rstrip('\n').split(','))
            schedule[item] = np.array(file)
            schedule[item] = schedule[item] == 'TRUE'
        
        all_free = schedule[member[0]]
        for i in range(1, len(schedule)):
            all_free = all_free * schedule[member[i]]
    
    return all_free

def tXmXr(time, member, room):
    import numpy as np
    scope_plate = time * member
    for item in room.keys():
        room[item] = room[item] * scope_plate
        if 0 == np.sum(room[item]):
            room[item] = None
    
    return room

def get_workable(room):
    import datetime
    
    week = ['月', '火', '水', '木', '金', '土', '日']
    workable = []
    for item in room.keys():
        if room[item] is not None:
            for i in range(len(room[item][0])):
                temp = {'place': '', 'day': 0, 'from': 0, 'to': 0, 'hold': 0}
                temp['place'] = item
                status = False
                for j in range(len(room[item])):
                    if status == False:
                        if room[item][j][i] == True:
                            temp['day'] = i
                            temp['from'] = j
                            status = True
                    else:
                        if room[item][j][i] == False:
                            temp['to'] = j
                            temp['hold'] = (temp['to'] - temp['from']) / 4
                            temp['start'] = str(int(temp['from'] / 4 + 9)) + ':' + str(int((temp['from'] - (temp['from'] / 4) * 4)) * 15).zfill(2)
                            temp['end'] = str(int(temp['to'] / 4 + 9)) + ':' + str(int((temp['to'] - (temp['to'] / 4) * 4)) * 15).zfill(2)
                            today = datetime.date.today()
                            today = today + datetime.timedelta(days=temp['day'])
                            temp['date'] = str(today.month)+'月'+str(today.day)+'日（'+week[today.weekday()]+'）'
                            workable.append(temp)
                            status = False
    
    return workable

