# -*- coding: utf-8 -*-
import os.path, copy, urllib.parse, requests, bs4, re, urllib.request, json, numpy as np
import common.regex as regex, common.language as language

def run(env_id, context):
    msg = language.text_trans(env_id, copy.deepcopy(context['message']))
    
    filter = {}
    filter['when'] = regex.get_plan(msg)
    filter['where'] = language.get_from_to(env_id, msg)
    
    if context['pardon'] < 3:
        if filter['where']['from'] is filter['where']['to'] is filter['when'] is None:
            context['response'] = '行先をお伝えください。' if context['pardon'] == 0 else '行先の認識に失敗しました。<br>表現を変えていただいてもよろしいでしょうか？'
            context['pardon'] += 1
        else:
            context['request'] = msg
            
            url = 'https://jik.nishitetsu.jp/route?'
            params = {
                      'f_zahyo_flg': 0,
                      't_zahyo_flg': 0,
                      'rightnow_flg': 1,
                      'sort': 2,
                      'jkn_busnavi': 1,
                      'syosaiFlg': 0
                     }
            
            if filter['where']['from'] is not None:
                params['f_list'] = get_nearest(context, filter['where']['form'])[1] + ',' + get_nearest(context, filter['where']['form'])[2]
            else:
                params['f_list'] = '0000,L00172'#六本松
            
            if filter['where']['to'] is not None:
                params['t_list'] = get_nearest(context, filter['where']['to'])[1] + ',' + get_nearest(context, filter['where']['to'])[2]
                schedule = scraping(url + urllib.parse.urlencode(params))
                context['extra'] = schedule
                context['response'] = create_table(schedule)
                if context['response'] is not None:
                    context['response'] += '<transaction>上記の運行予定を確認しました。'
                else:
                    context['response'] = '運行予定がありませんでした。'
                context['status'] = 'failed'
            else:
                context['response'] = '行先はどちらでしょうか？'
    else:
        context['response'] = '申し訳ございませんが、私では対応し兼ねます。<br>問合せ内容を担当者に引き継ぎますか？'
        context['status'] = 'consult'
    
    return context

def scraping(url):
    res = requests.get(url)
    #res = requests.get('https://jik.nishitetsu.jp/route?f_zahyo_flg=0&f_list=0001%2C551170&t_zahyo_flg=0&t_list=0001%2C610125&rightnow_flg=2&sdate=2017%2F11%2F27&stime_h=09&stime_m=00&stime_flg=1&sort=2&jkn_busnavi=1&syosaiFlg=0')
    res.raise_for_status()
    soup = bs4.BeautifulSoup(res.text, "html.parser")
    
    elems_id = []
    cnt = 1
    while True:
        try:
            elems_id.append(str(soup.select('#' + str(cnt))[0]))
            cnt += 1
        except IndexError:
            break
    
    elems_class = soup.select('.table_root.mb50')
    
    schedule = []
    
    for i in range(cnt - 1):
        root = ['----'] * 9
        
        root[0] = str(i+1)
        match = re.findall('<label>(\d{1,2}:\d{2}) .*</label>', elems_id[i])
        if 0 < len(match):
            root[3] = match[0]
        
        match = re.findall(' (.*遅れ)', elems_id[i])
        if 0 < len(match):
            root[8] = match[0]
        
        match = re.findall('<td>(\d{1,2}:\d{2}).*</td>', elems_id[i])
        if 0 < len(match):
            root[5] = match[0]
        
        match = re.findall('乗り換え</label><span>(\d{1,2})</span>', elems_id[i])
        if 0 < len(match):
            root[6] = match[0]
        
        match = re.findall('<span>(\d{3,4})</span>', elems_id[i])
        if 0 < len(match):
            root[7] = match[0]
        
        root[2] = elems_class[i].select('.img')[1].text.replace('\n', '').replace('\t', '').split(' (')[0]
        root[4] = elems_class[i].select('.img')[2].text.replace('\n', '').replace('\t', '').split(' (')[0]
        
        match = re.findall('<strong>(\[.*)</strong>', str(elems_class[i]))
        if 0 < len(match):
            root[1] = match[0]
        
        if root[8] == '----':
            root[8] = '定刻'
        
        schedule.append(root)
    
    return schedule

def create_table(schedule):
    table = None
    if 0 < len(schedule):
        table = "<table  id='scheduleTable'>"
        table += '<tr><th colspan=2>番号</th><th>出発</th><th>到着</th><th>バス</th></tr>'
        for i in range(len(schedule)):
            table += '<tr><td colspan=2 rowspan=2>'+schedule[i][0]+'</td><td>'+schedule[i][2]+'</td><td>'+schedule[i][4]+'</td><td colspan=2 rowspan=2>'+schedule[i][1]+'<br>'+schedule[i][8]+'</td></tr><tr><td>'+schedule[i][3]+'</td><td>'+schedule[i][5]+'</td></tr>'
        table += '</table>'
    
    return table

def get_nearest(context, place):
    url = 'https://maps.googleapis.com/maps/api/place/nearbysearch/json?'
    params = {'location': '33.578025,130.375915',
              'radius': '50000',
              #'type': 'restaurant',
              'language': 'ja',
              'keyword': place,
              'key': 'AIzaSyCD-S6kkj42i-5D_Swwb172tZGIjhFGlAg'
              }
    
    url + urllib.parse.urlencode(params)
    
    response = urllib.request.urlopen(url + urllib.parse.urlencode(params))
    content = json.loads(response.read().decode('utf8'))
    
    #content['results'][0]['geometry']['location']['lat']
    #content['results'][0]['geometry']['location']['lng']
    #content['results'][0]['name']
    #content['results'][0]['vicinity']
    
    sample = [content['results'][0]['geometry']['location']['lat'], content['results'][0]['geometry']['location']['lng']]
    
    name = []
    data = []
    with open(context['userhome'] + '/../../data/bus_stop.csv', 'r', encoding = 'utf8') as f:
        for line in f:
            line = line.rstrip('\n').split(',')
            if '' not in line:
                name.append([line[0], line[1], line[2]])
                data.append([float(line[3]), float(line[4])])
    
    power = np.power(np.array(data) - np.array(sample), 2)
    distance = np.sqrt(power[:,0] + power[:,1])
    
    return name[np.argmin(distance)]

