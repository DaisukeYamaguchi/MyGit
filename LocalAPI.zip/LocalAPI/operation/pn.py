import os, copy
import common.language as language, common.pkl as pkl
import configparser

def predict(context):
    ini = configparser.SafeConfigParser()
    ini.read(context['userhome'] + '/../../conf.ini')
    
    pn_thre = float(ini.get('threshold', 'pn_thre'))
    
    msg = language.wakachi_pn([copy.deepcopy(context['message'])])
    label = pkl.load(context['userhome'] + '/../../pickle/document/pn_label.pkl')
    vector = pkl.load(context['userhome'] + '/../../pickle/vector/pn.pkl')
    mlp = pkl.load(context['userhome'] + '/../../pickle/model/pn.pkl')
    
    X = vector.transform(msg)
    
    prob = {}
    for i in range(len(label)):
        prob[label[i]] = mlp[i].predict(X)[1][0]
    
    if pn_thre < prob['positive']:
        return 1
    elif pn_thre < prob['negative']:
        return -1
    else:
        return 0

