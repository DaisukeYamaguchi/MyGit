# -*- coding: utf-8 -*-
import os.path, common.pkl as pkl, glob

def set(context):
    pkl.dump(context, context[-1]['userhome'] + '/context.pkl')

def get(context = None, env_id = None, sess_id = None):
    if context is None:
        return pkl.load(os.environ.get('CHATBOT_ENV') + '/' + env_id + '/session/' + sess_id + '/context.pkl')
    else:
        return pkl.load(context[-1]['userhome'] + '/context.pkl')

def remove(context):
    os.remove(context[-1]['userhome'] + '/context.pkl')

