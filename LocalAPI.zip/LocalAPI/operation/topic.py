import os, copy, configparser, random
import common.pkl as pkl
import operation.pn as pn, operation.mlp as mlp

def run(env_id, context):
    ini = configparser.SafeConfigParser()
    ini.read(context['userhome'] + '/../../conf.ini')
    
    mlp_thre1 = float(ini.get('threshold', 'mlp_thre1'))
    mlp_thre2 = float(ini.get('threshold', 'mlp_thre2'))
    knn_thre = float(ini.get('threshold', 'knn_thre'))
    
    prob = mlp.predict(context, env_id)
    
    topic = {1: [], 2: [], 3: []}
    for item in prob:
        if mlp_thre1 < item[1]:
            topic[1].append(item[0])
        elif mlp_thre2 < item[1]:
            topic[2].append(item[0])
    
    for item in range(1, 4):
        if 0 == len(topic[item]):
            topic.pop(item)
    
    context['topic_list'] = topic
    context['status'] = 'estimation'
    
    return context

def predict(env_id, context):
    if context['status'] == 'direct':
        topic = get_topic(context)
        if 1 == len(topic):
            context['status'] = 'understand'
            context['topic'] = topic[0]
        elif 1 < len(topic):
            context['response'] = '複数のトピックの回答には対応していません。<br>単一のトピックを指定して再入力してください。'
        else:
            if 0 == pn.predict(context):
                topic = get_topic(context)
                if 1 == len(topic):
                    context['status'] = 'understand'
                    context['topic'] = topic[0]
                elif 0 == len(topic):
                    if context['pardon'] < 2:
                        context['response'] = '正しく認識できませんでした。<br>表現を変えて再入力してください。'
                        context['pardon'] += 1
                    else:
                        context['response'] = '申し訳ございませんが、私では対応し兼ねます。<br>問合せ内容を担当者に引き継ぎますか？'
                        context['pardon'] = 0
                        context['status'] = 'consult'
                else:
                    bot = '複数のトピックの回答には対応していません。<br>単一のトピックを指定して再入力してください。'
            elif 1 == pn.predict(context):
                if 1 in context['topic_list'].keys():
                    context['status'] = 'understand'
                    context['topic'] = context['topic_list'][1][0]
                elif 2 in context['topic_list'].keys():
                    context['status'] = 'understand'
                    context['topic'] = context['topic_list'][2][0]
                elif 3 in context['topic_list'].keys():
                    context['status'] = 'understand'
                    context['topic'] = context['topic_list'][3][0]
                else:
                    context['response'] = 'システムエラーが発生しました。'
                    context['status'] = 'failed'
            else:
                context['topic_list'] = None
                mlp_label = pkl.load(context['userhome']+ '/../../pickle/document/mlp_label.pkl')
                context['response'] = '以下のどのお問い合わせでしょうか？<br>' + '・'.join(list(mlp_label.values()))
    else:
        if 1 in context['topic_list'].keys():
            if 1 == len(context['topic_list'][1]):
                context['status'] = 'understand'
                context['topic'] = context['topic_list'][1][0]
            else:
                context['status'] = 'direct'
                context['response'] = '以下のお問い合わせが該当します。<br>どれでしょうか？<br>' + ' '.join(context['topic_list'][1])
                context['learning'].append(context['request'])
        elif 2 in context['topic_list'].keys():
            if 1 == len(context['topic_list'][2]):
                ini = configparser.SafeConfigParser()
                ini.read(os.environ.get('CHATBOT_ENV') + '/' + env_id + '/conf.ini')
                confirm = ini.get('message', 'confirm').rstrip('\n').split(',')
                context['status'] = 'direct'
                context['response'] = context['topic_list'][2][0] + random.choice(confirm)
                context['learning'].append(context['request'])
            else:
                context['status'] = 'direct'
                context['response'] = '以下のお問い合わせが候補に挙がります。<br>どれでしょうか？<br>' + '・'.join(context['topic_list'][2])
                context['learning'].append(context['request'])
        else:
            if context['pardon'] < 2:
                context['status'] = 'failed'
                context['response'] = '該当するトピックが見つかりませんでした。<br>表現を変えて再入力してください。'
                context['pardon'] += 1
            else:
                context['response'] = '申し訳ございませんが、私では対応し兼ねます。<br>問合せ内容をシステム管理者に引き継ぎますか？'
                context['pardon'] = 0
                context['topic'] = 'master'
                context['status'] = 'consult'
    
    return context

def get_topic(context):
    
    mlp_label = pkl.load(context['userhome']+ '/../../pickle/document/mlp_label.pkl')
    
    topic = []
    for item in mlp_label.values():
        if item in context['message']:
            topic.append(item)
    
    return topic

