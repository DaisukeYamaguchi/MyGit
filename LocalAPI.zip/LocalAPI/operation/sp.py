import os
import common.language as language, common.pkl as pkl, operation.session as session
import configparser

def predict(env_id, sess_id, msg, mode = 0):
    ini = configparser.SafeConfigParser()
    ini.read(cd + env_id + '/conf.ini')
    
    condition = session.get(id)
    
    thre = ''
    if condition['status'] == 'estimation':
        thre = float(ini.get('threshold', 'es_thre'))
    elif condition['status'] == 'understand':
        thre = float(ini.get('threshold', 'un_thre'))
    elif condition['status'] == 'steady':
        thre = float(ini.get('threshold', 'st_thre'))
    
    msg = language.wakachi_sp([msg])
    label = pkl.load(os.environ.get('CHATBOT_ENV') + '/' + env_id + '/pickle/document/sp.pkl')
    full = pkl.load(os.environ.get('CHATBOT_ENV') + '/' + env_id + '/pickle/vector/sp.pkl')
    mlp = pkl.load(os.environ.get('CHATBOT_ENV') + '/' + env_id + '/pickle/model/sp.pkl')
    
    X = full.transform(msg)
    
    prob = {}
    for i in range(len(label)):
        prob[label[i]] = mlp[i].predict(X)[1][0]
    
    if thre < prob['neutral'] and mode == 0:
        return 'neutral'
    else:
        list = []
        for item in prob.items():
            if thre < item[1]:
                list.append(item[0])
        
        return list

