# -*- coding: utf-8 -*-
import os.path, sys, datetime, configparser, time, random
import operation.topic as topic, operation.process as process, operation.proposal as proposal, operation.session as session, operation.consult as consult, operation.close as close, operation.pn as pn

#contextの仕様
# userhome   対象ユーザーのセッションパス
# request    ユーザーの問合せ内容（本件）
# response   ボットの回答内容
# message    ユーザーの返答内容
# datetime   問合せ開始時点での日時
# status     ボットの状態
# topic      対話のテーマ
# topic_list 対話のテーマの候補

#statusの仕様：
# greeting    挨拶のステップ
# estimation  トピック推定のステップ
# confirm     トピック確定のステップ
# understand  回答確定のステップ
# steady      連続問合せ及び新しい問合せを受け付けるステップ
# close       問合せを終了するステップ
# consult     回答の対応を担当者に引き継ぐステップ
# through     ここから先の処理はしない

def run(env_id, sess_id, message = ''):
    # 学習データのアップデート中は、それが終了するまで待機
    while os.path.exists(os.environ.get('CHATBOT_ENV') + '/' + env_id + '/wait'):
        pass
    
    # セッションがなければ生成し、あれば取得
    context = []
    if not os.path.exists(os.environ.get('CHATBOT_ENV') + '/' + env_id + '/session/' + sess_id):
        os.mkdir(os.environ.get('CHATBOT_ENV') + '/' + env_id + '/session/' + sess_id)
    else:
        context = session.get(env_id = env_id, sess_id = sess_id)
        if context == 1:
            return {'response': 'アクセスが込み合っております。<br>少々時間を置いてお問い合わせください。'}
        elif context == 2:
            return {'response': '致命的なアクセスエラーが発生しました。<br>管理者に通知しましたので、対応をお待ちください。', 'topic': 'system', 'status': 'consult'}
    #####
    
    # 問合せ内容をログに出力
    with open(os.environ.get('CHATBOT_ENV') + '/' + env_id + '/data/chat.log', 'a', encoding = 'utf8') as f:
        f.write(sess_id + ',' + message)
        f.write('\n')
    #####
    
    # 問合せがあれば処理し、なければ「何ですか？」を返す
    if message != '' and not message.startswith('もしもし'):
        # 確定したテーマを元に、継続して回答を導き出す
        # トピックの変更を検知した場合、ステータス"greeting"を返す
        if context != []:
            if context[-1]['status'] in {'steady'}:
                context[-1]['message'] = message
                context[-1] = process.run(context[-1], env_id, sess_id)
        #####
        
        # 最初の問合せの際に、問合せのテーマを推定する
        # 新しい問合せの際に、テーマを追加する
        if context == [] or (context[-1]['status'] in {'greeting', 'failed', 'close'}):
            context.append(topic.run(env_id, {'userid': sess_id, 'userhome': os.environ.get('CHATBOT_ENV') + '/' + env_id + '/session/' + sess_id, 'request': message, 'message' : message, 'response': None, 'datetime': datetime.datetime.today(), 'status': 'greeting', 'topic': None, 'topic_list': None, 'learning': [], 'pardon': 0, 'gene_flg': False, 'content': None}))
        else:
            context[-1]['message'] = message
        #####
        
        if context[-1]['status'] != 'direct':
            context[-1]['request'] = message
        
        # 推定したテーマを確定する
        if context[-1]['status'] in {'estimation', 'direct', 'confirm'}:
            context[-1] = topic.predict(env_id, context[-1])
            # 追加されたテーマが、前回と同じテーマであれば削除する
            if 1 < len(context) and (context[-1]['topic'] == context[-2]['topic']):
                context.pop(-2)
            #####
        #####
        
        # 確定したテーマを元に回答を導き出す
        # テーマを即座に確定できなかった場合、学習データとして残す
        if context[-1]['status'] in {'understand'}:
            if context[-1]['learning'] != []:
                context[-1]['learning'].append(context[-1]['topic'])
            context[-1] = process.run(context[-1], env_id, sess_id)
        #####
        
        # 回答できなかった際、担当者に引き継ぐ
        if context[-1]['status'] in {'abandon', 'consult'}:
            context.append(consult.push(context))
        
        # 次の問合せを予測・提案
        if context[-1]['status'] in {'proposal'}:
            if os.path.exists(context[-1]['userhome'] + '/../../pickle/model/markov.pkl'):
                if not context[-1]['gene_flg']:
                    context.append(proposal.run(context[-1], env_id))
                    if context[-1]['topic'] is not None:
                        context[-1]['gene_flg'] = True
                        context[-1]['response'] += ('<transaction>' + context[-1]['topic'] + 'についてのお問い合わせはいかがですか？')
                    else:
                        context[-1]['status'] = 'close'
                else:
                    if 1 == pn.predict(context[-1]):
                        context[-1] = process.run(context[-1], env_id, sess_id)
                    elif -1 == pn.predict(context[-1]):
                        context[-1]['status'] = 'close'
                    else:
                        print('未実装1')
            else:
                context[-1]['status'] = 'close'
        
        # 問合せを終了
        #if context[-1]['status'] in {'close'}:
        #    context.append(close.run(context[-1]))
    else:
        ini = configparser.SafeConfigParser()
        ini.read(os.environ.get('CHATBOT_ENV') + '/' + env_id + '/conf.ini')
        greeting = ini.get('message', 'greeting').rstrip('\n').split(',')
        context.append({'userid': sess_id, 'userhome': os.environ.get('CHATBOT_ENV') + '/' + env_id + '/session/' + sess_id, 'request': message, 'response': random.choice(greeting), 'datetime': datetime.datetime.today(), 'status': 'greeting', 'topic': None, 'topic_list': None, 'learning': [], 'pardon': 0, 'gene_flg': False, 'content': None})
    #####
    
    # コンテキストをファイルに出力
    result = session.set(context)
    
    if result == 1:
        return {'response': 'アクセスが込み合っております。<br>少々時間を置いてお問い合わせください。'}
    elif result == 2:
        return {'response': '致命的なアクセスエラーが発生しました。<br>管理者に通知しましたので、対応をお待ちください。', 'topic': 'system', 'status': 'consult'}
    #####
    
    # 回答内容をログに出力
    with open(os.environ.get('CHATBOT_ENV') + '/' + env_id + '/data/chat.log', 'a', encoding = 'utf8') as f:
        f.write('system(' + sess_id + '),' + context[-1]['response'])
        f.write('\n')
    #####
    
    return {'request': context[-1]['request'], 'response': context[-1]['response'], 'topic': context[-1]['topic'], 'topic_list': context[-1]['topic_list'], 'status': context[-1]['status'], 'learning': context[-1]['learning'], 'content': context[-1]['content']}

