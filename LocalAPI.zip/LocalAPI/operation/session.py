# -*- coding: utf-8 -*-
import time
import os.path, common.pkl as pkl, glob, common.filelock as filelock

def set(context):
    fl = filelock.FileLock(context[-1]['userhome'] + '/../../config/filelock')
    for i in range(100):
        if fl.acquire(context[-1]['userhome'] + '/context.pkl'):
            pkl.dump(context, context[-1]['userhome'] + '/context.pkl')
            for i in range(100):
                if fl.release(context[-1]['userhome'] + '/context.pkl'):
                    return 0
                else:
                    time.sleep(0.1)
            else:
                return 2
        else:
            time.sleep(0.1)
    else:
        return 1

def get(context = None, env_id = None, sess_id = None):
    path = None
    if context is None:
        path = os.environ.get('CHATBOT_ENV') + '/' + env_id + '/session/' + sess_id + '/context.pkl'
    else:
        path = context[-1]['userhome'] + '/context.pkl'
    
    fl = filelock.FileLock(os.environ.get('CHATBOT_ENV') + '/' + env_id + '/config/filelock')
    for i in range(100):
        if fl.acquire(path):
            context = pkl.load(path)
            for i in range(100):
                if fl.release(path):
                    return context
                else:
                    time.sleep(0.1)
            else:
                return 2
        else:
            time.sleep(0.1)
    else:
        return 1

def remove(context):
    os.remove(context[-1]['userhome'] + '/context.pkl')

