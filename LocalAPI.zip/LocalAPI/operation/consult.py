import configparser
import threading
import time
import datetime
import operation.pn as pn

def push(context):
    if 1 == pn.predict(context[-1]):
        ini = configparser.SafeConfigParser()
        ini.read(context[-1]['userhome'] + '/../../conf.ini')
        
        manager = ini.get('setting', 'manager')
        manager = manager.replace(', ', ',').replace(' ,', ',').replace(' , ', ',').replace(': ', ':').replace(' :', ':').replace(' : ', ':')
        
        group = manager.split(',')
        
        manager = {}
        for row in group:
            item = row.split(':')
            manager[item[0]] = item[1]
        
        target = None
        for i in range(len(context)):
            target = context[i]['topic']
        
        talk_list = []
        with open(context[-1]['userhome'] + '/../../data/chat.log', 'r', encoding = 'utf8') as f:
            for line in f:
                if context[-1]['userid'] in line.rstrip('\n').split(',')[0]:
                    talk_list.append(line.rstrip('\n').replace(',', ': '))
        
        manager = manager[target if target is not None else 'master']
        
        thread = ConsultThread()
        thread.start()
        
        return {'request': context[-1]['request'], 'response': '担当者に問合せました。<br>担当者からの回答をお待ちください。', 'topic': context[-1]['topic'], 'topic_list': context[-1]['topic_list'], 'status': context[-1]['status'], 'learning': context[-1]['learning']}
    elif -1 == pn.predict(context[-1]):
        return {'request': context[-1]['request'], 'response': '問合せを終了します。', 'topic': context[-1]['topic'], 'topic_list': context[-1]['topic_list'], 'status': context[-1]['status'], 'learning': context[-1]['learning']}
    else:
        return {'request': context[-1]['request'], 'response': '未実装2', 'topic': context[-1]['topic'], 'topic_list': context[-1]['topic_list'], 'status': context[-1]['status'], 'learning': context[-1]['learning']}

class ConsultThread(threading.Thread):
    def __init__(self):
        super(ConsultThread, self).__init__()
    
    def run(self):
        for i in range(30):
            print(i)
            time.sleep(1)

