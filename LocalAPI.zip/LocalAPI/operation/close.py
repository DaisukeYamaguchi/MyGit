def run(context):
    return {'request': context['request'], 'response': '問合せを終了します。', 'userhome': context['userhome'], 'topic': None, 'topic_list': None, 'status': 'close', 'learning': None, 'content': None}

