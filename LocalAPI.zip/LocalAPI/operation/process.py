import os.path
import common.pkl as pkl
import operation.knn as knn, operation.pn as pn
import configparser
import auxiliary.rsv as rsv
import auxiliary.bsn as bsn
import auxiliary.gmp as gmp
import auxiliary.gzr as gzr

def run(context, env_id, sess_id):
    ini = configparser.SafeConfigParser()
    ini.read(context['userhome'] + '/../../conf.ini')
    
    property = ini.get('process', 'setting')
    property = property.replace(', ', ',').replace(' ,', ',').replace(' , ', ',').replace(': ', ':').replace(' :', ':').replace(' : ', ':')
    
    setting = property.split(',')
    
    process = {}
    for row in setting:
        item = row.split(':')
        process[item[0]] = item[1]
    
    if process[context['topic']] == 'knn':
        context = knn.predict(context, env_id, context['topic'])
    elif process[context['topic']] == 'rsv':
        context = rsv.run(env_id, context)
    elif process[context['topic']] == 'bsn':
        context = bsn.run(env_id, context)
    elif process[context['topic']] == 'gmp':
        context = gmp.run(env_id, context)
    elif process[context['topic']] == 'gzr':
        context = gzr.run(env_id, context)
    
    return context
