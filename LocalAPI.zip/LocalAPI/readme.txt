//環境構築
http://localhost:5000/operate?environment=myenv&action=create

//学習（データは自前でアップロード）
http://localhost:5000/operate?environment=myenv&action=training&mode=update

//環境削除
http://localhost:5000/operate?environment=myenv&action=delete

//問合せ
http://localhost:5000/operate?environment=myenv&action=chat&id=yamaguchi&status=taking

//問合せ終了
http://localhost:5000/operate?environment=myenv&action=chat&id=yamaguchi&status=end

//デバッグ実行
import operation.entrance as ent
ent.run('myenv', 'yamaguchi', 'メッセージ')
