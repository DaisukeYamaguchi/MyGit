# -*- coding: utf-8 -*
from janome.tokenizer import Tokenizer

def status(sentence):
  t = Tokenizer()
  tokens = t.tokenize(sentence)
  
  for token in tokens:
      print(token)
  
  return result

