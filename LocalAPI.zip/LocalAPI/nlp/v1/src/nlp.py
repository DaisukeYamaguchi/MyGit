# -*- coding: utf-8 -*
from janome.tokenizer import Tokenizer

def get_proper_noun(sentence):
  t = Tokenizer()
  tokens = t.tokenize(sentence)
  
  nouns = []
  noun = ''
  for token in tokens:
    if token.part_of_speech.split(',')[0] == '名詞':
      noun += token.surface
    elif noun != '':
      nouns.append(noun)
      noun = ''
  
  if noun != '':
    nouns.append(noun)
  
  return nouns

