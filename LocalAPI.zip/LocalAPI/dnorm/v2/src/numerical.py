# -*- coding: utf-8 -*
import os.path
from janome.tokenizer import Tokenizer

def formula(text):
    
    t = Tokenizer('./dict.csv')
    
    tokens = t.tokenize(text)
    
    sentence = ''
    for token in tokens:
        if token.part_of_speech.split(',')[0] == '助詞':
            sentence += token.base_form
        else:
            sentence += token.surface
    
    return sentence

