# -*- coding: utf-8 -*
import os.path, re, datetime, requests, json
import dnorm.v2.src.numerical as numerical

def norm(sentence):
    url = 'https://labs.goo.ne.jp/api/chrono'
    data = {'app_id': '3152d5c551b78c99091e581f5c64f32975d1910db7d29988d8c9b6760edcf13a', 'sentence': sentence}
    headers = {'content-type': 'application/json'}
    
    res = requests.post(url, data = json.dumps(data), headers = headers)
    
    res = json.loads(res.text)
    
    for item in res['datetime_list']:
        item[1] = item[1].split('T')
        item[1] = item[1][0] if len(item[1]) == 1 else item[1][1]
        sentence = sentence.replace(item[0], '{{' + item[1] + '}}')
    
    result = {
        'from': {'date': None, 'time': None},
        'to': {'date': None, 'time': None},
        'on': {'date': None, 'time': None}
    }
    
    print(numerical.formula(sentence))
    
    match = re.findall('{{(\d{4}-\d{2}-\d{2})}}に', sentence)
    if 0 < len(match):
        result['on']['date'] = match[0][0]
    
    match = re.findall('{{(\d{2}:\d{2})}}に', sentence)
    if 0 < len(match):
        result['on']['time'] = match[0][0]
    
    match = re.findall('{{(\d{4}-\d{2}-\d{2})}}の*{{(\d{2}:\d{2})}}に', sentence)
    if 0 < len(match):
        result['on']['date'] = match[0][0]
        result['on']['time'] = match[0][1]
    
    match = re.findall('{{(\d{4}-\d{2}-\d{2})}}で', sentence)
    if 0 < len(match):
        result['on']['date'] = match[0][0]
    
    match = re.findall('{{(\d{2}:\d{2})}}で', sentence)
    if 0 < len(match):
        result['on']['time'] = match[0][0]
    
    match = re.findall('{{(\d{4}-\d{2}-\d{2})}}の*{{(\d{2}:\d{2})}}で', sentence)
    if 0 < len(match):
        result['on']['date'] = match[0][0]
        result['on']['time'] = match[0][1]
    
    match = re.findall('{{(\d{4}-\d{2}-\d{2})}}(から|～|以降)', sentence)
    if 0 < len(match):
        result['from']['date'] = match[0][0]
    
    match = re.findall('{{(\d{2}:\d{2})}}(から|～|以降)', sentence)
    if 0 < len(match):
        result['from']['time'] = match[0][1]
    
    match = re.findall('{{(\d{4}-\d{2}-\d{2})}}の*{{(\d{2}:\d{2})}}(から|～|以降)', sentence)
    if 0 < len(match):
        result['from']['date'] = match[0][0]
        result['from']['time'] = match[0][1]
    
    match = re.findall('{{(\d{4}-\d{2}-\d{2})}}まで', sentence)
    if 0 < len(match):
        result['to']['date'] = match[0][0]
    
    match = re.findall('{{(\d{2}:\d{2})}}まで', sentence)
    if 0 < len(match):
        result['to']['time'] = match[0][1]
    
    match = re.findall('{{(\d{4}-\d{2}-\d{2})}}の*{{(\d{2}:\d{2})}}まで', sentence)
    if 0 < len(match):
        result['to']['date'] = match[0][0]
        result['to']['time'] = match[0][1]
    
    match = re.findall('(から|～){{(\d{4}-\d{2}-\d{2})}}', sentence)
    if 0 < len(match):
        result['to']['date'] = match[0][0]
    
    match = re.findall('(から|～){{(\d{2}:\d{2})}}', sentence)
    if 0 < len(match):
        result['to']['time'] = match[0][1]
    
    match = re.findall('(から|～){{(\d{4}-\d{2}-\d{2})}}の*{{(\d{2}:\d{2})}}', sentence)
    if 0 < len(match):
        result['to']['date'] = match[0][0]
        result['to']['time'] = match[0][1]
    
    # 調整（onがNoneの時はfromを使用するとか）
    if result['on']['date'] is None and result['on']['time'] is None:
        if result['from']['date'] is not None and result['from']['time'] is not None:
            result['on']['date'] = result['from']['date']
            result['on']['time'] = result['from']['time']
            result['from']['date'] = None
            result['from']['time'] = None
    
    return result

