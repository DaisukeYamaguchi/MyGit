# -*- coding: utf-8 -*
import os, shutil, time
from datetime import datetime
import setup.initial as init, operation.session as session, common.filelock as filelock

def run():
    while True:
        env_dir = os.environ.get('CHATBOT_ENV')
        env_list = os.listdir(env_dir)
        for env in env_list:
            markov_data = []
            for file in find_all_files(env_dir + '/' + env, 'context.pkl'):
                delta = datetime.now() - datetime.fromtimestamp(os.stat(file).st_mtime)
                if 10 < delta.total_seconds():
                    context = session.get(context = [{'userhome': file.rstrip('context.pkl').rstrip(os.sep)}], env_id = env)
                    trans = 'START,'
                    for theme in context:
                        if theme['topic'] is not None:
                            trans += (theme['topic'] + ',')
                    trans += 'END'
                    markov_data.append(trans)
            if markov_data != []:
                with open(env_dir + '/' + env + '/data/markov_data.csv', 'a', encoding = 'utf8') as f:
                    for row in markov_data:
                        f.write(row)
                        f.write('\n')

def find_all_files(directory, regex):
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(regex):
                yield os.path.join(root, file)

