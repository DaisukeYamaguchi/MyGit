# -*- coding: utf-8 -*
import os, shutil, time
import setup.initial as init, operation.session as session, common.filelock as filelock

def run():
    env_dir = os.environ.get('CHATBOT_ENV')
    env_list = os.listdir(env_dir)
    while True:
        for env in env_list:
            context_list = []
            log = {}
            get = {}
            additional_data = []
            if os.path.exists(env_dir + '/' + env + '/data/additional.log'):
                with open(env_dir + '/' + env + '/data/additional.log', 'r', encoding = 'utf8') as f:
                    for row in f:
                        row = row.rstrip('\n').split(',')
                        log[row[0]] = row[1]
            for file in find_all_files(env_dir + '/' + env, 'context.pkl'):
                user = file.split(os.sep)[-2]
                last = 0
                if user in log.keys():
                    last = int(log[user])
                context = session.get(context = [{'userhome': file.rstrip('context.pkl').rstrip(os.sep)}], env_id = env)
                if last < len(context):
                    rows = 0
                    for i in range(last, len(context)):
                        if 3 == len(context[i]['learning']):
                            additional_data.append(','.join(context[i]['learning']))
                        rows += 1
                    get[user] = str(len(context))
                else:
                    get[user] = log[user]
            with open(env_dir + '/' + env + '/data/additional.log', 'w', encoding = 'utf8') as f:
                for row in get.items():
                    f.write(','.join(row))
                    f.write('\n')
            if additional_data != []:
                with open(env_dir + '/' + env + '/data/train_data.csv', 'a', encoding = 'utf8') as f:
                    for row in additional_data:
                        f.write(row)
                        f.write('\n')
                result = init.init_train(env + '/data/staging', 'add')
        if True or result['message'].startswith('Succeeded'):
            with open(env_dir + '/' + env + '/wait', 'w', encoding = 'utf8') as f:
                f.write('')
            time.sleep(1)
            for files in find_all_files(env_dir + '/' + env + '/data/staging', '.pkl'):
                result = put(env, files)
                os.remove(files)
            os.remove(env_dir + '/' + env + '/wait')
        else:
            print(env + ': 管理者に通知')

def find_all_files(directory, regex):
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(regex):
                yield os.path.join(root, file)

def put(env_id, files):
    fl = filelock.FileLock(os.environ.get('CHATBOT_ENV') + '/' + env_id  + '/config/filelock')
    for i in range(100):
        if fl.acquire(files.replace('/data/staging', '')):
            shutil.copyfile(files, files.replace('/data/staging', ''))
            for i in range(100):
                if fl.release(files.replace('/data/staging', '')):
                    return 0
                else:
                    time.sleep(1)
            else:
                return 2
        else:
            time.sleep(1)
    else:
        return 1

