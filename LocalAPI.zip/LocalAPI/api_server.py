# -*- coding: utf-8 -*
import json
import falcon
import setup.setup as setup
import knn.v1.setup.setup as setup
import knn.v1.operation.knn as knn
import dnorm.v1.src.dnorm as dnorm

# /knn/v1/environments
class KnnEnvironmentsResourceV1(object):
    def on_get(self, req, resp):
        response = None
        response = setup.create_env()
        resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /knn/v1/documents?environment_id={環境名}&document={学習データ（JSON）}
class KnnDocumentsResourceV1(object):
    def on_get(self, req, resp):
        response = None
        if 'environment_id' in req.params.keys():
            if 'document' in req.params.keys():
                response = setup.create_doc(req.params['environment_id'], req.params['document'])
            else:
                response = 'パラメータ：document を指定してください。'
        else:
            response = 'パラメータ：environment_id を指定してください。'
        
        resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /knn/v1/update?environment_id={環境名}&query={クエリ}
class KnnUpdateResourceV1(object):
    def on_get(self, req, resp):
        response = None
        if 'environment_id' in req.params.keys():
            if 'query' in req.params.keys():
                response = setup.update_doc(req.params['environment_id'], req.params['query'])
            else:
                response = 'パラメータ：query を指定してください。'
        else:
            response = 'パラメータ：environment_id を指定してください。'
        
        resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /knn/v1/view?environment_id={環境名}
class KnnViewResourceV1(object):
    def on_get(self, req, resp):
        response = None
        if 'environment_id' in req.params.keys():
            response = setup.view_doc(req.params['environment_id'])
        else:
            response = 'パラメータ：environment_id を指定してください。'
        
        resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /knn/v1/training_data?environment_id={環境名}&training_field{カラム名}
class KnnTrainingResourceV1(object):
    def on_get(self, req, resp):
        response = None
        if 'environment_id' in req.params.keys():
            if 'training_field' in req.params.keys():
                response = setup.training_doc(req.params['environment_id'], req.params['training_field'])
            else:
                response = 'パラメータ：training_field を指定してください。'
        else:
            response = 'パラメータ：environment_id を指定してください。'
        
        resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /knn/v1/query?environment_id={環境名}&request={問合せ内容}
class KnnQueryResourceV1(object):
    def on_get(self, req, resp):
        response = None
        if 'environment_id' in req.params.keys():
            if 'request' in req.params.keys():
                response = knn.predict(req.params['environment_id'], req.params['request'])
            else:
                response = 'パラメータ：request を指定してください。'
        else:
            response = 'パラメータ：environment_id を指定してください。'
        
        resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

# /d-norm/v1/query?request={問合せ内容}
class DNormQueryResourceV1(object):
    def on_get(self, req, resp):
        response = None
        if 'request' in req.params.keys():
            response = dnorm.norm(req.params['request'])
        else:
            response = 'パラメータ：request を指定してください。'
        
        resp.body = json.dumps(response, indent=4, sort_keys=True, ensure_ascii=False)

app = falcon.API()

app.add_route("/knn/v1/environments", KnnEnvironmentsResourceV1())
app.add_route("/knn/v1/documents", KnnDocumentsResourceV1())
app.add_route("/knn/v1/update", KnnUpdateResourceV1())
app.add_route("/knn/v1/view", KnnViewResourceV1())
app.add_route("/knn/v1/training_data", KnnTrainingResourceV1())
app.add_route("/knn/v1/query", KnnQueryResourceV1())
app.add_route("/d-norm/v1/query", DNormQueryResourceV1())

if __name__ == "__main__":
    from wsgiref import simple_server
    httpd = simple_server.make_server("", 14000, app)
    print('server listening...')
    httpd.serve_forever()

