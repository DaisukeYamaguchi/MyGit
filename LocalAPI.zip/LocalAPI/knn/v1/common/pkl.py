# -*- coding: utf-8 -*
import os.path, pickle

def dump(obj, file):
    with open(file,'wb') as f:
        pickle.dump(obj, f, protocol=4)

def load(file):
    with open(file,'rb') as f:
        obj = pickle.load(f)
    return obj
