# -*- coding: utf-8 -*
import os.path
from janome.tokenizer import Tokenizer

def wakachi_nv(env_id, text, dict = 'dict.csv'):
    cd = os.path.expanduser('~') + '/Chatbot/environments/' + env_id
    
    t = Tokenizer()#
    if os.path.exists(cd + '/data/' + dict):
        t = Tokenizer(cd + '/data/' + dict)
    
    for i in range(len(text)):
        line = []
        tokens = t.tokenize(text[i])
        
        for token in tokens:
            if token.part_of_speech.split(',')[0] == '名詞' or token.part_of_speech.split(',')[0] == '動詞':
                if token.base_form != '*':
                    line.append(token.base_form)
        text[i] = ' '.join(line)
    
    return text

def wakachi_n(text):
    t = Tokenizer()
    for i in range(len(text)):
        line = []
        tokens = t.tokenize(text[i])
        for token in tokens:
            if token.part_of_speech.split(',')[0] == '名詞':
                if token.base_form != '*':
                    line.append(token.base_form)
        text[i] = ' '.join(line)
    return text

def wakachi_pn(text):
    t = Tokenizer()
    
    for i in range(len(text)):
        line = []
        tokens = t.tokenize(text[i])
        for token in tokens:
            if token.part_of_speech.split(',')[0] == '名詞' or token.part_of_speech.split(',')[0] == '動詞' or token.part_of_speech.split(',')[0] == '助動詞' or token.part_of_speech.split(',')[0] == '感動詞' or token.part_of_speech.split(',')[0] == '副詞':
                if token.base_form != '*':
                    line.append(token.base_form)
        text[i] = ' '.join(line)
    return text

def wakachi_sp(text):
    t = Tokenizer()
    
    for i in range(len(text)):
        line = []
        tokens = t.tokenize(text[i])
        for token in tokens:
            if token.part_of_speech.split(',')[0] == '名詞' or token.part_of_speech.split(',')[0] == '動詞' or token.part_of_speech.split(',')[0] == '助動詞' or token.part_of_speech.split(',')[0] == '感動詞' or token.part_of_speech.split(',')[0] == '副詞':
                if token.base_form != '*':
                    line.append(token.base_form)
        text[i] = ' '.join(line)
    return text

def text_trans(env_id, sentence, dict = 'dict.csv'):
    cd = os.path.expanduser('~') + '/Chatbot/environments/' + env_id
    
    t = Tokenizer()
    if os.path.exists(cd + '/data/' + dict):
        t = Tokenizer(cd + '/data/' + dict)
    
    tokens = t.tokenize(sentence)
    
    sentence = ''
    for token in tokens:
        if token.part_of_speech.split(',')[0] != '記号':
            if token.part_of_speech.split(',')[1] == 'ユーザー定義' and token.part_of_speech.split(',')[2] == '時間':
                sentence = sentence + token.base_form
            else:
                sentence = sentence + token.surface
    
    return sentence

def get_proper_noun(env_id, sentence, dict = 'dict.csv'):
    cd = os.path.expanduser('~') + '/Chatbot/environments/' + env_id
    
    t = Tokenizer()
    if os.path.exists(cd + '/data/' + dict):
        t = Tokenizer(cd + '/data/' + dict)
    
    tokens = t.tokenize(sentence)
    
    member = None
    place = None
    for token in tokens:
        if token.part_of_speech.split(',')[2] == '人名':
            if member == None:
                member = []
            
            member.append(token.surface)
        elif token.part_of_speech.split(',')[1] == 'ユーザー定義' and token.part_of_speech.split(',')[2] == '場所':
            if place == None:
                place = []
            
            place.append(token.surface)
    
    return member, place

def get_from_to(env_id, sentence, dict = 'dict.csv'):
    cd = os.path.expanduser('~') + '/Chatbot/environments/' + env_id
    
    t = Tokenizer()
    if os.path.exists(cd + '/data/' + dict):
        t = Tokenizer(cd + '/data/' + dict)
    
    tokens = t.tokenize(sentence)
    stop_word = {'場所', 'どこ', '地図', 'マップ', '検索', 'バス', '行き', '時刻表' ,'時刻'}
    
    where = {'from': None, 'to': None}
    place = None
    for token in tokens:
        if place is None:
            if token.part_of_speech.split(',')[0] == '名詞' and token.part_of_speech.split(',')[1] != '非自立' and token.part_of_speech.split(',')[1] != '数' and token.part_of_speech.split(',')[1] != '接尾' and token.part_of_speech.split(',')[1] != 'サ変接続' and token.surface not in stop_word:
                place = token.surface
        else:
            if token.part_of_speech.split(',')[0] == '名詞' and token.surface not in stop_word:
                place += token.surface
            else:
                if token.base_form in {'から'}:
                    where['from'] = place
                else:
                    where['to'] = place
                place = None
    
    if where['to'] is None and place is not None:
        where['to'] = place
    
    return where

def get_place(env_id, sentence, dict = 'dict.csv'):
    cd = os.path.expanduser('~') + '/Chatbot/environments/' + env_id
    
    t = Tokenizer()
    if os.path.exists(cd + '/data/' + dict):
        t = Tokenizer(cd + '/data/' + dict)
    
    tokens = t.tokenize(sentence)
    stop_word = {'場所', 'どこ', '地図', 'マップ', '検索'}
    
    place = None
    for token in tokens:
        if place == None:
            if token.part_of_speech.split(',')[0] == '名詞' and token.part_of_speech.split(',')[1] != '非自立' and token.part_of_speech.split(',')[1] != 'サ変接続' and token.surface not in stop_word:
                place = token.surface
        else:
            if token.part_of_speech.split(',')[0] == '名詞':
                place += token.surface
            else:
                return place
    
    return place

def get_noun(env_id, sentence, dict = 'dict.csv'):
    cd = os.path.expanduser('~') + '/Chatbot/environments/' + env_id
    
    t = Tokenizer()
    if os.path.exists(cd + '/data/' + dict):
        t = Tokenizer(cd + '/data/' + dict)
    
    tokens = t.tokenize(sentence)
    
    noun = None
    for token in tokens:
        if noun == None:
            if token.part_of_speech.split(',')[0] == '名詞' and token.part_of_speech.split(',')[1] != '非自立' and token.part_of_speech.split(',')[1] != 'サ変接続':
                noun = token.surface
        else:
            if token.part_of_speech.split(',')[0] == '名詞':
                noun += token.surface
            else:
                return noun
    
    return noun

def get_number(text):
    
    t = Tokenizer()
    
    tokens = t.tokenize(text)
    
    line = []
    temp = None
    for token in tokens:
        if temp == None:
            if token.part_of_speech.split(',')[0] == '名詞' and token.part_of_speech.split(',')[1] == '数':
                temp = token.surface
        else:
            if token.surface == '番':
                line.append(temp)
    
    return line

