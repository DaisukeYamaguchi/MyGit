# -*- coding: utf-8 -*
import os.path
import knn.v1.common.pkl as pkl, knn.v1.common.language as language
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.feature_extraction.text import TfidfVectorizer

def run(env_id, data):
    data = np.array(data)
    
    X = language.wakachi_nv(env_id, data[:,1])
    
    vector = TfidfVectorizer(use_idf = True, min_df = 1)
    vector.fit_transform(X)
    
    X = vector.transform(X)
    
    clf = KNeighborsClassifier(n_neighbors = 10)
    
    clf.fit(X, data[:,0])
    
    pkl.dump(vector, os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments/' + env_id + '/pickle/vector.pkl')
    pkl.dump(clf, os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments/' + env_id + '/pickle/model.pkl')
    pkl.dump(X.toarray(), os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments/' + env_id + '/pickle/matrix.pkl')

