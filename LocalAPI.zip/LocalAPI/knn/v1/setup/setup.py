# -*- coding: utf-8 -*-
import os, sys, copy, configparser, shutil, string, random, sqlite3
import knn.v1.common.pkl as pkl
import numpy as np
import ast, knn.v1.setup.knn as knn

def create_env():
    response = None
    
    dirs = os.listdir(os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments')
    
    env_id = None
    chars = string.digits + ''.join([chr(i) for i in range(97,97+26)])
    while(True):
        name = []
        for i in range(2):
            name.append(''.join([random.choice(chars) for i in range(4)]))
        
        if '-'.join(name) not in dirs:
            env_id = '-'.join(name)
            shutil.copytree(os.environ.get('LOCALAPI_HOME') + '/knn/v1/template/env', os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments/' + env_id)
            response = {'environment_id': env_id}
            break
    
    return response

def create_doc(env_id, document):
    response = None
    
    dbpath = os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments/' + env_id + '/data/local.sqlite'
    connection = sqlite3.connect(dbpath)
    
    connection.isolation_level = None
    cur = connection.cursor()
    
    if document != "{}":
        document = ast.literal_eval(','.join(document))
        res = cur.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % 'train_data')
        if res.fetchone() is None:
            cols = ['_index INTEGER PRIMARY KEY']
            for col in document.keys():
                cols.append(col + ' TEXT')
            
            cur.execute('CREATE TABLE train_data (' + ', '.join(cols) + ')')
        
        cols = []
        vals = []
        for item in document.items():
            cols.append(item[0])
            vals.append('\'' + item[1] + '\'')
        
        cur.execute('INSERT INTO train_data(' + ', '.join(cols) + ') VALUES (' + ', '.join(vals) + ')')
        
        response = { 'message': '学習データを登録しました。' }
    else:
        res = cur.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % 'train_data')
        if res.fetchone() is not None:
            cur.execute("drop table train_data;")
            response = { 'message': '学習データを削除しました。'}
        else:
            response = { 'message': '学習データが存在しません。'}
    
    return response

def update_doc(env_id, query):
    response = None
    
    dbpath = os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments/' + env_id + '/data/local.sqlite'
    connection = sqlite3.connect(dbpath)
    
    connection.isolation_level = None
    cur = connection.cursor()
    
    query = ast.literal_eval(','.join(query))
    
    if query['value'] != {}:
        keys = []
        for item in query['key'].items():
            keys.append(item[0] + '="' + item[1] + '"')
        
        vals = []
        for item in query['value'].items():
            vals.append(item[0] + '="' + item[1] + '"')
        
        print('UPDATE train_data SET ' + ','.join(vals) + ' WHERE ' + ' and '.join(keys))
        cur.execute('UPDATE train_data SET ' + ','.join(vals) + ' WHERE ' + ' and '.join(keys))
        
        response = { 'message': '学習データを更新しました。' }
    else:
        keys = []
        for item in query['key'].items():
            keys.append(item[0] + '="' + item[1] + '"')
        
        cur.execute('DELETE FROM train_data WHERE ' + ' and '.join(keys))
        
        response = { 'message': '学習データを削除しました。'}
    
    return response

def view_doc(env_id):
    response = None
    
    dbpath = os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments/' + env_id + '/data/local.sqlite'
    connection = sqlite3.connect(dbpath)
    
    connection.isolation_level = None
    cur = connection.cursor()
    
    res = cur.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % 'train_data')
    if res.fetchone() is not None:
        cols = []
        cur.execute('SELECT * FROM train_data')
        for col in cur.description:
            cols.append(col[0])
        
        cols.remove("_index")
        
        cur.execute('SELECT ' + ','.join(cols) + ' FROM train_data')
        results = []
        for row in cur.fetchall():
            x = dict(zip([d[0] for d in cur.description], row))
            results.append(x)
        
        response = results
    else:
        response = { 'message': '学習データが存在しません。'}
    
    return response

def training_doc(env_id, field):
    response = None
    
    dbpath = os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments/' + env_id + '/data/local.sqlite'
    connection = sqlite3.connect(dbpath)
    
    connection.isolation_level = None
    cur = connection.cursor()
    
    res = cur.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % 'train_data')
    if res.fetchone() is not None:
        cur.execute('SELECT _index, ' + field + ' FROM train_data')
        results = []
        for row in cur:
            results.append(row)
        
        if 10 <= len(results):
            knn.run(env_id, results)
            response = { 'message': '学習を完了しました。'}
        else:
            response = { 'message': '学習データは最低１０件必要です。'}
    else:
        response = { 'message': '学習データが存在しません。'}
    
    return response

