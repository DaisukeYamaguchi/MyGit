# -*- coding: utf-8 -*-
import os, copy, sqlite3
import knn.v1.common.language as language, knn.v1.common.pkl as pkl
import numpy as np
import pandas as pd

def predict(env_id, request):
    response = None
    
    dbpath = os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments/' + env_id + '/data/local.sqlite'
    connection = sqlite3.connect(dbpath)
    
    connection.isolation_level = None
    cur = connection.cursor()
    
    res = cur.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % 'train_data')
    if res.fetchone() is not None:
        if os.path.exists(os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments/' + env_id + '/pickle/model.pkl'):
            msg = language.wakachi_nv(env_id, [request])
            os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments/' + env_id + '/pickle/local.sqlite'
            vector = pkl.load(os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments/' + env_id + '/pickle/vector.pkl')
            clf = pkl.load(os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments/' + env_id + '/pickle/model.pkl')
            matrix = pkl.load(os.environ.get('LOCALAPI_HOME') + '/knn/v1/environments/' + env_id + '/pickle/matrix.pkl')
            
            X = vector.transform(msg)
            distances, indices = clf.kneighbors(X)
            
            #mask = indices != np.arange(indices.shape[0])[:,np.newaxis]
            #mask[:,-1] &= np.logical_not(mask.all(axis=1))
            #shape = (indices.shape[0], indices.shape[1] - 1)
            #indices = indices[mask].reshape(shape)
            
            data = []
            for index in indices[0]:
                cur.execute('select * from train_data where _index = ' + str(index + 1)) # 修正対象：str(index + 1)
                for row in cur.fetchall():
                    x = dict(zip([d[0] for d in cur.description], row))
                    data.append(x)
            
            df = pd.DataFrame(matrix[indices[0]].T, columns = indices[0])
            df['this'] = X.toarray()[0]
            
            corr = df.corr()['this'].dropna().drop('this')
            
            results = []
            for item in corr.items():
                for i in range(len(data)):
                    if item[0]+1 == data[i]['_index']:
                        data[i]['confidence'] = item[1]
                        result = copy.deepcopy(data[i])
                        del result['_index']
                        results.append(result)
            response = { 'results': results }
        else:
            response = { 'message': '学習を完了していません。'}
    else:
        response = { 'message': '学習データが存在しません。'}
    
    return response

