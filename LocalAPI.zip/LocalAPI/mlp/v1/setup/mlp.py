# -*- coding: utf-8 -*
import os.path, threading, sqlite3, time
import mlp.v1.common.pkl as pkl, mlp.v1.common.language as language
import numpy as np
import pandas as pd
from sklearn.neural_network import MLPClassifier
from sklearn.feature_extraction.text import TfidfVectorizer

class MlpThread(threading.Thread):
  def __init__(self, env_id, index, X, y):
    super(MlpThread, self).__init__()
    self.env_id = env_id
    self.index = index
    self.X = X
    self.y = y
  
  def run(self):
    clf = MLPClassifier(
      hidden_layer_sizes = (50, ), 
      solver = 'adam', 
      alpha = 0.0001, 
      activation = 'relu', 
      random_state = 0, 
      max_iter = 10000, 
    )
    
    clf.fit(self.X, self.y)
    
    pkl.dump(clf, os.environ.get('LOCALAPI_HOME') + '/mlp/v1/environments/' + self.env_id + '/pickle/model' + str(self.index) + '.pkl')

def run(env_id, data):
  data = np.array(data)
  
  X = language.wakachi(env_id, data[:,0])
  
  vector = TfidfVectorizer(use_idf = True, min_df = 1)
  vector.fit_transform(X)
  
  X = vector.transform(X)
  
  mlp_dummy = pd.get_dummies(data[:,1], drop_first = False)
  mlp_label = {}
  for i in range(len(mlp_dummy.columns)):
      mlp_label[i] = mlp_dummy.columns[i]
  
  dbpath = os.environ.get('LOCALAPI_HOME') + '/mlp/v1/environments/' + env_id + '/data/local.sqlite'
  connection = sqlite3.connect(dbpath)
  
  connection.isolation_level = None
  cur = connection.cursor()
  
  res = cur.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % 'class_data')
  if res.fetchone():
      cur.execute("drop table class_data;")
  
  cur.execute('CREATE TABLE class_data (_index INTEGER PRIMARY KEY, label TEXT)')
  
  thread = []
  for i in range(len(mlp_label)):
    cur.execute('INSERT INTO class_data(label) VALUES(\'' + mlp_label[i] + '\')')
    y = mlp_dummy[mlp_label[i]]
    thread.append(MlpThread(env_id, i, X, y))
  
  for item in thread:
    item.start()
  
  for item in thread:
    item.join()
  
  for i in range(60):
    try:
      pkl.dump(vector, os.environ.get('LOCALAPI_HOME') + '/mlp/v1/environments/' + env_id + '/pickle/vector.pkl')
      break
    except:
      time.sleep(1)
  
  mlp = {}
  for i in range(len(mlp_label)):
    mlp[i] = pkl.load(os.environ.get('LOCALAPI_HOME') + '/mlp/v1/environments/' + env_id + '/pickle/model' + str(i) + '.pkl')
    os.remove(os.environ.get('LOCALAPI_HOME') + '/mlp/v1/environments/' + env_id + '/pickle/model' + str(i) + '.pkl')
  
  pkl.dump(mlp, os.environ.get('LOCALAPI_HOME') + '/mlp/v1/environments/' + env_id + '/pickle/model.pkl')

