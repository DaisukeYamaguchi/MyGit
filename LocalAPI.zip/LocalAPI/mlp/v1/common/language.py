# -*- coding: utf-8 -*
import os.path
from janome.tokenizer import Tokenizer

def wakachi(env_id, text, dict = 'dict.csv'):
  t = Tokenizer()
  for i in range(len(text)):
    line = []
    tokens = t.tokenize(text[i])
    
    for token in tokens:
      if token.part_of_speech.split(',')[0] == '名詞' or token.part_of_speech.split(',')[0] == '動詞' or token.part_of_speech.split(',')[0] == '形容詞':
        if token.base_form != '*':
          line.append(token.base_form)
        else:
          line.append(token.surface)
    text[i] = ' '.join(line)
  
  return text

