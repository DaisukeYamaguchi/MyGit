import os, copy, sqlite3, time
import mlp.v1.common.language as language, mlp.v1.common.pkl as pkl

def predict(env_id, request):
  response = None
  
  dbpath = os.environ.get('LOCALAPI_HOME') + '/mlp/v1/environments/' + env_id + '/data/local.sqlite'
  connection = sqlite3.connect(dbpath)
  
  connection.isolation_level = None
  cur = connection.cursor()
  
  res = cur.execute("SELECT * FROM sqlite_master WHERE type='table' and name='%s'" % 'class_data')
  if res.fetchone() is not None:
    cur.execute('select * from class_data')
    mlp_label = {}
    for row in cur.fetchall():
      mlp_label[int(row[0]) - 1] = row[1]
  
  msg = language.wakachi(env_id, [request])
  
  for i in range(10):
    try:
      full = pkl.load(os.environ.get('LOCALAPI_HOME') + '/mlp/v1/environments/' + env_id + '/pickle/vector.pkl')
      mlp = pkl.load(os.environ.get('LOCALAPI_HOME') + '/mlp/v1/environments/' + env_id + '/pickle/model.pkl')
      break
    except:
      time.sleep(1)
  
  X = full.transform(msg)
  
  prob = []
  for i in range(len(mlp_label)):
    prob.append({'class': mlp_label[i], 'confidence': mlp[i].predict(X)[0]})
  
  return prob

