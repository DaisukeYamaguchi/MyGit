# -*- coding: utf-8 -*-
import os

class FileLock:
    def __init__(self, lockfile):
        self.lockfile = lockfile
    
    def acquire(self, file):
        try:
            with open(self.lockfile, 'a') as f1:
                data = []
                with open(self.lockfile, 'r') as f2:
                    for line in f2:
                        data.append(line.rstrip('\n'))
                
                if os.path.abspath(file) not in data:
                    with open(os.path.abspath(file), 'a') as f3:
                        f1.write(os.path.abspath(file))
                        f1.write('\n')
                else:
                    raise PermissionError
            
            return True
        except PermissionError:
            return False
    
    def release(self, file):
        try:
            with open(self.lockfile, 'a') as f1:
                data = []
                with open(self.lockfile, 'r') as f2:
                    for line in f2:
                        data.append(line.rstrip('\n'))
                
                data.remove(os.path.abspath(file))
                
                with open(self.lockfile, 'w') as f3:
                    for item in data:
                        f1.write(item)
                        f1.write('\n')
            
            return True
        except PermissionError:
            return False

