import os, copy, configparser
import common.pkl as pkl

def run(context, env_id):
    context['topic'] == None
    ini = configparser.SafeConfigParser()
    ini.read(context['userhome'] + '/../../conf.ini')
    
    markov_thre1 = float(ini.get('threshold', 'markov_thre1'))
    markov_thre2 = float(ini.get('threshold', 'markov_thre2'))
    
    markov = pkl.load(context['userhome'] + '/../../pickle/model/markov.pkl')
    
    markov = markov[context['topic']]
    sum = markov['sum']
    del markov['sum']
    markov_list = []
    for item in markov.keys():
        markov_list.append([item, markov[item] / sum])
    
    markov_list.sort(key=lambda x:x[1])
    markov_list.reverse()
    
    if markov_thre1 < markov_list[0][1]:
        context['topic'] = markov_list[0][0]
    
    return context

