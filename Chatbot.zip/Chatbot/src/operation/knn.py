# -*- coding: utf-8 -*-
import os, copy
import common.language as language, common.pkl as pkl

def predict(context, env_id, topic):
    msg = language.wakachi_nv(env_id, [copy.deepcopy(context['request'])])
    text = pkl.load(context['userhome'] + '/../../pickle/document/text.pkl')
    knn_label = pkl.load(context['userhome'] + '/../../pickle/document/knn_label.pkl')
    part = pkl.load(context['userhome'] + '/../../pickle/vector/part.pkl')
    knn = pkl.load(context['userhome'] + '/../../pickle/model/knn.pkl')
    
    index = ''
    for key, value in knn_label.items():
        if value == topic:
            index = key
    
    vector = part[index]
    X = vector.transform(msg)
    
    clf = knn[index]
    context['response'] = clf.predict(X)[0]
    context['learning'].append(context['response']) if context['learning'] != [] else None
    context['status'] = 'proposal'
    
    return context

