import os, copy
import common.language as language, common.pkl as pkl

def predict(context, env_id):
    msg = language.wakachi_nv(env_id, [copy.deepcopy(context['request'])])#
    mlp_label = pkl.load(context['userhome'] + '/../../pickle/document/mlp_label.pkl')
    full = pkl.load(context['userhome'] + '/../../pickle/vector/mlp.pkl')#
    mlp = pkl.load(context['userhome'] + '/../../pickle/model/mlp.pkl')
    X = full.transform(msg)
    
    prob = []
    for i in range(len(mlp_label)):
        prob.append([mlp_label[i], mlp[i].predict(X)[1][0]])
    
    return prob

