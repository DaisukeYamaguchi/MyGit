# -*- coding: utf-8 -*-
import os.path, sys, datetime, operation.topic as topic, operation.process as process
import common.pkl as pkl, operation.session as sess
import operation.sp as sp, common.language as language, operation.regex as regex
import configparser

#statusの仕様：
# greeting 何についての問合せかなあ
# estimation 一旦はこの回答で合ってるかなあ
# understand この回答で間違いないな

def run(env_id, sess_id, msg = ''):
    
    context = {}
    if not os.path.exists(os.environ.get('CHATBOT_ENV') + '/' + env_id + '/session/' + sess_id):
        context = {'userhome': os.environ.get('CHATBOT_ENV') + '/' + env_id + '/session/' + sess_id, 'request': None, 'response': None, 'datetime': datetime.datetime.today(), 'status': 'greeting', 'topic': [], 'pn': False, 'direct': False, 'subject': None, 'switch': False, 'rely': None}
        os.mkdir(context['userhome'])
        pkl.dump(msg, context['userhome'] + '/message.pkl')
        sess.set(context)
    else:
        context = sess.get(env_id = env_id, sess_id = sess_id)
    
    if msg != '':
        context['request'] = msg
        if not os.path.exists(context['userhome'] + '/message.pkl'):
            pkl.dump(msg, context['userhome'] + '/message.pkl')
        
        with open(context['userhome'] + '/../../data/chat.log', 'a', encoding = 'utf8') as f:
            f.write('usr:' + msg)
            f.write('\n')
        
        if context['status'] in 'steady':
            index = language.get_number(regex.z2h(msg))
            if index == []:
                result = sp.predict(env_id, msg, mode = 1)
                if result != ['neutral'] and result != []:
                    context['status'] = 'greeting'
                    context['pn'] = False
            elif index != []:
                ini = configparser.SafeConfigParser()
                ini.read(context['userhome'] + '/../../conf.ini')
                
                rely = ini.get('setting', 'rely').replace(', ', ',').replace(' ,', ',').replace(' , ', ',')
                rely = rely.split(',')
                delete = False
                index = None
                
                for item in reversed(context['topic']):
                    if item in rely:
                        index = context['topic'].index(item)
                
                context = sess.get(context = context)
                context['topic'] = [context['topic'][index]]
                
                context['status'] = 'rely'
                context['subject'] = None#
                
                sess.set(context)
        
        if context['status'] in {'greeting'}:
            context = topic.run(context, env_id, msg)
        
        if context['status'] in {'estimation'}:
            context, context['response'] = topic.predict(context, msg)
            if context['switch']:
                sess.get(context = context)
                context['switch'] = True
        
        if context['status'] in {'understand', 'steady', 'rely'}:
            if context['pn'] == True:
                msg = pkl.load(context['userhome'] + '/message.pkl')
                context['pn'] = False
                sess.set(context)
            context = process.run(context, env_id, sess_id)
    else:
        context['response'] = 'どのようなお問い合わせですか？'
    
    #with open(context['userhome'] + '/../data/chat.log', 'a', encoding = 'utf8') as f:
    #    f.write('bot:' + reply)
    #    f.write('\n')
    
    return {'request': context['request'], 'response': context['response'], 'topic': ','.join(context['topic']), 'topic_list': context['topic_list'], 'status': context['status']}

