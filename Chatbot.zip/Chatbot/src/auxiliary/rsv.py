# -*- coding: utf-8 -*-
import os.path, numpy as np
import auxiliary.distance as distance, common.regex as regex, common.language as language, common.pkl as pkl, operation.pn as pn

def run(env_id, context):
    cd = os.path.expanduser('~') + '/Chatbot/environments/' + env_id
    
    if 'rsv' not in context.keys():
        context['rsv'] = {'filter': {'when': None, 'where': None, 'who': None}}
    filter = {}
    filter['when'] = regex.get_plan(context['message'])
    filter['who'], filter['where'] = language.get_proper_noun(env_id, context['message'], 'rsv/rsv_dict.csv')
    reply = None
    if context['status'] == 'fix':
        noun = language.get_noun(msg)
        if noun != None:
            reply = '予約が完了しました。<br>手続きを終了します。\n/release'
        else:
            reply = '会議名を判断できませんでした。<br>名詞以外の単語は対応していません。'
    
    if context['status'] == 'confirm':
        if 1 == pn.predict(msg):
            context['status'] == 'fix'
            reply = '会議名は何にしますか？'
        else:
            if rsv['when'] is rsv['who'] is rsv['where'] is None:
                candidate = get_candidate(rsv)
                result = create_table(candidate)
                context['response'] = result + '<transaction>空き状況を再度ご確認ください。'
                context['status'] = 'steady'
                return reply
            else:
                context['status'] = 'steady'
    
    if context['status'] == 'request':
        index = language.get_number(regex.z2h(msg))
        if 0 == len(index):
            context['response'] = '文脈を理解できませんでした。<br>管理者に追加学習を依頼します。'
        elif 1 == len(index):
            if int(index[0]) < len(context['rsv'])+1:
                candidate = get_candidate(context['rsv'])
                candidate = candidate[context['request']]
                candidate[3] = str(int(candidate[2].split(':')[0]) + 1) + ':' + candidate[2].split(':')[1]
                result = create_table([candidate])
                pkl.dump(result, context['userhome'] + '/rsv_cnf.pkl')
                reply = result + '<transaction>上記のスケジュールで予約してよろしいですか？'
                context['status'] = 'confirm'
            else:
                reply = 'その番号は存在しません。入力内容を確認してください。'
        elif 1 < len(index):
            reply = '申請は１件ずつ行ってください。'
    
    if context['status'] == 'steady':
        if filter['when'] is filter['who'] is filter['where'] is None:
            context['status'] = "greeting"
        else:
            for key in filter.keys():
                if filter[key] is not None:
                    context['rsv']['filter'][key] = filter[key]
    
    if context['status'] == 'understand':
        if filter['when'] is filter['who'] is filter['where'] is None:
            context['response'] = '日時、メンバー、場所から指定できます。'
        else:
            if context['rsv']['filter']['when'] is context['rsv']['filter']['who'] is context['rsv']['filter']['where'] is None:
                context['rsv']['filter'] = filter
            candidate = get_candidate(context['rsv']['filter'], cd)
            if candidate is None:
                reply = '空きが見つかりませんでした。'
            else:
                context['content'] = {}
                context['content']['order'] = ['no', 'date', 'start', 'end', 'place']
                context['content']['result'] = candidate
                context['content']['type'] = 'someTable'
                context['response'] = '以下の空き時間を確認しました。<br>予約したいスケジュールは番号でお伝えください。<br>'
                context['response'] += 'メンバー：　' + '、'.join(context['rsv']['filter']['who']) + '<br>' if context['rsv']['filter']['who'] is not None else 'メンバー：　<br>'
                context['response'] += '施設名：　' + '、'.join(context['rsv']['filter']['where']) + '<br>' if context['rsv']['filter']['where'] is not None else '施設名：　<br>'
                t_from = t_to = ''
                if context['rsv']['filter']['when'] is not None:
                    t_from = str(int(context['rsv']['filter']['when']['time']['from'] / 4 + 9)) + ':' + str(int((context['rsv']['filter']['when']['time']['from'] - (context['rsv']['filter']['when']['time']['from'] / 4) * 4)) * 15).zfill(2)
                    t_to = str(int(context['rsv']['filter']['when']['time']['to'] / 4 + 9)) + ':' + str(int((context['rsv']['filter']['when']['time']['to'] - (context['rsv']['filter']['when']['time']['to'] / 4) * 4)) * 15).zfill(2)
                context['response'] += '時間：　' + t_from + '～' + t_to + '<br>'
                context['status'] = 'steady'
    
    return context

def get_candidate(context, cd):
    time = interval(context['when'])
    member = schedule(context['who'], cd)
    room = reservation(context['where'], cd)
    
    workable = tXmXr(time, member, room)
    candidate = get_workable(workable)
    
    if candidate != []:
        for i in range(len(candidate)):
            candidate[i] = [candidate[i]['date'], candidate[i]['start'], candidate[i]['end'], candidate[i]['place'], str(candidate[i]['day']), str(candidate[i]['from']), str(candidate[i]['to']), str(candidate[i]['hold'])]
        
        candidate = sorted(candidate, key=lambda x:(x[4], x[5], x[6], x[3]), reverse = False)
        
        result = {}
        result[0] = {'no': '番号', 'date': '日付', 'start': '開始', 'end': '終了', 'place': '場所'}
        for i in range(len(candidate)):
            result[i+1] = {'no': i+1, 'date': candidate[i][0], 'start': candidate[i][1], 'end': candidate[i][2], 'place': candidate[i][3]}
        
        return result
    else:
        return None

def interval(when):
    date = np.array([[False] * 7] * 36)
    time = np.array([[False] * 7] * 36)
    
    if when == None:
        return True
    else:
        if when['date'] == None:
            date = None
        else:
            for i in range(when['date']['from'], when['date']['to']+1):
                date[:,i] = True
        
        if when['time'] == None:
            time = None
        else:
            for i in range(when['time']['from'], when['time']['to']):
                time[i,:] = True
        
        if date is None:
            if time is None:
                return True
            else:
                return time
        else:
            if time is None:
                return date
            else:
                return date * time

def reservation(room, cd):
    reservation = {}
    
    if room == None:
        room = os.listdir(cd + '/data/rsv/room')
        for i in range(len(room)):
            room[i] = room[i].split('.')[0]
    
    for item in room:
        file = []
        for line in open(cd + '/data/rsv/room/'+item+'.csv', 'r', encoding = 'utf8'):
            file.append(line.rstrip('\n').split(','))
        
        reservation[item] = np.array(file)
        reservation[item] = reservation[item] == 'TRUE'
    
    return reservation

def schedule(member, cd):
    schedule = {}
    
    all_free = None
    if member == None:
        all_free = True
    else:
        member = distance.run(member)
        
        for item in member:
            file = []
            for line in open(cd + '/data/rsv/member/'+item+'.csv', 'r', encoding = 'utf8'):
                file.append(line.rstrip('\n').split(','))
            schedule[item] = np.array(file)
            schedule[item] = schedule[item] == 'TRUE'
        
        all_free = schedule[member[0]]
        for i in range(1, len(schedule)):
            all_free = all_free * schedule[member[i]]
    
    return all_free

def tXmXr(time, member, room):
    import numpy as np
    scope_plate = time * member
    for item in room.keys():
        room[item] = room[item] * scope_plate
        if 0 == np.sum(room[item]):
            room[item] = None
    
    return room

def get_workable(room):
    import datetime
    
    week = ['月', '火', '水', '木', '金', '土', '日']
    workable = []
    for item in room.keys():
        if room[item] is not None:
            for i in range(len(room[item][0])):
                temp = {'place': '', 'day': 0, 'from': 0, 'to': 0, 'hold': 0}
                temp['place'] = item
                status = False
                for j in range(len(room[item])):
                    if status == False:
                        if room[item][j][i] == True:
                            temp['day'] = i
                            temp['from'] = j
                            status = True
                    else:
                        if room[item][j][i] == False:
                            temp['to'] = j
                            temp['hold'] = (temp['to'] - temp['from']) / 4
                            temp['start'] = str(int(temp['from'] / 4 + 9)) + ':' + str(int((temp['from'] - (temp['from'] / 4) * 4)) * 15).zfill(2)
                            temp['end'] = str(int(temp['to'] / 4 + 9)) + ':' + str(int((temp['to'] - (temp['to'] / 4) * 4)) * 15).zfill(2)
                            today = datetime.date.today()
                            today = today + datetime.timedelta(days=temp['day'])
                            temp['date'] = str(today.month)+'月'+str(today.day)+'日（'+week[today.weekday()]+'）'
                            workable.append(temp)
                            status = False
    
    return workable

