# -*- coding: utf-8 -*
import os, threading, copy
import common.language as language, common.pkl as pkl
import setup.mlp_thread_sub as mlp_thread_sub
from sklearn.feature_extraction.text import TfidfVectorizer

class MlpThreadSuper(threading.Thread):
    def __init__(self, id, data, dummy, label, name):
        super(MlpThreadSuper, self).__init__()
        self.id = id
        self.data = data
        self.dummy = dummy
        self.label = label
        self.name = name
    
    def run(self):
        cd = os.path.expanduser('~') + '/Chatbot/environments/'
        
        print(self.name + '_super >> start')
        
        vector, X = self.get_tfidf(copy.deepcopy(self.data[:,0]))
        
        thread = []
        for i in range(len(self.label)):
            y = self.dummy[self.label[i]]
            thread.append(mlp_thread_sub.MlpThreadSub(self.id, i, X, y, self.name))
        
        for item in thread:
            item.start()
        
        for item in thread:
            item.join()
        
        pkl.dump(vector, cd + self.id + '/pickle/vector/' + self.name + '.pkl')
        
        print(self.name + '_super >> end')
    
    def get_tfidf(self, data):
        if self.name == 'mlp':
            X = language.wakachi_nv(self.id, data)
        elif self.name == 'pn':
            X = language.wakachi_pn(data)
        vector = TfidfVectorizer(use_idf=True)
        vector.fit_transform(X)
        X = vector.transform(X)
        
        return vector, X

