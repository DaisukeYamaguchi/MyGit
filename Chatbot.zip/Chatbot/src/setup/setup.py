# -*- coding: utf-8 -*
import os, shutil

cd = os.path.dirname(os.path.abspath(__file__)) + '/../../'

def create_environment(id):
    try:
        os.mkdir(cd + 'environments/' + id) if not os.path.exists(cd + 'environments/' + id) else None
        os.mkdir(cd + 'environments/' + id + '/config') if not os.path.exists(cd + 'environments/' + id + '/config') else None
        os.mkdir(cd + 'environments/' + id + '/data') if not os.path.exists(cd + 'environments/' + id + '/data') else None
        os.mkdir(cd + 'environments/' + id + '/data/staging') if not os.path.exists(cd + 'environments/' + id + '/data/staging') else None
        os.mkdir(cd + 'environments/' + id + '/data/staging/pickle') if not os.path.exists(cd + 'environments/' + id + '/data/staging/pickle') else None
        os.mkdir(cd + 'environments/' + id + '/data/staging/pickle/document') if not os.path.exists(cd + 'environments/' + id + '/data/staging/pickle/document') else None
        os.mkdir(cd + 'environments/' + id + '/data/staging/pickle/model') if not os.path.exists(cd + 'environments/' + id + '/data/staging/pickle/model') else None
        os.mkdir(cd + 'environments/' + id + '/data/staging/pickle/vector') if not os.path.exists(cd + 'environments/' + id + '/data/staging/pickle/vector') else None
        os.mkdir(cd + 'environments/' + id + '/pickle') if not os.path.exists(cd + 'environments/' + id + '/pickle') else None
        os.mkdir(cd + 'environments/' + id + '/pickle/document') if not os.path.exists(cd + 'environments/' + id + '/pickle/document') else None
        os.mkdir(cd + 'environments/' + id + '/pickle/model') if not os.path.exists(cd + 'environments/' + id + '/pickle/model') else None
        os.mkdir(cd + 'environments/' + id + '/pickle/vector') if not os.path.exists(cd + 'environments/' + id + '/pickle/vector') else None
        os.mkdir(cd + 'environments/' + id + '/session') if not os.path.exists(cd + 'environments/' + id + '/session') else None
        shutil.copyfile(cd + 'src/template/conf.ini', cd + 'environments/' + id + '/conf.ini') if not os.path.exists(cd + '/environments/' + id + '/conf.ini') else None
        
        return {'message': 'Succeeded in creating the environment'}
    except:
        return {'message': 'Failed in creating the environment'}

def delete_environment(id):
    try:
        shutil.rmtree(cd + 'environments/' + id ) if os.path.exists(cd + 'environments/' + id) else None
        
        return {'message': 'Succeeded in deleting the environment'}
    except:
        return {'message': 'Failed in deleting the environment'}

def delete_session(id, session):
    try:
        shutil.rmtree(cd + 'environments/' + id + '/' + session) if os.path.exists(cd + 'environments/' + id + '/' + session) else None
        
        return {'message': 'Succeeded in deleting the session'}
    except:
        return {'message': 'Failed in deleting the session'}

