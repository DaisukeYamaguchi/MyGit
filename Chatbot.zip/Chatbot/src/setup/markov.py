# -*- coding: utf-8 -*-
import common.pkl as pkl


def train(env_id):
    try:
        env_dir = os.environ.get('CHATBOT_ENV')
        
        data = []
        with open(env_dir + '/' + env_id + '/data/markov_data.csv', 'r', encoding = 'utf8') as f:
            for line in f:
                data.append(line.rstrip('\n').split(','))
        
        unique = []
        markov_data = []
        for i in range(len(data)):
            for j in range(0, len(data[i]) - 1):
                unique.append(data[i][j])
                markov_data.append([data[i][j], data[i][j+1]])
        
        markov = {}
        unique = list(set(unique))
        for key in unique:
            markov[key] = {}
            markov[key]['sum'] = 0
            cnt = 0
            for item in markov_data:
                if key == item[0]:
                    if item[1] in markov[key]:
                        markov[key][item[1]] += 1
                    else:
                        markov[key][item[1]] = 1
                    markov[key]['sum'] += 1
        
        pkl.dump(markov, env_dir + '/' + env_id + '/pickle/model/markov.pkl')
        
        return {'message': 'Succeeded in training the data'}
    except:
        return {'message': 'Failed in training the data'}

