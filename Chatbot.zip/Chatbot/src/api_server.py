# -*- coding: utf-8 -*
import json
import falcon
import urllib.parse
from datetime import datetime
import setup.setup as setup
import setup.initial as initial
import operation.entrance as entrance

#クラスを作成し処理を記述する
class OperationResource(object):
    #GETメソッド
    def on_get(self, req, resp):
        response = None
        if 'environment' in req.params.keys():
            if 'action' in req.params.keys():
                if req.params['action'] == 'create':
                    response = setup.create_environment(req.params['environment'])
                elif req.params['action'] == 'training':
                    if 'mode' in req.params.keys():
                        if req.params['mode'] == 'create':
                            if 'file' in req.params.keys():
                                response = {'error': '使用できません。'}
                            else:
                                response = {'error': 'パラメータfileは必須です。', 'discription': '学習データのファイル名を指定してください。'}
                        elif req.params['mode'] == 'add':
                            if 'file' in req.params.keys():
                                response = {'error': '使用できません。'}
                            else:
                                response = {'error': 'パラメータfileは必須です。', 'discription': '学習データのファイル名を指定してください。'}
                        elif req.params['mode'] == 'update':
                            response = initial.init_train(req.params['environment'])
                        else:
                            response = {'error': 'パラメータactionの値が不明です。', 'discription': 'create-アップロードされた学習データから新たにモデルを生成します。add-アップロードされた学習データを追加し、モデルを更新します。update-既存の学習データからモデルを更新します。'}
                    else:
                        response = {'error': 'パラメータmodeは必須です。', 'discription': 'create-アップロードされた学習データから新たにモデルを生成します。add-アップロードされた学習データを追加し、モデルを更新します。update-既存の学習データからモデルを更新します。'}
                elif req.params['action'] == 'chat':
                    if 'id' in req.params.keys():
                        if 'status' in req.params.keys():
                            if req.params['status'] == 'taking':
                                msg = req.params['message'] if 'message' in req.params.keys() else ''
                                response = entrance.run(req.params['environment'], req.params['id'], msg)
                            elif req.params['status'] == 'close':
                                response = setup.delete_environment(req.params['environment'], req.params['id'])
                            else:
                                response = {'error': 'パラメータstatusの値が不明です。', 'discription': 'taking-システムとの対話を開始・継続します。close-システムとの対話を終了します。'}
                        else:
                            response = {'error': 'パラメータstatusは必須です。', 'discription': 'taking-システムとの対話を開始・継続します。close-システムとの対話を終了します。'}
                    else:
                        response = {'error': 'パラメータidは必須です。', 'discription': 'ユーザーのセッションIDを入力します。'}
                elif req.params['action'] == 'delete':
                    response = setup.delete_environment(req.params['environment'])
                else:
                    response = {'error': 'パラメータactionの値が不明です。', 'discription': 'create-環境を構築します。delete-環境を削除します。training-データを学習します。chat-システムと対話します。'}
            else:
                response = {'error': 'パラメータactionは必須です。', 'discription': 'create-環境を構築します。delete-環境を削除します。training-データを学習します。chat-システムと対話します。'}
        else:
            response = {'error': 'パラメータenvironmentは必須です。', 'discription': 'リクエストの対象となる環境名を入力します。'}
        
        print(response)
        
        #メッセージをjson形式で返す
        resp.body = json.dumps(response)

class ConsultingResource(object):
    #GETメソッド
    def on_get(self, req, resp):
        response = None
        if 'environment' in req.params.keys():
            if 'action' in req.params.keys():
                if req.params['action'] == 'create':
                    response = setup.create_environment(req.params['environment'])
                elif req.params['action'] == 'training':
                    if 'mode' in req.params.keys():
                        if req.params['mode'] == 'create':
                            if 'file' in req.params.keys():
                                response = {'error': '使用できません。'}
                            else:
                                response = {'error': 'パラメータfileは必須です。', 'discription': '学習データのファイル名を指定してください。'}
                        elif req.params['mode'] == 'add':
                            if 'file' in req.params.keys():
                                response = {'error': '使用できません。'}
                            else:
                                response = {'error': 'パラメータfileは必須です。', 'discription': '学習データのファイル名を指定してください。'}
                        elif req.params['mode'] == 'update':
                            response = initial.init_train(req.params['environment'])
                        else:
                            response = {'error': 'パラメータactionの値が不明です。', 'discription': 'create-アップロードされた学習データから新たにモデルを生成します。add-アップロードされた学習データを追加し、モデルを更新します。update-既存の学習データからモデルを更新します。'}
                    else:
                        response = {'error': 'パラメータmodeは必須です。', 'discription': 'create-アップロードされた学習データから新たにモデルを生成します。add-アップロードされた学習データを追加し、モデルを更新します。update-既存の学習データからモデルを更新します。'}
                elif req.params['action'] == 'chat':
                    if 'id' in req.params.keys():
                        if 'status' in req.params.keys():
                            if req.params['status'] == 'taking':
                                msg = req.params['message'] if 'message' in req.params.keys() else ''
                                response = entrance.run(req.params['environment'], req.params['id'], msg)
                            elif req.params['status'] == 'close':
                                response = setup.delete_environment(req.params['environment'], req.params['id'])
                            else:
                                response = {'error': 'パラメータstatusの値が不明です。', 'discription': 'taking-システムとの対話を開始・継続します。close-システムとの対話を終了します。'}
                        else:
                            response = {'error': 'パラメータstatusは必須です。', 'discription': 'taking-システムとの対話を開始・継続します。close-システムとの対話を終了します。'}
                    else:
                        response = {'error': 'パラメータidは必須です。', 'discription': 'ユーザーのセッションIDを入力します。'}
                elif req.params['action'] == 'delete':
                    response = setup.delete_environment(req.params['environment'])
                else:
                    response = {'error': 'パラメータactionの値が不明です。', 'discription': 'create-環境を構築します。delete-環境を削除します。training-データを学習します。chat-システムと対話します。'}
            else:
                response = {'error': 'パラメータactionは必須です。', 'discription': 'create-環境を構築します。delete-環境を削除します。training-データを学習します。chat-システムと対話します。'}
        else:
            response = {'error': 'パラメータenvironmentは必須です。', 'discription': 'リクエストの対象となる環境名を入力します。'}
        
        print(response)
        
        #メッセージをjson形式で返す
        resp.body = json.dumps(response)

class CORSMiddleware:
    def process_request(self, req, resp):
        resp.set_header('Access-Control-Allow-Origin', '*')

#appインスタンス作成
app = falcon.API(middleware=[CORSMiddleware()])
#エンドポイントとクラスを結びつける
app.add_route("/operate", OperationResource())
app.add_route("/consult", ConsultingResource())

if __name__ == "__main__":
    #サーバーを起動する
    from wsgiref import simple_server
    httpd = simple_server.make_server("", 14000, app)
    print('server listening...')
    httpd.serve_forever()

