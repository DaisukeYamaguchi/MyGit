# -*- coding: utf-8 -*-
import time, socket, threading, sys
import xml.etree.ElementTree as ET
import configparser, requests
from contextlib import closing
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options

class ListenThread(threading.Thread):
    def __init__(self, browser):
        super(ListenThread, self).__init__()
        self.browser = browser
    
    def run(self):
        try:
            while True:
                browser.find_element_by_id('usrMsg')
                time.sleep(1)
        except:
            url = 'http://' + host + ':3000/julius'
            payload = {'method': 'close', 'port': port}
            requests.get(url, params = payload)

host = 'localhost'
env = 'default'
bufsize = 4096

inifile = configparser.ConfigParser()

inifile.read('./config.ini')

try:
    host = inifile.get('settings', 'host')
    env = inifile.get('settings', 'env')
    bufsize = int(inifile.get('settings', 'bufsize'))
except:
    pass

url = 'http://' + host + ':3000/julius'
payload = {'method': 'connect', 'env': env}
port = int(requests.get(url, params = payload).text)

url = 'http://' + host + ':3000?edition=full'

options = Options()
options.add_argument('--disable-infobars')
browser = webdriver.Chrome(chrome_options=options)

browser.maximize_window()

browser.get(url)

ListenThread(browser).start()

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    with closing(sock):
        sock.connect((host, port))
        chunk = b""
        count = 0
        while True:
            count += 1
            chunk += sock.recv(bufsize)
            time.sleep(0.0001)
            place = chunk.find(b".\n")
            if not chunk:
                break
            elif place == -1:
                chunk = b""
                continue
            else:
                while chunk:
                    place = chunk.find(b".\n")
                    xml = chunk[0:place]
                    chunk = chunk[place+2:]
                    xml = xml.decode('utf8')
                    xml = xml.replace("\"<", "\"")
                    xml = xml.replace(">\"", "\"")
                    xml = xml.replace("</RECOGOUT>", "")
                    try:
                        root = ET.fromstring(xml)
                        speech = ""
                        for str in root.iter("WHYPO"):
                            speech += str.get("WORD")
                    except Exception as e:
                        print(e)
                    
                    if speech:
                        if (browser.find_element_by_id('micOff')).get_attribute("type") == 'image':
                            elem = browser.find_element_by_id('usrMsg')
                            elem.send_keys(speech)
                            elem = browser.find_element_by_id('submit')
                            elem.send_keys(Keys.ENTER)
except:
    print('Processing exit...')

