var express = require('express');
var router = express.Router();
var fs = require("fs-extra");

/* GET home page. */
router.get('/', function(req, res, next) {
  fs.readdir('./public/julius/environments/.', function(err, files){
    if(err){
      throw err;
    }
    var fileList = [];
    files.filter(function(file){
      fileList.push(file);
    });
    res.render('console', { title: 'index', environments: fileList });
  });
});

router.post('/', function(req, res, next) {
  switch(req.body['action']){
    case "create":
      fs.copy('./public/julius/template', './public/julius/environments/' + req.body['envName'], function (err){
        console.log('Successful creation.')
      });
      break;
    case "deploy":
      res.cookie('envName', req.body['envName']);
      res.redirect('/deploy');
      break;
  }
  
  if(req.body['action'] != 'deploy'){
    fs.readdir('./public/julius/environments/.', function(err, files){
      if(err){
        throw err;
      }
      var fileList = [];
      files.filter(function(file){
        fileList.push(file);
      });
      res.render('console', { title: 'console', environments: fileList });
    });
  }
});

module.exports = router;
