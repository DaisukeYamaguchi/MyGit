var express = require('express');
var router = express.Router();
var fs = require("fs-extra");
var aport = require('aport')
var co = require('co')
var childProcess = require('child_process');

/* GET home page. */
router.get("/", function(req, res, next) {
  res.header('Content-Type', 'application/json; charset=utf-8')
  switch(req.query.method){
    case "envlist":
      var envList = fs.readdirSync('./public/julius/environments/.');
      res.send(JSON.stringify(envList));
      break;
    case "connect":
      fs.access("./public/julius/environments/" + req.query.env, fs.constants.R_OK | fs.constants.W_OK, (error) => {
        if (error) {
          if (error.code === "ENOENT") {
            res.header('Content-Type', 'application/json; charset=utf-8')
            res.send("environment '" + req.query.env + "' doesn't exist");
          }
        }
        co(function * () {
          var port = yield aport()
          childProcess.spawn(process.cwd() + "/public/julius/master.bat", [port, req.query.env]);
          res.send(String(port));
        }).catch((err) => console.error(err))
      });
      break;
    case "close":
      fs.writeFile("./public/julius/close/" + req.query.port, "", function(err){
        if(err){
            throw err;
        }
        res.header('Content-Type', 'application/json; charset=utf-8')
        res.send("closed");
      });
      break;
  }
});

module.exports = router;
