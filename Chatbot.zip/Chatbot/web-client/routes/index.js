var express = require('express');
var router = express.Router();
var fs = require("fs-extra");
var request = require('request');
var http = require('http');
var net = require('net');

/* GET home page. */
router.get("/", function(req, res, next) {
  switch(req.query.edition){
    case "full":
      res.render("index", { title: "chat", version: "full edition"});
      break;
    case "trial":
      res.render("index", { title: "chat", version: "trial edition"});
      break;
    default:
      res.render("index", { title: "chat", version: "trial edition"});
      break;
  }
});

router.post("/", function(req, res, next) {
  switch(req.body["action"]){
    case "gzr":
      var log = JSON.parse(req.body["log"]).join("\n") + '\n'
      res.setHeader("Content-disposition", "attachment; filename=" + req.body["fileName"]);
      res.setHeader("Content-type", "text/csv; charset=UTF-8");
      res.write(log);
      res.end();
      break;
  }
})
/*
router.post("/", function(req, res, next) {
  if(req.body["message"].split(" ")[0] == "-cmd"){
    switch(req.body["message"].split(" ")[1]){
      case "singleLogin":
        var response = "ユーザーIDとパスワードを入力し、<br>ログインしてください。";
        res.render("index", { title: "chat", msgAry: req.body["msgAry"], response: response, mode: JSON.stringify(req.body["mode"]), content: JSON.stringify("singleLogin") });
        break;
      case "multiLogin":
        var response = "ユーザーIDとパスワードを入力し、<br>ログインしてください。";
        res.render("index", { title: "chat", msgAry: req.body["msgAry"], response: response, mode: JSON.stringify(req.body["mode"]), content: JSON.stringify("multiLogin") });
        break;
    }
  }
  
  switch(req.body["action"]){
    case "change":
      if(req.body["mode"] == "speech"){
        console.log('test2')
        var client = net.createConnection(10528, 'localhost', function(){
            console.log('connected.');
        });
        
        client.on('data', function(data){
            console.log(data.toString());
            client.end();
        });
        
        client.on('end', function(){
            console.log('disconnected.');
        });
      }
      res.render("index", { title: "chat", msgAry: req.body["msgAry"], response: req.body["response"], mode: JSON.stringify(req.body["mode"]), content: JSON.stringify("") });
      break;
  }
  var options = {
    uri: "http://localhost:5000/operate",
    headers: {"Content-Type": "application/json"},
    qs: {"environment": "myenv",
           "action": "chat",
           "id": "yamaguchi",
           "status": "taking",
           "message": req.body["message"]
        }
  }
  request.get(options, function (error, response, body) {
    if(error){
      //throw error;
    }
    //body = JSON.parse(body);
    body = "";
    
    res.render("index", { title: "chat", msgAry: req.body["msgAry"], response: body["response"], mode: JSON.stringify(req.body["mode"]), content: JSON.stringify("") });
  })
});
*/

module.exports = router;
