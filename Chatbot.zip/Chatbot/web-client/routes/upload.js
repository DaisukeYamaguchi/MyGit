var express = require("express");
var router = express.Router();
var fs = require("fs-extra");
var multer = require("multer");
var kuromoji = require('kuromoji');
var moji = require('moji');
var upload = multer({ dest: "./uploads/" });

/* GET users listing. */
router.get("/", function(req, res, next) {
  res.render("upload", { title: "upload", data: "", filename: "" });
});

router.post("/", upload.fields([ { name: "thumbnail" } ]), function(req, res, next) {
  if(Object.keys(req.files).length == 0){
    var data = JSON.parse(req.body['data'])
    data = yomi2dic(data);
    var text = '';
    text = data.join("\n") + '\n'
    res.setHeader('Content-disposition', 'attachment; filename=' + req.body['filename'].split(".")[0] + '.htkdic');
    res.setHeader('Content-type', 'text/csv; charset=UTF-8');
    res.write(text);
    res.end();
  }else{
    var path = req.files.thumbnail[0].path;
    var originalname = req.files.thumbnail[0].originalname;
    var extend = originalname.split(".")[1];
    fs.readFile(path, "utf8", function (err, text) {
      if (err) {
        throw err;
      }
      fs.unlink(path, function() {
        if (err) {
          throw err;
        }
        var contents = (text.replace(/\r?\n/g, "<br>").split("<br>")).filter(function(e){return e !== "";});
        var builder = kuromoji.builder({
          dicPath: './node_modules/kuromoji/dict'
        });
        builder.build(function(err, tokenizer) {
          if(err) {
            throw err;
          }
          var data = new Array();
          switch(extend){
            case "corpus":
              var itr = contents.concat();
              for(var i = 0;i<itr.length;i++){
                var tokens = tokenizer.tokenize(itr[i]);
                for(var j = 0;j<tokens.length;j++){
                  if(tokens[j]['pos'] == '名詞'){
                    if(tokens[j]['pronunciation'] != undefined){
                      data.push([tokens[j]['surface_form'], kata2hira(tokens[j]['pronunciation'])])
                    }else{
                      data.push([tokens[j]['surface_form'], ""])
                    }
                  }
                }
              }
              break;
            case "word":
              var tokens = tokenizer.tokenize(contents.join(' '));
              for(var j = 0;j<tokens.length;j++){
                if(tokens[j]['pos'] == '名詞'){
                  if(tokens[j]['pronunciation'] != undefined){
                    data.push([tokens[j]['surface_form'], kata2hira(tokens[j]['pronunciation'])])
                  }else{
                    data.push([tokens[j]['surface_form'], ""])
                  }
                }
              }
              break;
          }
          res.render("upload", { title: "upload", data: data, filename: originalname });
        });
      });
    });
  }
});

function yomi2dic(data){
  var dic = new Array();
  for(var i = 0;i<data.length;i++){
    data[i][1] = moji(data[i][1]).convert('KK', 'HG').toString();
    data[i][1] = data[i][1].replace(/う゛ぁ/g,"b a ");
    data[i][1] = data[i][1].replace(/う゛ぃ/g, "b i ");
    data[i][1] = data[i][1].replace(/う゛ぇ/g, "b e ");
    data[i][1] = data[i][1].replace(/う゛ぉ/g, "b o ");
    data[i][1] = data[i][1].replace(/う゛ゅ/g, "by u ");
    data[i][1] = data[i][1].replace(/ぅ゛/g, "b u ");
    data[i][1] = data[i][1].replace(/あぁ/g, "a a ");
    data[i][1] = data[i][1].replace(/いぃ/g, "i i ");
    data[i][1] = data[i][1].replace(/いぇ/g, "i e ");
    data[i][1] = data[i][1].replace(/いゃ/g, "y a ");
    data[i][1] = data[i][1].replace(/うぅ/g, "u: ");
    data[i][1] = data[i][1].replace(/えぇ/g, "e e ");
    data[i][1] = data[i][1].replace(/おぉ/g, "o: ");
    data[i][1] = data[i][1].replace(/かぁ/g, "k a: ");
    data[i][1] = data[i][1].replace(/きぃ/g, "k i: ");
    data[i][1] = data[i][1].replace(/くぅ/g, "k u: ");
    data[i][1] = data[i][1].replace(/くゃ/g, "ky a ");
    data[i][1] = data[i][1].replace(/くゅ/g, "ky u ");
    data[i][1] = data[i][1].replace(/くょ/g, "ky o ");
    data[i][1] = data[i][1].replace(/けぇ/g, "k e: ");
    data[i][1] = data[i][1].replace(/こぉ/g, "k o: ");
    data[i][1] = data[i][1].replace(/がぁ/g, "g a: ");
    data[i][1] = data[i][1].replace(/ぎぃ/g, "g i: ");
    data[i][1] = data[i][1].replace(/ぐぅ/g, "g u: ");
    data[i][1] = data[i][1].replace(/ぐゃ/g, "gy a ");
    data[i][1] = data[i][1].replace(/ぐゅ/g, "gy u ");
    data[i][1] = data[i][1].replace(/ぐょ/g, "gy o ");
    data[i][1] = data[i][1].replace(/げぇ/g, "g e: ");
    data[i][1] = data[i][1].replace(/ごぉ/g, "g o: ");
    data[i][1] = data[i][1].replace(/さぁ/g, "s a: ");
    data[i][1] = data[i][1].replace(/しぃ/g, "sh i: ");
    data[i][1] = data[i][1].replace(/すぅ/g, "s u: ");
    data[i][1] = data[i][1].replace(/すゃ/g, "sh a ");
    data[i][1] = data[i][1].replace(/すゅ/g, "sh u ");
    data[i][1] = data[i][1].replace(/すょ/g, "sh o ");
    data[i][1] = data[i][1].replace(/せぇ/g, "s e: ");
    data[i][1] = data[i][1].replace(/そぉ/g, "s o: ");
    data[i][1] = data[i][1].replace(/ざぁ/g, "z a: ");
    data[i][1] = data[i][1].replace(/じぃ/g, "j i: ");
    data[i][1] = data[i][1].replace(/ずぅ/g, "z u: ");
    data[i][1] = data[i][1].replace(/ずゃ/g, "zy a ");
    data[i][1] = data[i][1].replace(/ずゅ/g, "zy u ");
    data[i][1] = data[i][1].replace(/ずょ/g, "zy o ");
    data[i][1] = data[i][1].replace(/ぜぇ/g, "z e: ");
    data[i][1] = data[i][1].replace(/ぞぉ/g, "z o: ");
    data[i][1] = data[i][1].replace(/たぁ/g, "t a: ");
    data[i][1] = data[i][1].replace(/ちぃ/g, "ch i: ");
    data[i][1] = data[i][1].replace(/つぁ/g, "ts a ");
    data[i][1] = data[i][1].replace(/つぃ/g, "ts i ");
    data[i][1] = data[i][1].replace(/つぅ/g, "ts u: ");
    data[i][1] = data[i][1].replace(/つゃ/g, "ch a ");
    data[i][1] = data[i][1].replace(/つゅ/g, "ch u ");
    data[i][1] = data[i][1].replace(/つょ/g, "ch o ");
    data[i][1] = data[i][1].replace(/つぇ/g, "ts e ");
    data[i][1] = data[i][1].replace(/つぉ/g, "ts o ");
    data[i][1] = data[i][1].replace(/てぇ/g, "t e: ");
    data[i][1] = data[i][1].replace(/とぉ/g, "t o: ");
    data[i][1] = data[i][1].replace(/だぁ/g, "d a: ");
    data[i][1] = data[i][1].replace(/ぢぃ/g, "j i: ");
    data[i][1] = data[i][1].replace(/づぅ/g, "d u: ");
    data[i][1] = data[i][1].replace(/づゃ/g, "zy a ");
    data[i][1] = data[i][1].replace(/づゅ/g, "zy u ");
    data[i][1] = data[i][1].replace(/づょ/g, "zy o ");
    data[i][1] = data[i][1].replace(/でぇ/g, "d e: ");
    data[i][1] = data[i][1].replace(/どぉ/g, "d o: ");
    data[i][1] = data[i][1].replace(/なぁ/g, "n a: ");
    data[i][1] = data[i][1].replace(/にぃ/g, "n i: ");
    data[i][1] = data[i][1].replace(/ぬぅ/g, "n u: ");
    data[i][1] = data[i][1].replace(/ぬゃ/g, "ny a ");
    data[i][1] = data[i][1].replace(/ぬゅ/g, "ny u ");
    data[i][1] = data[i][1].replace(/ぬょ/g, "ny o ");
    data[i][1] = data[i][1].replace(/ねぇ/g, "n e: ");
    data[i][1] = data[i][1].replace(/のぉ/g, "n o: ");
    data[i][1] = data[i][1].replace(/はぁ/g, "h a: ");
    data[i][1] = data[i][1].replace(/ひぃ/g, "h i: ");
    data[i][1] = data[i][1].replace(/ふぅ/g, "f u: ");
    data[i][1] = data[i][1].replace(/ふゃ/g, "hy a ");
    data[i][1] = data[i][1].replace(/ふゅ/g, "hy u ");
    data[i][1] = data[i][1].replace(/ふょ/g, "hy o ");
    data[i][1] = data[i][1].replace(/へぇ/g, "h e: ");
    data[i][1] = data[i][1].replace(/ほぉ/g, "h o: ");
    data[i][1] = data[i][1].replace(/ばぁ/g, "b a: ");
    data[i][1] = data[i][1].replace(/びぃ/g, "b i: ");
    data[i][1] = data[i][1].replace(/ぶぅ/g, "b u: ");
    data[i][1] = data[i][1].replace(/ふゃ/g, "hy a ");
    data[i][1] = data[i][1].replace(/ぶゅ/g, "by u ");
    data[i][1] = data[i][1].replace(/ふょ/g, "hy o ");
    data[i][1] = data[i][1].replace(/べぇ/g, "b e: ");
    data[i][1] = data[i][1].replace(/ぼぉ/g, "b o: ");
    data[i][1] = data[i][1].replace(/ぱぁ/g, "p a: ");
    data[i][1] = data[i][1].replace(/ぴぃ/g, "p i: ");
    data[i][1] = data[i][1].replace(/ぷぅ/g, "p u: ");
    data[i][1] = data[i][1].replace(/ぷゃ/g, "py a ");
    data[i][1] = data[i][1].replace(/ぷゅ/g, "py u ");
    data[i][1] = data[i][1].replace(/ぷょ/g, "py o ");
    data[i][1] = data[i][1].replace(/ぺぇ/g, "p e: ");
    data[i][1] = data[i][1].replace(/ぽぉ/g, "p o: ");
    data[i][1] = data[i][1].replace(/まぁ/g, "m a: ");
    data[i][1] = data[i][1].replace(/みぃ/g, "m i: ");
    data[i][1] = data[i][1].replace(/むぅ/g, "m u: ");
    data[i][1] = data[i][1].replace(/むゃ/g, "my a ");
    data[i][1] = data[i][1].replace(/むゅ/g, "my u ");
    data[i][1] = data[i][1].replace(/むょ/g, "my o ");
    data[i][1] = data[i][1].replace(/めぇ/g, "m e: ");
    data[i][1] = data[i][1].replace(/もぉ/g, "m o: ");
    data[i][1] = data[i][1].replace(/やぁ/g, "y a: ");
    data[i][1] = data[i][1].replace(/ゆぅ/g, "y u: ");
    data[i][1] = data[i][1].replace(/ゆゃ/g, "y a: ");
    data[i][1] = data[i][1].replace(/ゆゅ/g, "y u: ");
    data[i][1] = data[i][1].replace(/ゆょ/g, "y o: ");
    data[i][1] = data[i][1].replace(/よぉ/g, "y o: ");
    data[i][1] = data[i][1].replace(/らぁ/g, "r a: ");
    data[i][1] = data[i][1].replace(/りぃ/g, "r i: ");
    data[i][1] = data[i][1].replace(/るぅ/g, "r u: ");
    data[i][1] = data[i][1].replace(/るゃ/g, "ry a ");
    data[i][1] = data[i][1].replace(/るゅ/g, "ry u ");
    data[i][1] = data[i][1].replace(/るょ/g, "ry o ");
    data[i][1] = data[i][1].replace(/れぇ/g, "r e: ");
    data[i][1] = data[i][1].replace(/ろぉ/g, "r o: ");
    data[i][1] = data[i][1].replace(/わぁ/g, "w a: ");
    data[i][1] = data[i][1].replace(/をぉ/g, "o: ");
    data[i][1] = data[i][1].replace(/う゛/g, "b u ");
    data[i][1] = data[i][1].replace(/でぃ/g, "d i ");
    data[i][1] = data[i][1].replace(/でぇ/g, "d e: ");
    data[i][1] = data[i][1].replace(/でゃ/g, "dy a ");
    data[i][1] = data[i][1].replace(/でゅ/g, "dy u ");
    data[i][1] = data[i][1].replace(/でょ/g, "dy o ");
    data[i][1] = data[i][1].replace(/てぃ/g, "t i ");
    data[i][1] = data[i][1].replace(/てぇ/g, "t e: ");
    data[i][1] = data[i][1].replace(/てゃ/g, "ty a ");
    data[i][1] = data[i][1].replace(/てゅ/g, "ty u ");
    data[i][1] = data[i][1].replace(/てょ/g, "ty o ");
    data[i][1] = data[i][1].replace(/すぃ/g, "s i ");
    data[i][1] = data[i][1].replace(/ずぁ/g, "z u a ");
    data[i][1] = data[i][1].replace(/ずぃ/g, "z i ");
    data[i][1] = data[i][1].replace(/ずぅ/g, "z u ");
    data[i][1] = data[i][1].replace(/ずゃ/g, "zy a ");
    data[i][1] = data[i][1].replace(/ずゅ/g, "zy u ");
    data[i][1] = data[i][1].replace(/ずょ/g, "zy o ");
    data[i][1] = data[i][1].replace(/ずぇ/g, "z e ");
    data[i][1] = data[i][1].replace(/ずぉ/g, "z o ");
    data[i][1] = data[i][1].replace(/きゃ/g, "ky a ");
    data[i][1] = data[i][1].replace(/きゅ/g, "ky u ");
    data[i][1] = data[i][1].replace(/きょ/g, "ky o ");
    data[i][1] = data[i][1].replace(/しゃ/g, "sh a ");
    data[i][1] = data[i][1].replace(/しゅ/g, "sh u ");
    data[i][1] = data[i][1].replace(/しぇ/g, "sh e ");
    data[i][1] = data[i][1].replace(/しょ/g, "sh o ");
    data[i][1] = data[i][1].replace(/ちゃ/g, "ch a ");
    data[i][1] = data[i][1].replace(/ちゅ/g, "ch u ");
    data[i][1] = data[i][1].replace(/ちぇ/g, "ch e ");
    data[i][1] = data[i][1].replace(/ちょ/g, "ch o ");
    data[i][1] = data[i][1].replace(/とぅ/g, "t u ");
    data[i][1] = data[i][1].replace(/とゃ/g, "ty a ");
    data[i][1] = data[i][1].replace(/とゅ/g, "ty u ");
    data[i][1] = data[i][1].replace(/とょ/g, "ty o ");
    data[i][1] = data[i][1].replace(/どぁ/g, "d o a ");
    data[i][1] = data[i][1].replace(/どぅ/g, "d u ");
    data[i][1] = data[i][1].replace(/どゃ/g, "dy a ");
    data[i][1] = data[i][1].replace(/どゅ/g, "dy u ");
    data[i][1] = data[i][1].replace(/どょ/g, "dy o ");
    data[i][1] = data[i][1].replace(/どぉ/g, "d o: ");
    data[i][1] = data[i][1].replace(/にゃ/g, "ny a ");
    data[i][1] = data[i][1].replace(/にゅ/g, "ny u ");
    data[i][1] = data[i][1].replace(/にょ/g, "ny o ");
    data[i][1] = data[i][1].replace(/ひゃ/g, "hy a ");
    data[i][1] = data[i][1].replace(/ひゅ/g, "hy u ");
    data[i][1] = data[i][1].replace(/ひょ/g, "hy o ");
    data[i][1] = data[i][1].replace(/みゃ/g, "my a ");
    data[i][1] = data[i][1].replace(/みゅ/g, "my u ");
    data[i][1] = data[i][1].replace(/みょ/g, "my o ");
    data[i][1] = data[i][1].replace(/りゃ/g, "ry a ");
    data[i][1] = data[i][1].replace(/りゅ/g, "ry u ");
    data[i][1] = data[i][1].replace(/りょ/g, "ry o ");
    data[i][1] = data[i][1].replace(/ぎゃ/g, "gy a ");
    data[i][1] = data[i][1].replace(/ぎゅ/g, "gy u ");
    data[i][1] = data[i][1].replace(/ぎょ/g, "gy o ");
    data[i][1] = data[i][1].replace(/ぢぇ/g, "j e ");
    data[i][1] = data[i][1].replace(/ぢゃ/g, "j a ");
    data[i][1] = data[i][1].replace(/ぢゅ/g, "j u ");
    data[i][1] = data[i][1].replace(/ぢょ/g, "j o ");
    data[i][1] = data[i][1].replace(/じぇ/g, "j e ");
    data[i][1] = data[i][1].replace(/じゃ/g, "j a ");
    data[i][1] = data[i][1].replace(/じゅ/g, "j u ");
    data[i][1] = data[i][1].replace(/じょ/g, "j o ");
    data[i][1] = data[i][1].replace(/びゃ/g, "by a ");
    data[i][1] = data[i][1].replace(/びゅ/g, "by u ");
    data[i][1] = data[i][1].replace(/びょ/g, "by o ");
    data[i][1] = data[i][1].replace(/ぴゃ/g, "py a ");
    data[i][1] = data[i][1].replace(/ぴゅ/g, "py u ");
    data[i][1] = data[i][1].replace(/ぴょ/g, "py o ");
    data[i][1] = data[i][1].replace(/うぁ/g, "u a ");
    data[i][1] = data[i][1].replace(/うぃ/g, "w i ");
    data[i][1] = data[i][1].replace(/うぇ/g, "w e ");
    data[i][1] = data[i][1].replace(/うぉ/g, "w o ");
    data[i][1] = data[i][1].replace(/ふぁ/g, "f a ");
    data[i][1] = data[i][1].replace(/ふぃ/g, "f i ");
    data[i][1] = data[i][1].replace(/ふぅ/g, "f u ");
    data[i][1] = data[i][1].replace(/ふゃ/g, "hy a ");
    data[i][1] = data[i][1].replace(/ふゅ/g, "hy u ");
    data[i][1] = data[i][1].replace(/ふょ/g, "hy o ");
    data[i][1] = data[i][1].replace(/ふぇ/g, "f e ");
    data[i][1] = data[i][1].replace(/ふぉ/g, "f o ");
    data[i][1] = data[i][1].replace(/あ/g, "a ");
    data[i][1] = data[i][1].replace(/い/g, "i ");
    data[i][1] = data[i][1].replace(/う/g, "u ");
    data[i][1] = data[i][1].replace(/え/g, "e ");
    data[i][1] = data[i][1].replace(/お/g, "o ");
    data[i][1] = data[i][1].replace(/か/g, "k a ");
    data[i][1] = data[i][1].replace(/き/g, "k i ");
    data[i][1] = data[i][1].replace(/く/g, "k u ");
    data[i][1] = data[i][1].replace(/け/g, "k e ");
    data[i][1] = data[i][1].replace(/こ/g, "k o ");
    data[i][1] = data[i][1].replace(/さ/g, "s a ");
    data[i][1] = data[i][1].replace(/し/g, "sh i ");
    data[i][1] = data[i][1].replace(/す/g, "s u ");
    data[i][1] = data[i][1].replace(/せ/g, "s e ");
    data[i][1] = data[i][1].replace(/そ/g, "s o ");
    data[i][1] = data[i][1].replace(/た/g, "t a ");
    data[i][1] = data[i][1].replace(/ち/g, "ch i ");
    data[i][1] = data[i][1].replace(/つ/g, "ts u ");
    data[i][1] = data[i][1].replace(/て/g, "t e ");
    data[i][1] = data[i][1].replace(/と/g, "t o ");
    data[i][1] = data[i][1].replace(/な/g, "n a ");
    data[i][1] = data[i][1].replace(/に/g, "n i ");
    data[i][1] = data[i][1].replace(/ぬ/g, "n u ");
    data[i][1] = data[i][1].replace(/ね/g, "n e ");
    data[i][1] = data[i][1].replace(/の/g, "n o ");
    data[i][1] = data[i][1].replace(/は/g, "h a ");
    data[i][1] = data[i][1].replace(/ひ/g, "h i ");
    data[i][1] = data[i][1].replace(/ふ/g, "f u ");
    data[i][1] = data[i][1].replace(/へ/g, "h e ");
    data[i][1] = data[i][1].replace(/ほ/g, "h o ");
    data[i][1] = data[i][1].replace(/ま/g, "m a ");
    data[i][1] = data[i][1].replace(/み/g, "m i ");
    data[i][1] = data[i][1].replace(/む/g, "m u ");
    data[i][1] = data[i][1].replace(/め/g, "m e ");
    data[i][1] = data[i][1].replace(/も/g, "m o ");
    data[i][1] = data[i][1].replace(/ら/g, "r a ");
    data[i][1] = data[i][1].replace(/り/g, "r i ");
    data[i][1] = data[i][1].replace(/る/g, "r u ");
    data[i][1] = data[i][1].replace(/れ/g, "r e ");
    data[i][1] = data[i][1].replace(/ろ/g, "r o ");
    data[i][1] = data[i][1].replace(/が/g, "g a ");
    data[i][1] = data[i][1].replace(/ぎ/g, "g i ");
    data[i][1] = data[i][1].replace(/ぐ/g, "g u ");
    data[i][1] = data[i][1].replace(/げ/g, "g e ");
    data[i][1] = data[i][1].replace(/ご/g, "g o ");
    data[i][1] = data[i][1].replace(/ざ/g, "z a ");
    data[i][1] = data[i][1].replace(/じ/g, "j i ");
    data[i][1] = data[i][1].replace(/ず/g, "z u ");
    data[i][1] = data[i][1].replace(/ぜ/g, "z e ");
    data[i][1] = data[i][1].replace(/ぞ/g, "z o ");
    data[i][1] = data[i][1].replace(/だ/g, "d a ");
    data[i][1] = data[i][1].replace(/ぢ/g, "j i ");
    data[i][1] = data[i][1].replace(/づ/g, "z u ");
    data[i][1] = data[i][1].replace(/で/g, "d e ");
    data[i][1] = data[i][1].replace(/ど/g, "d o ");
    data[i][1] = data[i][1].replace(/ば/g, "b a ");
    data[i][1] = data[i][1].replace(/び/g, "b i ");
    data[i][1] = data[i][1].replace(/ぶ/g, "b u ");
    data[i][1] = data[i][1].replace(/べ/g, "b e ");
    data[i][1] = data[i][1].replace(/ぼ/g, "b o ");
    data[i][1] = data[i][1].replace(/ぱ/g, "p a ");
    data[i][1] = data[i][1].replace(/ぴ/g, "p i ");
    data[i][1] = data[i][1].replace(/ぷ/g, "p u ");
    data[i][1] = data[i][1].replace(/ぺ/g, "p e ");
    data[i][1] = data[i][1].replace(/ぽ/g, "p o ");
    data[i][1] = data[i][1].replace(/や/g, "y a ");
    data[i][1] = data[i][1].replace(/ゆ/g, "y u ");
    data[i][1] = data[i][1].replace(/よ/g, "y o ");
    data[i][1] = data[i][1].replace(/わ/g, "w a ");
    data[i][1] = data[i][1].replace(/ゐ/g, "i ");
    data[i][1] = data[i][1].replace(/ゑ/g, "e ");
    data[i][1] = data[i][1].replace(/ん/g, "N ");
    data[i][1] = data[i][1].replace(/っ/g, "q ");
    data[i][1] = data[i][1].replace(/ー/g, ": ");
    data[i][1] = data[i][1].replace(/ぁ/g, "a ");
    data[i][1] = data[i][1].replace(/ぃ/g, "i ");
    data[i][1] = data[i][1].replace(/ぅ/g, "u ");
    data[i][1] = data[i][1].replace(/ぇ/g, "e ");
    data[i][1] = data[i][1].replace(/ぉ/g, "o ");
    data[i][1] = data[i][1].replace(/ゎ/g, "w a ");
    data[i][1] = data[i][1].replace(/ぉ/g, "o ");
    data[i][1] = data[i][1].replace(/を/g, "o ");
    data[i][1] = data[i][1].replace(/ $/g, "");
    data[i][1] = data[i][1].replace(/:+/g, ":");
    data[i][1] = data[i][1].replace(/ :/g, ":");
    
    dic.push(data[i][0] + "+名詞\t[" + data[i][0] + "]\t"+ data[i][1]);
  }
  return dic;
}

function kata2hira(src) {
  return  src.replace(/[\u30a1-\u30f6]/g, function(match) {
    var chr = match.charCodeAt(0) - 0x60;
    return String.fromCharCode(chr);
  });
}

module.exports = router;
