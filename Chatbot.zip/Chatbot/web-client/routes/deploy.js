var express = require("express");
var router = express.Router();
var fs = require("fs-extra");
var multer = require("multer");
var upload = multer({ dest: "./uploads/" });
var childProcess = require('child_process');
var taskkill = require('taskkill');
var netstat = require('node-netstat');
var net = require('net');

/* GET users listing. */
router.get("/", function(req, res, next) {
  fs.readFile("./public/julius/environments/" + req.cookies.envName + "/.conf", "utf8", function (err, port) {
    if(err){
      throw err;
    }
    fs.readdir('public/julius/environments/' + req.cookies.envName + '/dict/.', function(err, files){
      if(err){
        throw err;
      }
      var fileList = [];
      files.filter(function(file){
        fileList.push(file);
      });
      var idx = fileList.indexOf('.htkdic');
      if(idx >= 0){
        fileList.splice(idx, 1); 
      }
      fs.readFile("./public/julius/environments/" + req.cookies.envName + "/.state", "utf8", function (err, state) {
        if(err){
          throw err;
        }
        res.render('deploy', { title: 'deploy', port: port, dictList: fileList, status: state });
      });
    });
  });
});

router.post("/", upload.fields([ { name: "thumbnail" } ]), function(req, res, next) {
  switch(req.body['action']){
    case 'dictControl':
      switch(req.body['command']){
        case 'delete':
          fs.unlink("./public/julius/environments/" + req.cookies.envName + "/dict/" + req.body['dictRadio'], function (err) {
            fs.readdir('public/julius/environments/' + req.cookies.envName + '/dict/.', function(err, files){
              if(err){
                throw err;
              }
              var fileList = [];
              files.filter(function(file){
                fileList.push(file);
              });
              var idx = fileList.indexOf('.htkdic');
              if(idx >= 0){
                fileList.splice(idx, 1); 
              }
              fs.readFile("./public/julius/environments/" + req.cookies.envName + "/.conf", "utf8", function (err, port) {
                if(err){
                  throw err;
                }
                res.render('deploy', { title: 'deploy', port: port, dictList: fileList, status: 'unknown'});
              });
            });
          });
          break;
        case 'download':
          fs.readFile("./public/julius/environments/" + req.cookies.envName + "/dict/" + req.body['dictRadio'], "utf8", function(err, text) {
            if (err) {
              throw err;
            }
            res.setHeader('Content-disposition', 'attachment; filename=' + req.body['dictRadio']);
            res.setHeader('Content-type', 'text/csv; charset=UTF-8');
            res.write(text);
            res.end();
          });
          break;
      }
      break;
    default:
      var path = req.files.thumbnail[0].path;
      var originalname = req.files.thumbnail[0].originalname;
      fs.copyFile(path, './public/julius/environments/' + req.cookies.envName + '/dict/' + originalname, (err) => {
        if (err) {
          throw err;
        }
        fs.unlink(path, function() {
          fs.readFile("./public/julius/environments/" + req.cookies.envName + "/.conf", "utf8", function(err, text) {
            fs.readdir('public/julius/environments/' + req.cookies.envName + '/dict/.', function(err, files){
              if(err){
                throw err;
              }
              var fileList = [];
              files.filter(function(file){
                fileList.push(file);
              });
              var idx = fileList.indexOf('product.htkdic');
              if(idx >= 0){
                fileList.splice(idx, 1); 
              }
              res.render('deploy', { title: 'index', port: text, dictList: fileList, status: 'unknown' });
            });
          });
        });
      });
      break;
  }
});

function listener(port){
  var socket = new net.Socket();
  
  socket.connect(port, "127.0.0.1", function() {
    socket.destroy();
    return "listening";
  });
  
  socket.on("error", function(e) {
    return "undefined";
  });
}

module.exports = router;
