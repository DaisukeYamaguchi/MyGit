var globalList = "";

$(document).ready(function() {
  $("#messageDiv").on('DOMSubtreeModified propertychange', function() {
    if($("#voiceOff").attr("type") == "image"){
      speak();
    }
  });
});

function speak(){
  var voices = speechSynthesis.getVoices();
  var uttr = new SpeechSynthesisUtterance($("#messageDiv").html());
  voices.forEach(function(v, i){
    if(v.name == "Google 日本語"){
      uttr.voice = v;
    }
  });
  speechSynthesis.cancel();
  speechSynthesis.speak(uttr);
}

$(function() {
  $(".submitOn").on('click',function(){
    var msg = "";
    
    msg = $("#usrMsg").val();
    $("#usrMsg").val("");
    $("#usrMsg").focus();
    
    if($("#mode").val() != "readonly"){
      var url = "http://localhost:14000/operate?";
      var query = {"environment": "myenv",
        "action": "chat",
        "id": "yamaguchi",
        "status": "taking",
        "message": msg
      }
      url = url + $.param(query);
      fetch(url, {mode: 'cors'}).then(function(response) {
        return response.json();
      }).then(function(json) {
        $("#messageDiv").html(json["response"]);
        $("#contentDiv").html(transResponse(json));
        clientProccess(json);
        $(".cube").css("animation", "rotateCube 10s infinite linear");
      });
      $(".cube").css("animation", "rotateCube 1s infinite linear");
    }else{
      if(msg.indexOf("終了") === 0){
        downloadLog();
        $("#mode").val("normal");
      }
    }
    msg = msg == "" ? "　" : msg;
    var time = new Date();
    time = ('0' + time.getHours()).slice(-2) + ":" + ('0' + time.getMinutes()).slice(-2) + ":" + ('0' + time.getSeconds()).slice(-2);
    $("#logDiv").append('<div class="msgContainer"><div class="msgIcon"></div><div class="logTime">' + time + '</div><div class="usrMsg">' + msg + '</div></div>');
    $("#logDiv").animate({scrollTop: $('#logDiv')[0].scrollHeight}, 'slow');
  });
  
  $(".micSwitch").on("click",function(){
    if($("#micOn").attr("type") == "image"){
      $("#micOn").attr("type", "hidden");
      $("#micOff").attr("type", "image");
      if($("#version").html() == "trial version"){
        recognition.start();
        $("#usrMsg").prop("disabled", true);
        $("#submit").prop("class", "submitOff");
        $("#submit").prop("disabled", true);
      }
    }else if($("#micOff").attr("type") == "image"){
      $("#micOn").attr("type", "image");
      $("#micOff").attr("type", "hidden");
      if($("#version").html() == "trial version"){
        recognition.stop();
        $("#usrMsg").prop("disabled", false);
        $("#submit").prop("class", "submitOn");
        $("#submit").prop("disabled", false);
      }
    }
  });
  
  $(".voiceSwitch").on("click",function(){
    if($("#voiceOn").attr("type") == "image"){
      $("#voiceOn").attr("type", "hidden");
      $("#voiceOff").attr("type", "image");
    }else if($("#voiceOff").attr("type") == "image"){
      $("#voiceOn").attr("type", "image");
      $("#voiceOff").attr("type", "hidden");
    }
  });
});

function enter(code){
  if(13 === code){
    $("#submit").click();
  }
}

window.SpeechRecognition = window.SpeechRecognition || webkitSpeechRecognition;
var recognition = new webkitSpeechRecognition();
recognition.lang = 'ja';
recognition.interimResults = true;
recognition.continuous = true;

recognition.onresult = function(event){
  var results = event.results;
  for (var i = event.resultIndex; i<results.length; i++){
    if(!results[i].isFinal){
      $("#usrMsg").val(results[i][0].transcript);
    }else{
      $("#submit").click();
    }
  }
}

function transResponse(json){
  var html = "";
  if(json["content"]){
    switch(json["content"]["type"]){
      case "someTable":
        html = createTable(json);
        $("#someTable").addClass("contentIn");
        break;
      case "html":
        html = json["content"]["result"];
        break;
    }
  }
  return html;
}

function createTable(json){
  var html = '<table id="someTable" border="1">';
  var num = Object.keys(json["content"]["result"]).length;
  for(var i = 0;i<num;i++){
    html += "<tr>";
    for(var j = 0;j<json["content"]["order"].length;j++){
      html += "<td>";
      html += json["content"]["result"][i][json["content"]["order"][j]];
      html += "</td>";
    }
    html += "</tr>";
  }
  html += "</table>";
  
  return html;
}

function clientProccess(json){
  switch(json["topic"]){
    case "議事録"://globalList
      //$("#contentDiv").load("./html/multiLogin.html");
      $("#mode").val("readonly");
      $("#logDiv").empty();
      break;
  }
}

function downloadLog(){
  var log = new Array();
  for(var i = 0;i<$("#logDiv .usrMsg").length;i++){
    log.push($("#logDiv .logTime")[i].innerHTML + "\t" + $("#logDiv .usrMsg")[i].innerHTML);
  }
  var date = new Date();
  date = date.getFullYear() + ('0' + date.getMonth() + 1).slice(-2) + ('0' + date.getDay()).slice(-2) + "_" + ('0' + date.getHours()).slice(-2) + ('0' + date.getMinutes()).slice(-2);
  var form = $("<form/>", {method: "post", action: "/"});
  $("body").append(form);
  form.append($("<input/>", {type: "hidden", name: "action", value: "gzr"}));
  form.append($("<input/>", {type: "hidden", name: "fileName", value: "minute" + date + ".txt"}));
  form.append($("<input/>", {type: "hidden", name: "log", value: JSON.stringify(log)}));
  $("#messageDiv").html("対話の記録を送信しました。<br>ファイル名： minute" + date + ".txt<br>内容をご確認ください。");
  form.submit();
}

