var fs = require('fs-extra');
require('date-utils');
var taskkill = require('taskkill');
var netstat = require('node-netstat');

function run(){
  fs.readdir("./public/julius/close", function(err, files){
    if(err){
      throw err;
    }
    files.filter(function(file){
      return file
    }).forEach(function (file) {
      netstat({
        filter: {
          local: {
            port: parseInt(file)
          }
        },
        limit: 5
      }, function (data) {
        taskkill(data['pid'], {force: true}).then(() => {
          console.log('Session closed.')
          fs.unlink("./public/julius/close/" + file, function (err) {
          });
        });
      });
    });
  });
}

setInterval(function(){
  run();
}, 1000);

