# selenium(テスト自動化ツール)用いた疑似RPA
#coding : utf-8
import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

# seleniumがchromeを操作するためのドライバを取得
browser = webdriver.Chrome('./chromedriver')

# Googleのトップページへ遷移
browser.get('https://www.google.com/')



# 念のため応答を待機
time.sleep(1)



# 検索テキストボックスの要素id「lst-ib」を取得し、「youtube」という文字列で検索
elem = browser.find_element_by_id('lst-ib')
elem.send_keys('youtube')
elem.send_keys(Keys.ENTER)



# 念のため応答を待機
time.sleep(1)



# 検索結果のみが含まれるであろう要素id「res」を取得
elem = browser.find_element_by_id('res')
# 要素id「res」から、検索結果のリンクであるタグ「a」を全て取得
elem = elem.find_elements_by_tag_name('a')
# 一番上のタグ「a」（リンク）にエンターキーを送る
elem[0].send_keys(Keys.ENTER)



# 念のため応答を待機
time.sleep(1)



# youtubeページの検索テキストボックスを取得し、「WBC 井端 神」と入力
elem = browser.find_element_by_id('search')
elem.send_keys('WBC 井端 神')
# 検索ボタンに対してエンターキーを送る
elem = browser.find_element_by_id('search-icon-legacy')
elem.send_keys(Keys.ENTER)



# 念のため応答を待機
time.sleep(1)


# 検索結果のみが含まれるであろうタグ「ytd-video-renderer」のクラス「style-scope ytd-item-section-renderer」を全て取得
elem = browser.find_elements_by_xpath('//ytd-video-renderer[@class="style-scope ytd-item-section-renderer"]')
# 必ず待機する
time.sleep(1)
# 一番上の要素にクリックを送信
elem[0].find_element_by_id('meta').click()

