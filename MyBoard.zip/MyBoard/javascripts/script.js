var frameWidth = $(window).width() / 2;

var flameNum = $('.frame').length
var activeFrame = 0;

$(function(){
  $('.slider.left').mouseover(function(e){
    if(0 < activeFrame){
      $(this).css('transform', 'translateX(50px)');
    }
  }).mouseout(function(e){
    $(this).css('transform', 'translateX(0px)');
  });
  
  $('.slider.right').mouseover(function(e){
    if(activeFrame < flameNum - 2){
      $(this).css('transform', 'translateX(-50px)');
    }
  }).mouseout(function(e){
    $(this).css('transform', 'translateX(0px)');
  });
  
  $('.slider.left').click(function(){
    var val = parseInt($('.frame').css('transform').split(',')[4]);
    $('.frame').css('transform', 'translateX(' + (val + frameWidth) + 'px)');
    if(activeFrame-- <= 1){
      $(this).css('transform', 'translateX(0px)');
    }
  });
  
  $('.slider.right').click(function(){
    var val = parseInt($('.frame').css('transform').split(',')[4]);
    $('.frame').css('transform', 'translateX(' + (val - frameWidth) + 'px)');
    if(flameNum - 3 <= activeFrame++){
      $(this).css('transform', 'translateX(0px)');
    }
  });
});
