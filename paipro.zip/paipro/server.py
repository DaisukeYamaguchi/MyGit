from flask import Flask, render_template, Response
from time import time
import socket
import pyautogui
import io, sys
import base64
from PIL import Image
import tkinter
import threading
import random
import requests, pyautogui
from flask import Flask, render_template, session, request
from flask_socketio import SocketIO, emit, join_room, leave_room, close_room, rooms, disconnect
from joblib import Parallel, delayed

class Camera(object):
    def __init__(self):
        self.width = 0
        self.height = 0

    def get_frame(self):
        img_pil = pyautogui.screenshot()
        output = io.BytesIO()
        img_pil.save(output, format='JPEG')
        return output.getvalue()

app1 = Flask(__name__)
app2 = Flask(__name__)

app2.config['SECRET_KEY'] = 'secret!'

async_mode = None
thread = None

socketio = SocketIO(app2, async_mode=async_mode)

path = []
for i in range(0, 11):
    if i != 3 and i != 7:
        path.append(str(random.randrange(10)))
    else:
        path.append('-')

@app1.route('/' + ''.join(path))
def index():
    img_pil = pyautogui.screenshot()
    return render_template('index.html', width = img_pil.size[0], height = img_pil.size[1])

@app1.route('/feed')
def feed():
    return Response(generate(Camera()), mimetype='multipart/x-mixed-replace; boundary=frame')

@socketio.on('connect', namespace='/operate')
def test_connect():
    emit('operate', {'data': 'Connected', 'count': 0})

@socketio.on('operate', namespace='/operate')
def test_message(data):
    print(data)
    if data['action'] == 'mousemove':
        pyautogui.moveTo(data['x'], data['y'])
    elif data['action'] == 'mousedown':
        pyautogui.mouseDown(button='left')
    elif data['action'] == 'mouseup':
        pyautogui.mouseUp(button='left')
    elif data['action'] == 'keydown':
        pyautogui.keyDown(data['key'])
    elif data['action'] == 'keyup':
        pyautogui.keyUp(data['key'])

def handle():
    frm = tkinter.Tk()
    frm.geometry('490x120')
    frm.title('サンプル画面')
    ip_label = tkinter.Label(text='アクセスURL：', font=('', 12))
    ip_label.place(x=50, y=30)
    
    ip_value = tkinter.Entry(font=('', 16), width=35)
    ip_value.insert(tkinter.END, 'http://' + socket.gethostbyname(socket.gethostname()) + ':5000/' + ''.join(path))
    ip_value.configure(state='readonly')
    ip_value.place(x=50, y=55)
    
    frm.mainloop()
    sys.exit(0)

def entrust(event):
    test_message({'action': 'request'})

def generate(camera):
    while True:
        frame = camera.get_frame()
        yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

def http_start():
    app1.run(host='0.0.0.0', port=5000, debug=False)

def socket_start():
    socketio.run(app2, host='0.0.0.0', port=5001, debug=False)

if __name__ == '__main__':
    threading.Thread(target=handle).start()
    threading.Thread(target=socket_start).start()
    threading.Thread(target=http_start).start()

