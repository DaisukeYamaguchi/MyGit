import os, sys , topic, target, pkl

reply = ''

if 1 < len(sys.argv):
    msg = sys.argv[1]
    if not os.path.exists('condition.pkl'):
        pkl.dump(msg, 'message.pkl')
        topic.run(msg)
    reply = target.run(msg)
else:
    reply = 'どのようなお問い合わせですか？'

print(reply)
