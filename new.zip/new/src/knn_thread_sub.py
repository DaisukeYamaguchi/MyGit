import os, threading, copy
import language, pkl
import numpy as np

class KnnThreadSub(threading.Thread):
    def __init__(self, index, text):
        super(KnnThreadSub, self).__init__()
        self.index = index
        self.text = text
    
    def run(self):
        from sklearn.neighbors import KNeighborsClassifier
        
        print('knn_sub:'+str(self.index)+' >> start')
        
        cd = os.path.dirname(os.path.abspath(__file__)) + '/..'
        
        part_vector = {}
        model = {}
        
        pick = np.array(self.text)
        
        vector, X = self.get_tfidf(copy.deepcopy(pick[:,0]))
        
        y = pick[:,2]
        
        clf = KNeighborsClassifier(n_neighbors = 1)
        
        clf.fit(X, y)
        
        pkl.dump(vector, cd + '/pickle/vector/part'+str(self.index)+'.pkl')
        pkl.dump(clf, cd + '/pickle/model/knn'+str(self.index)+'.pkl')
        
        print('knn_sub:'+str(self.index)+' >> end')
    
    def get_tfidf(self, data):
        from sklearn.feature_extraction.text import TfidfVectorizer
        
        X = language.wakachi_nv(data)
        vector = TfidfVectorizer(use_idf=True)
        vector.fit_transform(X)
        X = vector.transform(X)
        
        return vector, X
