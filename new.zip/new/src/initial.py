# -*- coding: utf-8 -*-
import os, sys
import pkl
import numpy as np

cd = os.path.dirname(os.path.abspath(__file__)) + '/..'

def init_train():
    import threading
    import mlp_thread_super, knn_thread_super
    
    data = []
    with open(cd + '/train_data.csv', 'r', encoding = 'utf8') as f:
        for line in f:
            data.append(line.rstrip('\n').split(','))
    
    data = np.array(data)
    
    dummy = get_dummy(data[:,1])
    
    label = {}
    for i in range(len(dummy.columns)):
        label[i] = dummy.columns[i]
    
    thread = []
    thread.append(mlp_thread_super.MlpThreadSuper(data, dummy, label))
    thread.append(knn_thread_super.KnnThreadSuper(data, label))
    
    for item in thread:
        item.start()
    
    for item in thread:
        item.join()
    
    pkl.dump(label, cd + '/pickle/document/label.pkl')
    merge_pickle(label)
    
    return '学習が完了しました。'

def get_dummy(data):
    import pandas as pd
    
    return pd.get_dummies(data, drop_first = False)

def merge_pickle(label):
    vector = {}
    mlp = {}
    knn = {}
    for i in range(len(label)):
        vector[i] = pkl.load(cd + '/pickle/vector/part'+str(i)+'.pkl')
        mlp[i] = pkl.load(cd + '/pickle/model/mlp'+str(i)+'.pkl')
        knn[i] = pkl.load(cd + '/pickle/model/knn'+str(i)+'.pkl')
        os.remove(cd + '/pickle/vector/part'+str(i)+'.pkl')
        os.remove(cd + '/pickle/model/mlp'+str(i)+'.pkl')
        os.remove(cd + '/pickle/model/knn'+str(i)+'.pkl')
    
    pkl.dump(vector, cd + '/pickle/vector/part.pkl')
    pkl.dump(mlp, cd + '/pickle/model/mlp.pkl')
    pkl.dump(knn, cd + '/pickle/model/knn.pkl')


msg = ''
if 1 < len(sys.argv):
    if sys.argv[1] == 'train':
        msg = init_train()
    elif sys.argv[1] == 'synonym':
        msg = init_syonym()
else:
    msg = init_train()
    msg = init_syonym()

print(msg)

