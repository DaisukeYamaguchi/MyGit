import os, sys, datetime, topic, target, pkl

reply = None
cd = os.path.dirname(os.path.abspath(__file__)) + '/..'

if 1 < len(sys.argv):
    msg = sys.argv[1]
    if not os.path.exists(cd + '/pickle/session/condition.pkl'):
        condition = {}
        condition['datetime'] = datetime.datetime.today()
        pkl.dump(condition, cd + '/pickle/session/condition.pkl')
        pkl.dump(msg, cd + '/pickle/session/message.pkl')
        topic.run(msg)
    reply = target.run(msg)

print(reply)
