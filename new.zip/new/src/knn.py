import os
import language, pkl

def predict(topic, msg):
    
    cd = os.path.dirname(os.path.abspath(__file__)) + '/..'
    
    msg = language.wakachi_nv([msg])
    text = pkl.load(cd + '/pickle/document/text.pkl')
    label = pkl.load(cd + '/pickle/document/label.pkl')
    part = pkl.load(cd + '/pickle/vector/part.pkl')
    knn = pkl.load(cd + '/pickle/model/knn.pkl')
    
    index = ''
    for key, value in label.items():
        if value == topic:
            index = key
    
    vector = part[index]
    X = vector.transform(msg)
    
    clf = knn[index]
    
    distances, indices = clf.kneighbors(X)
    
    text = text[index]
    
    reply = []
    for item in indices[0]:
        reply.append(text[item][2])
    
    return reply

