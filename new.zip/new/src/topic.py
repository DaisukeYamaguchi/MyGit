import os, mlp, pkl
import configparser

def run(msg):
    
    cd = os.path.dirname(os.path.abspath(__file__)) + '/..'
    
    condition = pkl.load(cd + '/pickle/session/condition.pkl')
    
    ini = configparser.SafeConfigParser()
    ini.read(cd + '/conf.ini')
    
    mlp_thre1 = float(ini.get('settings', 'mlp_thre1'))
    mlp_thre2 = float(ini.get('settings', 'mlp_thre2'))
    mlp_thre3 = float(ini.get('settings', 'mlp_thre3'))
    knn_thre = float(ini.get('settings', 'knn_thre'))
    
    prob = mlp.predict(msg)
    
    pick = [[] for j in range(3)]
    for item in prob:
        if mlp_thre1 < item[1]:
            pick[0].append(item)
        elif mlp_thre2 < item[1]:
            pick[1].append(item)
        elif mlp_thre3 < item[1]:
            pick[2].append(item)
    
    bot = ''
    condition.update({'predict': '', 'topic': []})
    if 0 != len(pick[0]):
        if 1 == len(pick[0]):
            condition['predict'] = 'definitely'
            condition['topic'].append(pick[0][0][0])
            condition['case'] = '11'
            condition['ask'] = False
        else:
            bot += pick[0][0][0]
            for i in range(pick[0]):
                condition['predict'] = 'definitely'
                condition['topic'].append(pick[0][i][0])
                condition['case'] = '12'
                condition['ask'] = False
    elif 0 != len(pick[1]):
        if 1 == len(pick[1]):
            condition['predict'] = 'probably'
            condition['topic'].append(pick[1][0][0])
            condition['case'] = '21'
            condition['ask'] = False
        else:
            bot += pick[1][0][0]
            for i in range(pick[1]):
                condition['predict'] = 'probably'
                condition['topic'].append(pick[1][i][0])
                condition['case'] = '22'
                condition['ask'] = False
    else:
        condition['case'] = '00'
    
    print(condition)
    
    pkl.dump(condition, cd + '/pickle/session/condition.pkl')

