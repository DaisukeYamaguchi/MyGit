import os, knn, pkl

def run(msg):
    
    cd = os.path.dirname(os.path.abspath(__file__)) + '/..'
    
    condition = pkl.load(cd + '/pickle/session/condition.pkl')
    message = pkl.load(cd + '/pickle/session/message.pkl')
    
    bot = ''
    if condition['case'] == '11':
        bot += ','.join(knn.predict(condition['topic'][0], message))
        bot += '\r\n回答に満足いただけましたか？'
        condition['case'] = '99'
        condition['ask'] = True
    elif condition['case'] == '12':
        if condition['ask']:
            topic = get_topic(msg)
            if 1 == len(topic):
                bot += ','.join(knn.predict(condition['topic'][0], message))
                bot += '\r\n回答に満足いただけましたか？'
                condition['case'] = '99'
            else:
                bot += '申し訳ございません、判断できませんでした。\n管理者に追加学習を依頼し、サービスを終了します。'
        else:
            for i in range(len(condition['topic'])):
                bot += condition['topic'][i] + '、'
            bot += 'これらの話に該当しそうです。どれですか？'
            condition['ask'] = True
    elif condition['case'] == '21':
        if condition['ask']:
            pn = 1
            if pn == 1:
                bot += ','.join(knn.predict(condition['topic'][0], message))
                bot += '\r\n回答に満足いただけましたか？'
                condition['case'] = '99'
            else:
                topic = get_topic(msg)
                if 1 == len(topic):
                    bot += ','.join(knn.predict(topic[0], message))
                    bot += '\r\n回答に満足いただけましたか？'
                    condition['case'] = '99'
                else:
                    label = pkl.load(cd + '/pickle/document/label.pkl')
                    for item in label.values():
                        bot += item + '、'
                    bot += 'どれについての話ですか？'
                    condition['case'] = '12'
        else:
            bot += condition['topic'][0] + 'についての話ですか？'
            condition['ask'] = True
    elif condition['case'] == '22':
        if condition['ask']:
            topic = get_topic(msg)
            if 1 == len(topic):
                bot += ','.join(knn.predict(condition['topic'][0], pkl.load(cd + '/pickle/session/message.pkl')))
                bot += '\r\n回答に満足いただけましたか？'
                condition['case'] = '99'
            else:
                bot += '申し訳ございません、判断できませんでした。\n管理者に追加学習を依頼し、サービスを終了します。'
        else:
            bot += condition['topic'][0]
            for i in range(1, len(condition['topic'])):
                bot += '、'+condition['topic'][i]
            bot += 'についての話に該当する可能性があります。どれですか？'
            condition['ask'] = True
    elif condition['case'] == '99':
        pn = 0
        if pn == 1:
            bot += 'ありがとうございます。またのご利用をお待ちしております。'
        else:
            bot += 'お役に立てず申し訳ございません。\n管理者に追加学習を依頼し、サービスを終了します。'
    else:
        bot += '申し訳ございません、判断できませんでした。\n管理者に追加学習を依頼し、サービスを終了します。'
    
    print(condition)
    pkl.dump(condition, cd + '/pickle/session/condition.pkl')
    
    return bot

def get_topic(msg):
    
    cd = os.path.dirname(os.path.abspath(__file__)) + '/..'
    
    label = pkl.load(cd + '/pickle/document/label.pkl')
    
    topic = []
    for item in label.values():
        if item in msg:
            topic.append(item)
    
    return topic

