import os, threading, copy
import language, pkl
import numpy as np

class MlpThreadSub(threading.Thread):
    def __init__(self, index, X, y):
        super(MlpThreadSub, self).__init__()
        self.index = index
        self.X = X
        self.y = y
    
    def run(self):
        from sklearn.neural_network import MLPClassifier
        
        print('mlp_sub:'+str(self.index)+' >> start')
        
        cd = os.path.dirname(os.path.abspath(__file__)) + '/..'
        
        clf = MLPClassifier(
            hidden_layer_sizes = (50, ), 
            solver = 'adam', 
            alpha = 0.0001, 
            activation = 'relu', 
            random_state = 0, 
            max_iter = 10000, 
        )
        
        clf.fit(self.X, self.y)
        
        pkl.dump(clf, cd + '/pickle/model/mlp'+str(self.index)+'.pkl')
        
        print('mlp_sub:'+str(self.index)+' >> end')

