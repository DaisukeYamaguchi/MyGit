import os, threading, copy
import language, pkl

class MlpThreadSuper(threading.Thread):
    def __init__(self, data, dummy, label):
        super(MlpThreadSuper, self).__init__()
        self.data = data
        self.dummy = dummy
        self.label = label
    
    def run(self):
        import mlp_thread_sub
        
        print('mlp_super >> start')
        
        cd = os.path.dirname(os.path.abspath(__file__)) + '/..'
        
        vector, X = self.get_tfidf(copy.deepcopy(self.data[:,0]))
        
        thread = []
        for i in range(len(self.label)):
            y = self.dummy[self.label[i]]
            thread.append(mlp_thread_sub.MlpThreadSub(i, X, y))
        
        for item in thread:
            item.start()
        
        for item in thread:
            item.join()
        
        pkl.dump(vector, cd + '/pickle/vector/full.pkl')
        
        print('mlp_super >> end')
    
    def get_tfidf(self, data):
        from sklearn.feature_extraction.text import TfidfVectorizer
        
        X = language.wakachi_nv(data)
        vector = TfidfVectorizer(use_idf=True)
        vector.fit_transform(X)
        X = vector.transform(X)
        
        return vector, X

