import os
import language, pkl

def predict(msg):
    
    cd = os.path.dirname(os.path.abspath(__file__)) + '/..'
    
    msg = language.wakachi_nv([msg])
    label = pkl.load(cd + '/pickle/document/label.pkl')
    full = pkl.load(cd + '/pickle/vector/full.pkl')
    mlp = pkl.load(cd + '/pickle/model/mlp.pkl')
    
    X = full.transform(msg)
    
    prob = []
    for i in range(len(label)):
        prob.append([label[i], mlp[i].predict(X)[1][0]])
    
    return prob

