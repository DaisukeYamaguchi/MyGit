import os, threading
import pkl

class KnnThreadSuper(threading.Thread):
    def __init__(self, data, label):
        super(KnnThreadSuper, self).__init__()
        self.data = data
        self.label = label
    
    def run(self):
        import knn_thread_sub
        print('knn_super >> start')
        
        cd = os.path.dirname(os.path.abspath(__file__)) + '/..'
        
        text = {}
        for i in range(len(self.label)):
            text[i] = []
            for line in self.data:
                if line[1] == self.label[i]:
                    text[i].append(list(line))
        
        thread = []
        for i in range(len(text)):
            thread.append(knn_thread_sub.KnnThreadSub(i, text[i]))
        
        for item in thread:
            item.start()
        
        for item in thread:
            item.join()
        
        pkl.dump(text, cd + '/pickle/document/text.pkl')
        
        print('knn_super >> end')

