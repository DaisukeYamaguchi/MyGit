import language, pkl

def predict(label, msg):
    
    msg = language.wakachi_nv([msg])
    learning_set = pkl.load('learning_set.pkl')
    
    index = ''
    for key, value in learning_set['label'].items():
        if value == label:
            index = key
    
    vector = learning_set['vector']['part'+str(index)]
    X = vector.transform(msg)
    
    clf = learning_set['knn']['model'+str(index)]
    
    distances, indices = clf.kneighbors(X)
    
    text = learning_set['text'][index]
    
    reply = []
    for item in indices[0]:
        reply.append(text[item][2])
    
    return reply

