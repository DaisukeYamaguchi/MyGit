import os, knn, language, pkl
import configparser

def run(msg):
    condition = pkl.load('condition.pkl')
    
    bot = ''
    if condition['case'] == '11':
        if condition['ask']:
            bot += ','.join(knn.predict(condition['topic'][0], pkl.load('message.pkl')))
            os.remove('condition.pkl')
        else:
            bot += ','.join(knn.predict(condition['topic'][0], pkl.load('message.pkl')))
            condition['ask'] = True
            os.remove('condition.pkl')
    elif condition['case'] == '12':
        if condition['ask']:
            topic = get_topic(msg)
            if 1 == len(topic):
                bot += ','.join(knn.predict(condition['topic'][0], pkl.load('message.pkl')))
                os.remove('condition.pkl')
            else:
                bot += 'すいません、判断できません。'
        else:
            bot += condition['topic'][0]
            for i in range(1, len(condition['topic'])):
                bot += '、'+condition['topic'][i]
            bot += 'についての話に該当します。どれですか？'
            condition['ask'] = True
    elif condition['case'] == '21':
        if condition['ask']:
            pn = 0
            if pn == 1:
                bot += ','.join(knn.predict(condition['topic'][0], pkl.load('message.pkl')))
                os.remove('condition.pkl')
            else:
                topic = get_topic(msg)
                if 1 == len(topic):
                    bot += ','.join(knn.predict(topic[0], pkl.load('message.pkl')))
                    os.remove('condition.pkl')
                else:
                    bot += '何についての話ですか？'
        else:
            bot += condition['topic'][0] + 'についての話ですか？'
            condition['ask'] = True
    elif condition['case'] == '22':
        if condition['ask']:
            topic = get_topic(msg)
            if 1 == len(topic):
                bot += ','.join(knn.predict(condition['topic'][0], pkl.load('message.pkl')))
                os.remove('condition.pkl')
            else:
                bot += 'すいません、判断できません。'
        else:
            bot += condition['topic'][0]
            for i in range(1, len(condition['topic'])):
                bot += '、'+condition['topic'][i]
            bot += 'についての話に該当する可能性があります。どれですか？'
            condition['ask'] = True
    else:
        bot += 'すいません、全然分かりません。'
    pkl.dump(condition, 'condition.pkl')
    
    return bot

def get_topic(msg):
    
    learning_set = pkl.load('learning_set.pkl')
    
    topic = []
    for item in learning_set['label'].values():
        if item in msg:
            topic.append(item)
    
    return topic

