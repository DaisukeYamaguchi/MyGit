import language, pkl

def predict(msg):
    
    msg = language.wakachi_nv([msg])
    learning_set = pkl.load('learning_set.pkl')
    
    X = learning_set['vector']['full'].transform(msg)
    
    prob = []
    for i in range(len(learning_set['label'])):
        prob.append([learning_set['label'][i], learning_set['mlp']['model'+str(i)].predict(X)[1][0]])
    
    return prob

