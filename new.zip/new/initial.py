# -*- coding: utf-8 -*-
import sys, copy
import language, pkl
import numpy as np

msg = sys.argv[1]

def init_train():
    
    learning_set = {}
    
    data = []
    with open('all_ziburi.csv', 'r', encoding = 'utf8') as f:
        for line in f:
            data.append(line.rstrip('\n').split(','))
    
    data = np.array(data)
    
    vector, X = get_tfidf(copy.deepcopy(data[:,1]))
    
    dummy = get_dummy(data[:,0])
    
    label = {}
    text = {}
    for item in zip(range(len(dummy.columns)), dummy.columns):
        label[item[0]] = item[1]
        text[item[0]] = []
        for line in data:
            if line[0] == item[1]:
                text[item[0]].append(list(line))
    
    learning_set['label'] = label
    learning_set['text'] = text
    
    learning_set['mlp'] = run_mlp(X, dummy, label)
    learning_set['knn'], learning_set['vector'] = run_knn(text, label)
    learning_set['vector']['full'] = vector
    
    pkl.dump(learning_set, 'learning_set.pkl')

def get_dummy(data):
    import pandas as pd
    
    return pd.get_dummies(data, drop_first = False)

def get_tfidf(data):
    from sklearn.feature_extraction.text import TfidfVectorizer
    
    X = language.wakachi_nv(data)
    vector = TfidfVectorizer(use_idf=True)
    vector.fit_transform(X)
    X = vector.transform(X)
    
    return vector, X

def run_mlp(X, dummy, label):
    from sklearn.neural_network import MLPClassifier
    
    model = {}
    for i in range(len(label)):
        y = dummy[label[i]]
        
        clf = MLPClassifier(
            hidden_layer_sizes = (50, ), 
            solver = 'adam', 
            alpha = 0.0001, 
            activation = 'relu', 
            random_state = 0, 
            max_iter = 10000, 
        )
        
        clf.fit(X, y)
        
        model['model'+str(i)] = clf
    
    return model

def run_knn(text, label):
    from sklearn.neighbors import KNeighborsClassifier
    
    part_vector = {}
    model = {}
    for i in range(len(text)):
        pick = np.array(text[i])
        
        vector, X = get_tfidf(copy.deepcopy(pick[:,1]))
        
        y = pick[:,2]
        
        clf = KNeighborsClassifier(n_neighbors = 4)
        
        clf.fit(X, y)
        
        part_vector['part'+str(i)] = vector
        model['model'+str(i)] = clf
    
    return model, part_vector



if msg == 'train':
    init_train()
elif msg == 'synonym':
    init_syonym()

