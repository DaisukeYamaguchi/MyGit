import knn, language, pkl
import configparser

def run(msg):
    condition = pkl.load('condition.pkl')
    learning_set = pkl.load('learning_set.pkl')
    word = ''
    topic = []
    
    word = language.wakachi_n([msg]).split(' ')
    for item in learning_set['label'].values():
        if word in item:
            topic.append(item)
    
    pn = 1
    
    bot = ''
    if pn == 1:
        msg = pkl.load('message.pkl')
        if 1 == len(topic):
            bot = knn.predict(topic[0], msg)
        else:
            bot = '文言を変えてください。'
    else:
        bot = '否定形を使わずにお伝えください。'
    
    return bot

