# -*- coding: utf-8 -*
import os, sys, datetime
import pkl
from dateutil.relativedelta import relativedelta
from janome.tokenizer import Tokenizer

# 類義語学習のメッセージ
def extract(feature):
    
    status = pkl.load('status.pkl')
    
    status['time'] = datetime.datetime.today()
    
    file = {'who': '', 'when': {'direct': '', 'from': '', 'to': ''}, 'what': ''}
    
    week = ['月', '火', '水', '木', '金', '土', '日']
    
    t = Tokenizer('5w1h_dict.csv')
    
    tokens = t.tokenize(''.join(feature).upper())
    
    for token in tokens:
        if token.part_of_speech.split(',')[3] == 'when':
            if 'day' in token.infl_form:
                if file['when']['from'] == '' and file['when']['to'] == '':
                    file['when']['direct'] = status['time'] - datetime.timedelta(days=int(token.infl_form.split('=')[1]))
                else:
                    file['when']['direct'] = file['when']['from'] + datetime.timedelta(days=int(token.infl_form.split('=')[1]))
                    print()
            elif 'month' in token.infl_form:
                if file['when']['from'] == '' and file['when']['to'] == '':
                    date = status['time'] - relativedelta(months=int(token.infl_form.split('=')[1]))
                    file['when']['direct'] = date
                    file['when']['from'] = file['when']['direct'] - datetime.timedelta(days=file['when']['direct'].day) + datetime.timedelta(days=1)
                    file['when']['to'] = file['when']['from'] + relativedelta(months=1) - datetime.timedelta(days=1)
            elif 'week' in token.infl_form:
                if file['when']['from'] == '' and file['when']['to'] == '':
                    print(token.infl_form.split('=')[1])
                    date = status['time'] - datetime.timedelta(days=int(token.infl_form.split('=')[1]) * 7)
                    file['when']['direct'] = date
                    file['when']['from'] = file['when']['direct'] - datetime.timedelta(days=date.weekday())
                    file['when']['to'] = file['when']['direct'] + datetime.timedelta(days=6-date.weekday())
                else:
                    for i in range(7):
                        if week[(file['when']['from'] + datetime.timedelta(days=i)).weekday()] == token.base_form:
                            file['when']['direct'] = file['when']['from'] + datetime.timedelta(days=i)
                    
                    file['when']['from'] = file['when']['to'] = ''
        if token.part_of_speech.split(',')[3] == 'who':
            file['who'] = token.surface
        if token.part_of_speech.split(',')[3] == 'what':
            file['what'] = token.base_form
    
    return file

