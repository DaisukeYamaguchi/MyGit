# -*- coding: utf-8 -*-
import pkl
from sklearn.neural_network import MLPClassifier
from sklearn.grid_search import GridSearchCV
from sklearn.metrics import classification_report

params = {'hidden_layer_sizes': [(50,), (100,), (150,), (200,), (250,), (300,)], 
          'max_iter': [1000], 
          'batch_size': [200, 300], 
          'early_stopping': [True], 
          'learning_rate_init': [0.01, 0.005, 0.001, 0.0005], 
          'random_state':[123]}

score = 'f1'
clf = GridSearchCV(MLPClassifier(), params, cv=5, scoring='%s_weighted' % score )

clf.fit(train_X, train_y[:,0])

for item in clf.grid_scores_:
    print(item)

clf.best_params_

print("# Tuning hyper-parameters for %s" % score)
print()
print("Best parameters set found on development set: %s" % clf.best_params_)
print()

# それぞれのパラメータでの試行結果の表示
print("Grid scores on development set:")
print()
for params, mean_score, scores in clf.grid_scores_:
    print("%0.3f (+/-%0.03f) for %r"
          % (mean_score, scores.std() * 2, params))

print()

# テストデータセットでの分類精度を表示
print("The scores are computed on the full evaluation set.")
print()
true_y, pred_y = train_y, clf.predict(train_X)
print(classification_report(true_y, pred_y))





'''
model = []
for i in range(len(index)):
    y = label.iloc[:,i]
    
    # 学習モデル定義
    clf = MultinomialNB()
    
    clf.fit(X, y)
    
    model.append(clf)

pkl.dump(clf, 'mlp_doc_models.pkl')

hidden_layer_sizes=(100, )#隠れ層のノード数(多層にもできる)
activation='relu'#活性化関数(identify, logistic, tanh, relu)
solver='adam'#最適化手法(lbfgs(準ニュートン法), sgd, adam)
alpha=0.0001
batch_size='auto'#バッチサイズ(sgd, adamで適用)
learning_rate='constant'
learning_rate_init=0.001
power_t=0.5
max_iter=200#最大エポック数
shuffle=True#iterationの度にサンプルをシャッフル
random_state=None
tol=0.0001
verbose=False
warm_start=False
momentum=0.9
nesterovs_momentum=True
early_stopping=False
validation_fraction=0.1
beta_1=0.9
beta_2=0.999
epsilon=1e-08

hidden_layer_sizes=(100, )	隠れ層のノード数(多層化可能)
activation=’relu’	活性化関数(identify, logistic, tanh, relu)
solver=’adam’	最適化手法(lbfgs, sgd, adam)
alpha	L2ペナルティ（正則化の項）
batch_size=’auto’	最適化のバッチサイズ(sgd、adam用)
learning_rate	重み更新のための学習率スケジュール（’定数’、 ‘invscaling’、 ‘adaptive’）
max_iter=200	反復の最大回数
shuffle	反復する度にサンプルをシャッフルするか（solverが’sgd’か’adam’の時に使用）
random_state	乱数生成の状態 or シード（int、RandomState）
tol	最適化の許容誤差
power_t	スケーリング学習率の指数
verbose	進捗メッセージを標準出力するかどうか
warm_start	以前の呼び出しの解を再利用して初期化するかどうか
momentum	勾配降下更新のモメンタム
nesterovs_momentum	訓練データの10％が妥当性検査として自動設定され、2つの連続したエポックで少なくとも妥当性スコアが改善していない場合は訓練終了（solver = ‘sgd’または ‘adam’で有効）
early_stopping	検証スコアが改善されていないとき訓練中止のために早期停止を使用するかどうか
validation_fractionv	早期停止のための妥当性確認として設定される訓練データの割合
beta_1	adamの第1モーメントベクトルの推定値に対する指数関数的減衰率
beta_2	adamの第2モーメントベクトルの推定値に対する指数関数的減衰率
epsilon	adamの数値安定性の値(solver = ‘adam’で使用)
'''