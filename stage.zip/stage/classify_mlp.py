# -*- coding: utf-8 -*-
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier


clf = MLPClassifier(solver="sgd",random_state=0,max_iter=10000)
clf.fit(X_train, y_train)
print (clf.score(X_test, y_test))

'''
model = []
for i in range(len(index)):
    y = label.iloc[:,i]
    
    # 学習モデル定義
    clf = MultinomialNB()
    
    clf.fit(X, y)
    
    model.append(clf)

pkl.dump(clf, 'mlp_doc_models.pkl')

hidden_layer_sizes=(100, )#隠れ層のノード数(多層にもできる)
activation='relu'#活性化関数(identify, logistic, tanh, relu)
solver='adam'#最適化手法(lbfgs(準ニュートン法), sgd, adam)
alpha=0.0001
batch_size='auto'#バッチサイズ(sgd, adamで適用)
learning_rate='constant'
learning_rate_init=0.001
power_t=0.5
max_iter=200#最大エポック数
shuffle=True#iterationの度にサンプルをシャッフル
random_state=None
tol=0.0001
verbose=False
warm_start=False
momentum=0.9
nesterovs_momentum=True
early_stopping=False
validation_fraction=0.1
beta_1=0.9
beta_2=0.999
epsilon=1e-08
'''
