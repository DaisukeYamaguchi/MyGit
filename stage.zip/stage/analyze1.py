# -*- coding: utf-8 -*
import os, sys, subprocess
import random as rd
import common
from janome.tokenizer import Tokenizer

# 係り受け解析の結果を返す
def cabocha(msg):
    with open('input.txt', 'w', encoding = 'utf8') as f:
        f.write(msg)
    
    proc = subprocess.Popen("cabocha -f1 < input.txt", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    buf = []
    
    while True:
        # バッファから1行読み込む.
        line = proc.stdout.readline().decode('utf8')
        buf.append(line.rstrip('\r\n').replace('\t', ' '))
        
        # バッファが空 + プロセス終了.
        if not line and proc.poll() is not None:
            break
    
    os.remove('input.txt')
    
    num = buf.count('')
    for i in range(num):
        buf.remove('')
    
    buf.remove('EOS')
    
    next = False
    relates = []
    temp = []
    for item in buf:
        if item[0] == '*':
            next = True
            relates.append(item)
        else:
            if next:
                temp.append(item.split(' ')[0])
            else:
                temp[-1] += item.split(' ')[0]
            
            next = False
    
    for i in range(len(relates)):
        relates[i] = relates[i].split(' ')
        relates[i][0] = temp[i]
    
    return relates

def run(msg):
    # チャットボックス宣言
    subject = ''
    predict = ''
    object = ''
    
    t = Tokenizer('dict.csv')
    
    # 主語節と目的語を取得
    pos = []
    objtemp = ''
    temp = ''
    tokens = t.tokenize(msg)
    for token in tokens:
        pos.append([token.surface, token.part_of_speech.split(',')[0], token.part_of_speech.split(',')[1], token.part_of_speech.split(',')[2], token.base_form])
        if token.part_of_speech.split(',')[1] == '係助詞':
            subject = temp + token.surfase
        elif token.part_of_speech.split(',')[1] == '格助詞':
#            if wn.getSynonym(temp) != {}:
#                object = list(wn.getSynonym(temp).keys())[0]
            if common.method(temp) != None:
                object = common.method(temp)
                objtemp = temp
        else:
            temp = token.surface
    
    # 係り受け解析を取得
    relates = cabocha(msg)
    
    # 目的語群を特徴的文書として取得
    index = None
    add = True
    feature = []
    for i in range(len(relates)):
        if add:
            if objtemp in relates[i][0]:
                add = False
            else:
                feature.append(relates[i][0])
    
    
    
    # 係り受け解析を取得
    #relates = cabocha(msg)
    
    # 目的語群を特徴的文書として取得
    #index = None
    #cnt = None
    #feature = []
    #relates.reverse()
    #for i in range(len(relates)):
    #    if objtemp in relates[i][0]:
    #        index = relates[i][1]
    #        feature = [relates[i][0]]
    #        cnt = i
    #
    #for i in range(cnt+1, len(relates)):
    #    if index == relates[i][2].replace('D', ''):
    #        feature.append(relates[i][0])
    #        index = relates[i][1]
    #
    #feature.reverse()
    
    
    
    # 述語節を取得
    for i in range(len(relates)):
        if '-1D' in relates[i][2]:
            predict = relates[i][0]
    
    # 述語節の不要な文言を除去
    tokens = t.tokenize(predict)
    predict = ''
    for token in tokens:
        predict += token.base_form
        break
    
    # predict = list(wn.getSynonym(predict).keys())[0]
    predict = common.synonym(predict)
    
    return {'subject': subject, 'predict': predict, 'object': object, 'feature': feature}

