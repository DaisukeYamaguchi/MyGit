# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
from matplotlib_venn import venn3
from matplotlib.font_manager import FontProperties

fp = FontProperties(fname=r'C:\WINDOWS\Fonts\HGRGE.TTC', size=14)

#A=1.8, B=0.9,C=0.3,AB=0.5,AC=0.2,BC=0.3,ABC=0.2
venn3(subsets = {'100': 1.8, '010': 0.9, '001': 0.3,
                 '110': 0.5, '101': 0.2, '011': 0.3,
                 '111': 0.2}, 
                 set_labels = None)

plt.legend([u'山', '口', '大'], prop=fp, loc='upper left')
plt.show()
