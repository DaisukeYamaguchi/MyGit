# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import pkl
import language
from sklearn.feature_extraction.text import TfidfVectorizer

data = []
with open('all_ziburi.csv', 'r', encoding = 'utf8') as f:
    for line in f:
        data.append(line.rstrip('\n').split(','))

data.pop(0)
data = np.array(data)

text = data[:,0]
label = pd.Series(data[:,1])
label = label.reset_index(drop=True)
label = pd.get_dummies(label, drop_first = True)

temp = list(label.columns)
index = {}
for i in range(len(temp)):
    index[i] = temp[i]

# ストップワードを指定してベクトルを学習
vectorizer = TfidfVectorizer(stop_words=['私'])
vectorizer.fit(train_X)

train_X = vectorizer.transform(text) 
train_y = label.as_matrix()

pkl.dump(index, 'label_index.pkl')
pkl.dump(vectorizer, 'doc_vec.pkl')





# 学習データからベクトルを生成
X = vectorizer.transform(train_X)

model = []
for i in range(len(index)):
    y = label.iloc[:,i]
    
    # 学習モデル定義
    clf = MultinomialNB()
    
    clf.fit(X, y)
    
    model.append(clf)

pkl.dump(clf, 'document_models.pkl')

