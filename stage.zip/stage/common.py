# -*- coding: utf-8 -*
import pkl

# 類義語学習のメッセージ
def re_hear(selection):
    print('要求を理解しました。')
    print('これまでにおっしゃった')
    for i in range(0, len(selection)-1):
        print(str(i+1) + '.「'+selection[i]+'」')
    
    if 2 < len(selection):
        print('これらは')
    else:
        print('これは')
    
    print('「'+selection[-1]+'」')
    print('と同じ意味ですか？')

def synonym(word):
    synonym = pkl.load('represent.pkl')
    represent = None
    for item in synonym['synonym']:
        if word in synonym['synonym'][item]:
            represent = item
    
    return represent

def method(word):
    method = pkl.load('represent.pkl')
    represent = None
    for item in method['method']:
        if word in method['method'][item]:
            represent = item
    
    return represent

def decision(dict):
    decision = pkl.load('represent.pkl')
    represent = None
    for item in decision['decision'].keys():
        if dict['subject'] == decision['decision'][item]['subject'] and dict['predict'] == decision['decision'][item]['predict'] and dict['object'] == decision['decision'][item]['object']:
            represent = item
    
    return represent

