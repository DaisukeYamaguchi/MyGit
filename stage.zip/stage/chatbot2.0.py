# -*- coding: utf-8 -*
import pkl
import analyze1
import file_base
import common
import random as rd

status = pkl.load('status.pkl')

msg = '先月山口さんが作ったエクセルの手順書をください'

status['talk'] = analyze1.run(msg)

selection = []
if status['talk']['subject'] == None or status['talk']['subject'] == None:
    selection.append(msg)
    msg = rd.choice(status[random]['pardon']) + '\n' + rd.choice(status[random]['rehear'])
else:
    if selection != []:
        re_hear(selection)
    
    process = common.decision(status['talk'])
    
    if process == 'open_file':
        file_base.extract(status['talk']['feature'])
        msg = 'May I open any file?'
            #open_file()
    else:
        msg = 'unknown processes.'

print(msg)
