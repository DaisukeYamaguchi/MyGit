# -*- coding: utf-8 -*
from janome.tokenizer import Tokenizer

def wakachi_nv(text):
    t = Tokenizer('dict.csv')
    
    for i in range(len(text)):
        line = []
        tokens = t.tokenize(text[i])
        for token in tokens:
            if token.part_of_speech.split(',')[0] == '名詞' or token.part_of_speech.split(',')[0] == '動詞':
                if token.base_form != '*':
                    line.append(token.base_form)
        text[i] = ' '.join(line)
    return text

