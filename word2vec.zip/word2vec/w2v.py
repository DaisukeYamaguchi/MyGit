import os
from janome.tokenizer import Tokenizer

t = Tokenizer()

cnt = 0

word_dict = {}
with open('./wiki_wakachi.txt', 'w', encoding='utf8') as f1:
  for item1 in os.listdir('./text'):
    for item2 in os.listdir('./text/' + item1):
      wiki = open('./text/' + item1 + '/' + item2, 'r', encoding='utf8')
      
      for line in wiki:
        tokens = t.tokenize(line)
        
        line = []
        for token in tokens:
          #if token.part_of_speech.split(',')[0] == '名詞' or token.part_of_speech.split(',')[0] == '動詞' or token.part_of_speech.split(',')[0] == '形容詞' or token.part_of_speech.split(',')[0] == '形容動詞':
          if token.part_of_speech.split(',')[0] == '名詞':
            if token.part_of_speech.split(',')[1] != '代名詞' and token.part_of_speech.split(',')[1] != '非自立' and token.part_of_speech.split(',')[1] != '接尾' and token.part_of_speech.split(',')[1] != '数':
              if token.base_form != '*':
                line.append(token.base_form)
                if token.base_form in word_dict.keys():
                  word_dict[token.base_form] += (word_dict[token.base_form] + 1)
                else:
                  word_dict[token.base_form] = 1
              else:
                line.append(token.surface)
                if token.surface in word_dict.keys():
                  word_dict[token.surface] += (word_dict[token.surface] + 1)
                else:
                  word_dict[token.surface] = 1
        
        waste = f1.write(' '.join(line))
        waste = f1.write('\n')
        cnt += 1
        print('row: ' + str(cnt))
      
      wiki.close()



from gensim.models import word2vec
import logging

logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
sentences = word2vec.Text8Corpus('./wiki_wakachi.txt')

model = word2vec.Word2Vec(sentences, size=200, min_count=20, window=15)
model.save("./wiki.model")



#model = word2vec.Word2Vec.load('./wiki.model')
#results = model.wv.most_similar(positive=['技術'])
#for result in results:
#    print(result)



from gensim.models import word2vec
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

model = word2vec.Word2Vec.load('./wiki.model')

words = list(model.vocab.keys())

data = []
for i in range(len(words)):
  data.append(model[words[i]])

pca = PCA(n_components=3)
pca.fit(data)
data_pca = pca.transform(data)

for i in range(len(data_pca)):
  data_pca[i] = data_pca[i] * (50 / np.sqrt(np.sum(data_pca[i] * data_pca[i])))




import numpy
import PIL.Image
import PIL.ImageDraw
import PIL.ImageFont

def draw_text_at_center(img, text):
  draw = PIL.ImageDraw.Draw(img)
  draw.font = PIL.ImageFont.truetype('./meiryo.ttc', 20)
  
  img_size = numpy.array(img.size)
  txt_size = numpy.array(draw.font.getsize(text))
  pos = [0, -3]
  
  draw.text(pos, text, (0, 0, 0))

num = 500

string = ''
for i in range(num):
  tmp = data_pca[i].tolist()
  tmp.append(len(words[i]))
  if i == 0:
    string += '['
  string += '[' + str(tmp[0])
  for j in range(3):
    string += (',' + str(tmp[j+1]))
  string += ']'
  
  if i == num - 1:
    string += ']'
  else:
    string += ',\r\n'
  
  img = PIL.Image.new('RGBA', (len(words[i]) * 20, 20))
  draw_text_at_center(img, words[i])
  
  img.save('./images/words/' + str(i) + '.png')

print(string)

