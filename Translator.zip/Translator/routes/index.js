var fs = require('fs');
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.post('/', function(req, res, next) {
  var info = {'room': req.body.room, 'user': req.body.user, 'lang': req.body.lang}
  res.render('room', {title: 'room', info: JSON.stringify(info)});
});

module.exports = router;
