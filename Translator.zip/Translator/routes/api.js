var LanguageTranslatorV2 = require('watson-developer-cloud/language-translator/v2');
var express = require('express');
var router = express.Router();

var languageTranslator = new LanguageTranslatorV2({
  username: '6a01f80a-5d43-4187-ad1b-e9caebdfa97b',
  password: 'EHPBEsDp0Xrx'
});

var models = [];

languageTranslator.listModels({},function(err, response) {
  if(err){
    res.send(err);
  }else{
    for(var i=0 ; i<response['models'].length ; i++){
      models.push(response['models'][i]['source'] + '-' + response['models'][i]['target'])
    }
  }
});

/* GET users listing. */
router.get('/translate', function(req, res, next) {
  console.log(req.query.from + ' -> ' + req.query.to)
  if(0 <= models.indexOf(req.query.from + '-' + req.query.to) && 0 <= models.indexOf(req.query.to + '-' + req.query.from)){
    var parameters = {
      text: req.query.message,
      source: req.query.from,
      target: req.query.to
    };
    
    languageTranslator.translate(parameters, function(err, response){
      if(err){
        console.log(err)
      }else{
        res.send(response['translations'][0]['translation']);
      }
    });
  }else{
    var parameters = {
      text: req.query.message,
      source: req.query.from,
      target: 'en'
    };
    
    languageTranslator.translate(parameters, function(err, response){
      if(err){
        console.log(err)
      }else{
        var message = response['translations'][0]['translation'];
        var parameters = {
          text: message,
          source: 'en',
          target: req.query.to
        };
        
        languageTranslator.translate(
          parameters,
          function(err, response) {
            if(err){
              console.log(err)
            }else{
              res.send(response['translations'][0]['translation']);
            }
          }
        );
      }
    });
  }
});

module.exports = router;
