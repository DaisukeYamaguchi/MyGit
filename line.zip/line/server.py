import os, requests, json
from botsession import BotSessionInterface

from flask import Flask, request, abort, send_from_directory, g
from linebot import (
    LineBotApi, WebhookHandler, WebhookParser
)

from linebot.exceptions import (
    InvalidSignatureError,
    LineBotApiError
)

from linebot.models import (
    MessageEvent, TextMessage, TextSendMessage,
    URIAction, PostbackAction, PostbackEvent,
    FlexSendMessage, BubbleContainer, ImageComponent, BoxComponent,
    TextComponent, SpacerComponent, IconComponent, ButtonComponent,
    SeparatorComponent)

app = Flask(__name__)

LINE_CHANNEL_ACCESS_TOKEN = 'CRb5a3LzPc1eSdktYNqL24+aL1t3Igoy+AH3DfM91l5trihrwT8SZi8i/bRV4Je4xX69ODFu7LaZvwBsdWkf/kfwOx0ziPHbVH3za6SREr2W3k5Bv5ljPG6B9vnnvuXp2SzURJuJ+KW0OqLi28N6zgdB04t89/1O/w1cDnyilFU='
LINE_CHANNEL_SECRET = 'fd51a514677cc753a677b5f6bb1e48fc'

line_bot_api = LineBotApi(LINE_CHANNEL_ACCESS_TOKEN)
handler = WebhookHandler(LINE_CHANNEL_SECRET)
parser = WebhookParser(LINE_CHANNEL_SECRET)

session = {}

@app.route("/callback", methods=['POST'])
def callback():
    # get X-Line-Signature header value
    signature = request.headers['X-Line-Signature']

    # get request body as text
    body = request.get_data(as_text=True)
    app.logger.info("Request body: " + body)

    # handle webhook body
    try:
        events = parser.parse(body, signature)
        user_id = events.pop().source.user_id
        
        if user_id not in session.keys():
            session[user_id] = {}
        
        handler.handle(body, signature)
    except LineBotApiError as e:
        print("Got exception from LINE Messaging API: %s\n" % e.message)
        for m in e.error.details:
            print("  %s: %s" % (m.property, m.message))
        print("\n")
    except InvalidSignatureError:
        abort(400)

    return 'OK'



@handler.add(MessageEvent, message=TextMessage)
def handle_text_message(event):
    text = event.message.text

    url = 'waste'
    
    session[event.source.user_id]['url'] = url
    
    response = requests.get(url)
    data = json.loads(response.text)
    postback(event, data)
    
    #line_bot_api.reply_message(
    #    event.reply_token, TextSendMessage(text=event.message.text))


@handler.add(PostbackEvent)
def handle_postback(event):
    url = 'waste'
    
    session[event.source.user_id]['url'] = url
    
    response = requests.get(url)
    data = json.loads(response.text)
    postback(event, data)



def postback(event, data):
    buttons = []
    for i in range(len(data['buttons'])):
        buttons.append(
            ButtonComponent(
                style='primary',
                height='sm',
                action=PostbackAction(label=data['buttons'][i], data=data['buttons'][i])
            )
        )
    
    bubble = BubbleContainer(
        direction='ltr',
        body=BoxComponent(
            layout='vertical',
            spacing='sm',
            contents=[
                TextComponent(
                    text=data['message'],
                    weight='bold',
                    color='#aaaaaa',
                    size='lg'
                )
            ]
        ),
        footer=BoxComponent(
            layout='vertical',
            spacing='sm',
            contents=buttons
        )
    )
    message = FlexSendMessage(alt_text="hello", contents=bubble)
    line_bot_api.reply_message(
        event.reply_token,
        message
    )

if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    app.run(host="0.0.0.0", port=port)

